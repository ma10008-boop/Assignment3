#pragma once

#include "net/http_client.h"

namespace sign {

enum class VerifyResult {
    Ok,
    NotSigned,          // no Content-Digest header at all -- an ordinary, unsigned page
                        // (not a failure: signing is opt-in, see docs on this function)
    MalformedHeaders,   // has a Content-Digest but Signature-Input/Signature are absent or
                        // don't match the minimal shape this checks for (verify_signature.cpp)
    DigestMismatch,     // Content-Digest doesn't match the page's actual body
    CertFetchFailed,    // couldn't fetch the leaf cert named by Signature-Input's cert-url
    MalformedCert,      // the fetched cert bytes don't parse as DER/X.509
    UntrustedCert,      // the leaf cert doesn't chain to tinybrowse's pinned root
    BadSignature,       // the signature doesn't verify against the leaf's public key
};

// Human-readable, for diagnostics/REPL banners.
const char* verify_result_message(VerifyResult result);

// Verifies that `page` (as returned by net::fetch) is a signed page. Signing
// is opt-in: a page with no Content-Digest header at all is NotSigned, not
// a failure -- tinybrowse's fail-closed policy (browser.cpp) only kicks in
// once a page *attempts* to present a signature. Checks, in order:
//   1. its Content-Digest header matches a fresh SHA-256 of its actual body
//   2. a leaf certificate, fetched from the URL named by Signature-Input's
//      cert-url parameter, chains to tinybrowse's pinned root
//      (sign::load_trust_anchor)
//   3. the Signature header's value verifies as an ECDSA-P256 signature,
//      by that leaf's public key, over the page body's raw SHA-256 digest
//
// This is a deliberately narrow, non-general subset of RFC 9421 (HTTP
// Message Signatures) and RFC 9530 (Content-Digest): the header shapes are
// fixed --
//   Content-Digest: sha-256=:<base64 digest>:
//   Signature-Input: sig1=("content-digest");cert-url="<url>"
//   Signature: sig1=:<base64 DER ECDSA signature>:
// -- and the signed value is the body's raw digest, not RFC 9421's full
// canonical signature-base construction. Fetching the cert is a second,
// unauthenticated net::fetch; only the cert's signature chain (checked
// against the pinned root) establishes trust, not how it was transported.
VerifyResult verify_signature(const net::FetchResult& page);

}  // namespace sign
