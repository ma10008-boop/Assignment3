#pragma once

#include <string>

namespace sign {

// Computes RFC 9530's Content-Digest header value for `body` using
// SHA-256: "sha-256=:<base64 of the raw 32-byte digest>:". Used both to
// state a page's digest when signing it and, on the receiving end, to
// recompute and compare against what a page's headers claim -- a cheap
// check that runs before any certificate/signature verification.
std::string compute_content_digest(const std::string& body);

}  // namespace sign
