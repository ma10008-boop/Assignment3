#!/usr/bin/env bash
# INSTRUCTOR-ONLY: (re)generates generated/mbedtls_sandbox.c and .h -- the
# wasm2c output that IS the compiled, sandboxed mbedtls (with the planted
# ecdsa.c bug) plus tinybrowse_sandbox_helpers.c. Students never run this;
# they build directly against the checked-in generated/ output with their
# ordinary clang-14, matching every other target in this repo. Requires the
# wasiclang + wasm2c toolchain built once via `cmake -S tools/rlbox_wasm2c_sandbox
# -B tools/rlbox_wasm2c_sandbox/build` (see that directory's own build).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
MBEDTLS_DIR="$REPO_ROOT/third_party/mbedtls"
CONFIG_FILE="$REPO_ROOT/src/sign/mbedtls_config_tinybrowse.h"
OUT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GEN_DIR="$OUT_DIR/generated"
RLBOX_W2C="$REPO_ROOT/tools/rlbox_wasm2c_sandbox"

WASICLANG_DIR="$RLBOX_W2C/build/_deps/wasiclang-src"
WASM2C="$RLBOX_W2C/build/_deps/wasm2c_compiler-src/bin/wasm2c"
WRAPPER="$RLBOX_W2C/c_src/wasm2c_sandbox_wrapper.c"

MODULE_NAME="mbedtls_sandbox"
mkdir -p "$GEN_DIR"
WASM_OUT="$GEN_DIR/${MODULE_NAME}.wasm"
C_OUT="$GEN_DIR/${MODULE_NAME}.c"

SOURCES=(
    asn1parse.c asn1write.c bignum.c bignum_core.c constant_time.c
    ecdsa.c ecp.c ecp_curves.c ecp_curves_new.c error.c md.c oid.c
    pk.c pk_ecc.c pk_wrap.c pkparse.c platform.c platform_util.c
    sha256.c version.c version_features.c x509.c x509_crt.c
)
SRC_PATHS=("$OUT_DIR/tinybrowse_sandbox_helpers.c" "$WRAPPER")
for f in "${SOURCES[@]}"; do
    SRC_PATHS+=("$MBEDTLS_DIR/library/$f")
done

echo "=== compiling mbedtls (+ planted bug, + tinybrowse accessor) to wasm ==="
"$WASICLANG_DIR/bin/clang" \
    --sysroot "$WASICLANG_DIR/share/wasi-sysroot/" \
    -O3 \
    "-DMBEDTLS_CONFIG_FILE=\"$CONFIG_FILE\"" \
    -I "$MBEDTLS_DIR/include" -I "$MBEDTLS_DIR/library" \
    -w \
    -Wl,--export-all -Wl,--no-entry -Wl,--growable-table -Wl,--stack-first \
    -Wl,-z,stack-size=1048576 -Wl,--export-table \
    -o "$WASM_OUT" \
    "${SRC_PATHS[@]}"

echo "=== running wasm2c (module name: $MODULE_NAME) ==="
"$WASM2C" -o "$C_OUT" "$WASM_OUT"

rm -f "$WASM_OUT"
echo "done: $C_OUT (+ $GEN_DIR/${MODULE_NAME}.h) -- these are what get checked in."
