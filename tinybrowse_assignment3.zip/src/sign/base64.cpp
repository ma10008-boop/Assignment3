#include "sign/base64.h"

namespace sign {

namespace {

const char kAlphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

// -1 for characters outside the base64 alphabet, built once on first use.
const int8_t* decode_table() {
    static int8_t table[256];
    static bool initialized = false;
    if (!initialized) {
        for (int i = 0; i < 256; ++i) {
            table[i] = -1;
        }
        for (int i = 0; i < 64; ++i) {
            table[static_cast<unsigned char>(kAlphabet[i])] = static_cast<int8_t>(i);
        }
        initialized = true;
    }
    return table;
}

}  // namespace

std::string base64_encode(const std::string& data) {
    std::string out;
    out.reserve(((data.size() + 2) / 3) * 4);

    size_t i = 0;
    while (i + 3 <= data.size()) {
        unsigned int n = (static_cast<unsigned char>(data[i]) << 16) |
                         (static_cast<unsigned char>(data[i + 1]) << 8) |
                         static_cast<unsigned char>(data[i + 2]);
        out += kAlphabet[(n >> 18) & 0x3f];
        out += kAlphabet[(n >> 12) & 0x3f];
        out += kAlphabet[(n >> 6) & 0x3f];
        out += kAlphabet[n & 0x3f];
        i += 3;
    }

    size_t remaining = data.size() - i;
    if (remaining == 1) {
        unsigned int n = static_cast<unsigned char>(data[i]) << 16;
        out += kAlphabet[(n >> 18) & 0x3f];
        out += kAlphabet[(n >> 12) & 0x3f];
        out += "==";
    } else if (remaining == 2) {
        unsigned int n =
            (static_cast<unsigned char>(data[i]) << 16) | (static_cast<unsigned char>(data[i + 1]) << 8);
        out += kAlphabet[(n >> 18) & 0x3f];
        out += kAlphabet[(n >> 12) & 0x3f];
        out += kAlphabet[(n >> 6) & 0x3f];
        out += '=';
    }
    return out;
}

bool base64_decode(const std::string& input, std::string* out) {
    if (input.empty()) {
        *out = "";
        return true;
    }
    if (input.size() % 4 != 0) {
        return false;
    }

    // Strip up to two trailing '=' as padding, then require every
    // remaining character to be a real alphabet character -- a '=' any
    // earlier (too many padding characters, or padding in the middle) is
    // rejected below rather than silently absorbed.
    size_t data_len = input.size();
    int pad = 0;
    while (pad < 2 && data_len > 0 && input[data_len - 1] == '=') {
        --data_len;
        ++pad;
    }

    const int8_t* table = decode_table();
    std::string result;
    result.reserve((data_len / 4) * 3 + 3);

    unsigned int buffer = 0;
    int bits = 0;
    for (size_t i = 0; i < data_len; ++i) {
        int v = table[static_cast<unsigned char>(input[i])];
        if (v < 0) {
            return false;
        }
        buffer = (buffer << 6) | static_cast<unsigned int>(v);
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            result += static_cast<char>((buffer >> bits) & 0xff);
        }
    }

    *out = std::move(result);
    return true;
}

}  // namespace sign
