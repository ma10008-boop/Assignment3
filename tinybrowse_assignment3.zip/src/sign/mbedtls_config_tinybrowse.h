/**
 * tinybrowse's trimmed mbedTLS config for the signed-page feature.
 *
 * Deliberately narrow: X.509 cert parsing/verification and ECDSA-P256
 * signature checking only -- no TLS record layer, no RSA, no entropy/RNG
 * (verification needs none), no PEM (pages carry DER directly). See
 * docs/ARCHITECTURE.md's networking section for why tinybrowse has no TLS
 * dependency at the transport layer either; this is a separate,
 * application-level signature check on top of plain HTTP.
 *
 * This file fully replaces upstream's include/mbedtls/mbedtls_config.h (via
 * -DMBEDTLS_CONFIG_FILE) rather than being layered on top of it, so nothing
 * outside this file decides what's enabled.
 */
#ifndef TINYBROWSE_MBEDTLS_CONFIG_H
#define TINYBROWSE_MBEDTLS_CONFIG_H

#define MBEDTLS_PLATFORM_C

/* ASN.1 / OID: DER parsing plumbing shared by x509 and pk. ASN1_WRITE_C is
 * needed even though this is verify-only -- ECDSA signatures are
 * themselves a DER SEQUENCE{r,s}, and mbedtls_ecdsa_read_signature builds
 * one internally to compare against. */
#define MBEDTLS_ASN1_PARSE_C
#define MBEDTLS_ASN1_WRITE_C
#define MBEDTLS_OID_C

/* Bignum + EC: the math ECDSA-P256 verification is built on. */
#define MBEDTLS_BIGNUM_C
#define MBEDTLS_ECP_C
#define MBEDTLS_ECP_DP_SECP256R1_ENABLED
#define MBEDTLS_ECDSA_C

/* PK: the algorithm-agnostic public-key wrapper x509 verification uses to
 * check a certificate's signature and to expose the leaf's public key. */
#define MBEDTLS_PK_C
#define MBEDTLS_PK_PARSE_C

/* Hashing: SHA-256 is the only digest ECDSA-P256 needs here. */
#define MBEDTLS_MD_C
#define MBEDTLS_SHA256_C

/* X.509: certificate parsing and chain-to-trust-anchor verification. */
#define MBEDTLS_X509_USE_C
#define MBEDTLS_X509_CRT_PARSE_C

/* Human-readable error strings for diagnostics (mbedtls_strerror). */
#define MBEDTLS_ERROR_C
#define MBEDTLS_VERSION_C

#endif /* TINYBROWSE_MBEDTLS_CONFIG_H */
