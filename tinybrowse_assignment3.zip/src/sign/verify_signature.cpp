#include "sign/verify_signature.h"

#include "mbedtls/pk.h"
#include "mbedtls/sha256.h"
#include "mbedtls/x509_crt.h"
#include "net/http_client.h"
#include "sign/base64.h"
#include "sign/content_digest.h"
#include "sign/trust_anchor.h"

namespace sign {

namespace {

// Expects exactly: sig1=("content-digest");cert-url="<url>"[;other=params
// ignored]. A minimal subset -- not a general RFC 8941 structured-field
// parser: the covered-components list must be exactly ("content-digest")
// and the label must be exactly "sig1".
bool parse_signature_input(const std::string& header_value, std::string* cert_url) {
    const std::string prefix = "sig1=(\"content-digest\")";
    if (header_value.compare(0, prefix.size(), prefix) != 0) {
        return false;
    }

    size_t pos = prefix.size();
    bool found_cert_url = false;
    while (pos < header_value.size()) {
        if (header_value[pos] != ';') {
            return false;
        }
        ++pos;
        size_t eq = header_value.find('=', pos);
        if (eq == std::string::npos) {
            return false;
        }
        std::string key = header_value.substr(pos, eq - pos);
        if (eq + 1 >= header_value.size() || header_value[eq + 1] != '"') {
            return false;
        }
        size_t value_start = eq + 2;
        size_t value_end = header_value.find('"', value_start);
        if (value_end == std::string::npos) {
            return false;
        }
        if (key == "cert-url") {
            *cert_url = header_value.substr(value_start, value_end - value_start);
            found_cert_url = true;
        }
        pos = value_end + 1;
    }
    return found_cert_url;
}

// Expects exactly: sig1=:<base64>:
bool parse_signature_header(const std::string& header_value, std::string* raw_signature) {
    const std::string prefix = "sig1=:";
    if (header_value.size() < prefix.size() + 1 || header_value.compare(0, prefix.size(), prefix) != 0 ||
        header_value.back() != ':') {
        return false;
    }
    std::string encoded = header_value.substr(prefix.size(), header_value.size() - prefix.size() - 1);
    return base64_decode(encoded, raw_signature);
}

bool header(const net::FetchResult& page, const char* name, std::string* out) {
    auto it = page.headers.find(name);
    if (it == page.headers.end()) {
        return false;
    }
    *out = it->second;
    return true;
}

}  // namespace

const char* verify_result_message(VerifyResult result) {
    switch (result) {
        case VerifyResult::Ok:
            return "signature valid";
        case VerifyResult::NotSigned:
            return "not a signed page";
        case VerifyResult::MalformedHeaders:
            return "missing or malformed signature headers";
        case VerifyResult::DigestMismatch:
            return "Content-Digest does not match the page body";
        case VerifyResult::CertFetchFailed:
            return "could not fetch the signing certificate";
        case VerifyResult::MalformedCert:
            return "signing certificate is not a valid DER certificate";
        case VerifyResult::UntrustedCert:
            return "signing certificate does not chain to the pinned root";
        case VerifyResult::BadSignature:
            return "signature does not verify against the signing certificate";
    }
    return "unknown signature verification result";
}

VerifyResult verify_signature(const net::FetchResult& page) {
    std::string content_digest;
    if (!header(page, "content-digest", &content_digest)) {
        return VerifyResult::NotSigned;
    }
    if (content_digest != compute_content_digest(page.body)) {
        return VerifyResult::DigestMismatch;
    }

    std::string signature_input;
    std::string cert_url;
    if (!header(page, "signature-input", &signature_input) ||
        !parse_signature_input(signature_input, &cert_url)) {
        return VerifyResult::MalformedHeaders;
    }

    std::string signature_header;
    std::string raw_signature;
    if (!header(page, "signature", &signature_header) ||
        !parse_signature_header(signature_header, &raw_signature)) {
        return VerifyResult::MalformedHeaders;
    }

    net::FetchResult cert_fetch = net::fetch(cert_url);
    if (!cert_fetch.ok || cert_fetch.status_code >= 400) {
        return VerifyResult::CertFetchFailed;
    }

    mbedtls_x509_crt leaf;
    mbedtls_x509_crt_init(&leaf);
    if (mbedtls_x509_crt_parse_der(&leaf, reinterpret_cast<const unsigned char*>(cert_fetch.body.data()),
                                    cert_fetch.body.size()) != 0) {
        mbedtls_x509_crt_free(&leaf);
        return VerifyResult::MalformedCert;
    }

    mbedtls_x509_crt root;
    mbedtls_x509_crt_init(&root);
    if (load_trust_anchor(&root) != 0) {
        mbedtls_x509_crt_free(&root);
        mbedtls_x509_crt_free(&leaf);
        return VerifyResult::UntrustedCert;
    }

    uint32_t flags = 0;
    if (mbedtls_x509_crt_verify(&leaf, &root, nullptr, nullptr, &flags, nullptr, nullptr) != 0 ||
        flags != 0) {
        mbedtls_x509_crt_free(&root);
        mbedtls_x509_crt_free(&leaf);
        return VerifyResult::UntrustedCert;
    }

    unsigned char digest[32];
    mbedtls_sha256(reinterpret_cast<const unsigned char*>(page.body.data()), page.body.size(), digest,
                   /*is224=*/0);

    VerifyResult result = VerifyResult::Ok;
    if (mbedtls_pk_verify(&leaf.pk, MBEDTLS_MD_SHA256, digest, sizeof(digest),
                           reinterpret_cast<const unsigned char*>(raw_signature.data()),
                           raw_signature.size()) != 0) {
        result = VerifyResult::BadSignature;
    }

    mbedtls_x509_crt_free(&root);
    mbedtls_x509_crt_free(&leaf);
    return result;
}

}  // namespace sign
