#pragma once

#include <string>

namespace sign {

// Standard base64 (RFC 4648 section 4, with '=' padding) -- this is what
// RFC 9421's structured-field "Byte Sequence" values use inside their
// surrounding ':' delimiters (e.g. a Signature header's
// "sig1=:base64here:"). Encoding/decoding those delimiters themselves is
// the caller's job; these two functions only handle the base64 payload.
std::string base64_encode(const std::string& data);

// Returns false -- leaving *out unspecified -- if `input` isn't valid
// base64: wrong length, a character outside the base64 alphabet, or a '='
// anywhere other than the last one or two characters.
bool base64_decode(const std::string& input, std::string* out);

}  // namespace sign
