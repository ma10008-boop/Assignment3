#include "browser/browser.h"

#include <cstdio>
#include <fstream>
#include <sstream>
#include <vector>

#include "net/http_client.h"
#include "render/layout.h"
#include "render/terminal.h"
#include "sign/verify_signature.h"
#include "tinyhtml/dom.h"
#include "tinyhtml/parser.h"
#include "tinyscript/ast.h"
#include "tinyscript/dom_api.h"
#include "tinyscript/interpreter.h"
#include "tinyscript/parser.h"
#include "tinyscript/typecheck.h"

namespace browser {

SignatureCheck check_signature(const net::FetchResult& result) {
    sign::VerifyResult verify = sign::verify_signature(result);
    if (verify == sign::VerifyResult::NotSigned) {
        return SignatureCheck{true, ""};
    }
    if (verify == sign::VerifyResult::Ok) {
        return SignatureCheck{true, "signature verified"};
    }
    return SignatureCheck{false, sign::verify_result_message(verify)};
}

bool read_file(const std::string& path, std::string& out) {
    std::ifstream file(path);
    if (!file) {
        return false;
    }
    std::ostringstream buffer;
    buffer << file.rdbuf();
    out = buffer.str();
    return true;
}

namespace {

const int kTerminalWidth = 80;

enum class Dialect { TinyScript, TypyScript };

void collect_script_elements(tinyhtml::Node* node, std::vector<tinyhtml::Node*>* out) {
    if (node == nullptr) {
        return;
    }
    if (node->type == tinyhtml::NodeType::Element && node->tag_name == "script") {
        out->push_back(node);
    }
    for (tinyhtml::Node* child = node->first_child; child != nullptr; child = child->next_sibling) {
        collect_script_elements(child, out);
    }
}

// docs/tinyhtml-spec.md section 2: `type` defaults to "tinyscript"
// when omitted (or set to anything other than exactly "typyscript").
std::string script_type_attr(tinyhtml::Node* script) {
    tinyhtml::Attribute* attr = tinyhtml::find_attribute(script, "type");
    return attr != nullptr ? attr->value : "tinyscript";
}

// docs/typyscript-spec.md section 4: the document's dialect is
// fixed by the first <script> tag encountered.
Dialect document_dialect(const std::vector<tinyhtml::Node*>& scripts) {
    if (scripts.empty()) {
        return Dialect::TinyScript;  // no scripts at all; the choice is moot
    }
    return script_type_attr(scripts.front()) == "typyscript" ? Dialect::TypyScript
                                                              : Dialect::TinyScript;
}

}  // namespace

std::vector<tinyscript::Diagnostic> run_scripts(tinyhtml::Node* document) {
    std::vector<tinyhtml::Node*> script_elements;
    collect_script_elements(document, &script_elements);
    if (script_elements.empty()) {
        return {};
    }

    Dialect dialect = document_dialect(script_elements);
    std::vector<tinyscript::Diagnostic> diags;
    std::vector<tinyscript::Program> programs;
    programs.reserve(script_elements.size());

    for (tinyhtml::Node* script : script_elements) {
        std::string source;
        if (script->first_child != nullptr && script->first_child->type == tinyhtml::NodeType::Text) {
            source = script->first_child->text;
        }
        tinyscript::ParseResult result = tinyscript::parse(source);
        for (const tinyscript::Diagnostic& d : result.diagnostics) {
            diags.push_back(d);
        }
        programs.push_back(std::move(result.program));

        // Mixed dialects are only meaningful for a typyscript document
        // (docs/typyscript-spec.md section 4) -- tinyscript has no
        // notion of rejecting a document at all, so a stray `type`
        // elsewhere is simply ignored when the document itself is
        // tinyscript.
        if (dialect == Dialect::TypyScript && script_type_attr(script) != "typyscript") {
            diags.push_back(tinyscript::Diagnostic{
                "script block's 'type' disagrees with the document's typyscript dialect "
                "(fixed by the first <script> tag)",
                0});
        }
    }

    tinyscript::Interpreter interp;
    tinyscript::register_dom_api(interp, document);

    bool should_run = true;
    if (dialect == Dialect::TypyScript) {
        std::vector<tinyscript::Program*> blocks;
        blocks.reserve(programs.size());
        for (tinyscript::Program& p : programs) {
            blocks.push_back(&p);
        }
        std::vector<tinyscript::Diagnostic> check_diags;
        tinyscript::typecheck_document(blocks, nullptr, &check_diags);
        for (const tinyscript::Diagnostic& d : check_diags) {
            diags.push_back(d);
        }
        // All-or-nothing (docs/typyscript-spec.md section 4): a
        // parse error, a dialect mismatch, or any checker diagnostic all
        // count as "does not type-check" -- nothing in the document runs,
        // though the document itself still renders further down.
        should_run = diags.empty();
    }

    if (should_run) {
        for (tinyscript::Program& p : programs) {
            tinyscript::collect_functions(interp, p);
        }
        for (tinyscript::Program& p : programs) {
            tinyscript::execute_program(interp, p, &diags);
        }
    }

    tinyscript::free_scope(interp.globals);
    for (tinyscript::Program& p : programs) {
        tinyscript::free_program(p);
    }

    return diags;
}

render::LayoutResult render_document_source(const std::string& source) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(source);
    for (const tinyhtml::Diagnostic& diag : parsed.diagnostics) {
        std::fprintf(stderr, "tinyhtml: line %d: %s\n", diag.line, diag.message.c_str());
    }

    for (const tinyscript::Diagnostic& diag : run_scripts(parsed.document)) {
        std::fprintf(stderr, "tinyscript: line %d: %s\n", diag.line, diag.message.c_str());
    }

    render::LayoutResult result = render::layout(parsed.document, kTerminalWidth);
    tinyhtml::free_node(parsed.document);
    return result;
}

int load_and_render(const std::string& path) {
    std::string source;
    if (!read_file(path, source)) {
        std::fprintf(stderr, "tinybrowse: could not read '%s'\n", path.c_str());
        return 1;
    }
    render::print_to_terminal(render_document_source(source).lines);
    return 0;
}

int load_and_render_url(const std::string& url) {
    net::FetchResult result = net::fetch(url);
    if (!result.ok) {
        std::fprintf(stderr, "tinybrowse: could not fetch '%s': %s\n", url.c_str(), result.error.c_str());
        return 1;
    }
    if (result.status_code >= 400) {
        std::fprintf(stderr, "tinybrowse: '%s' returned HTTP %d\n", url.c_str(), result.status_code);
    }

    SignatureCheck sig = check_signature(result);
    if (!sig.ok) {
        std::fprintf(stderr, "tinybrowse: refusing to render '%s': %s\n", url.c_str(), sig.message.c_str());
        return 1;
    }
    if (!sig.message.empty()) {
        std::fprintf(stderr, "tinybrowse: '%s': %s\n", url.c_str(), sig.message.c_str());
    }

    render::print_to_terminal(render_document_source(result.body).lines);
    return 0;
}

}  // namespace browser
