#include "browser/repl.h"

#include <cctype>
#include <vector>

#include "browser/browser.h"
#include "net/http_client.h"
#include "net/url.h"
#include "render/terminal.h"

namespace browser {

namespace {

bool is_absolute_http_url(const std::string& s) {
    const std::string scheme = "http://";
    if (s.size() < scheme.size()) {
        return false;
    }
    for (size_t i = 0; i < scheme.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(s[i])) != scheme[i]) {
            return false;
        }
    }
    return true;
}

// True if `href` has some scheme prefix other than "http://" -- a literal
// ':' before the first '/' ("https:", "mailto:", "javascript:", ...).
// Mirrors net::url.cpp's identical check for the same reason there.
bool has_other_scheme(const std::string& href) {
    size_t colon = href.find(':');
    size_t slash = href.find('/');
    return colon != std::string::npos && (slash == std::string::npos || colon < slash);
}

// Joins path segments and collapses "." / ".." (clamped at the root, like
// net::resolve_url's identical collapse for URL paths -- duplicated here
// rather than shared since one produces a bare filesystem path and the
// other a full URL with a host).
std::string normalize_path(const std::string& combined) {
    bool absolute = !combined.empty() && combined[0] == '/';
    std::vector<std::string> stack;
    size_t pos = 0;
    while (pos <= combined.size()) {
        size_t next = combined.find('/', pos);
        std::string segment = combined.substr(pos, next == std::string::npos ? std::string::npos : next - pos);
        if (segment == "..") {
            if (!stack.empty()) {
                stack.pop_back();
            }
        } else if (!segment.empty() && segment != ".") {
            stack.push_back(segment);
        }
        if (next == std::string::npos) {
            break;
        }
        pos = next + 1;
    }
    if (stack.empty()) {
        return absolute ? "/" : ".";
    }
    std::string result;
    for (size_t i = 0; i < stack.size(); ++i) {
        if (i > 0 || absolute) {
            result += '/';
        }
        result += stack[i];
    }
    return result;
}

bool resolve_from_file(const std::string& base_path, const std::string& href, Location* out) {
    if (is_absolute_http_url(href)) {
        out->kind = LocationKind::Url;
        out->value = "http://" + href.substr(std::string("http://").size());  // normalize scheme casing
        return true;
    }
    if (has_other_scheme(href)) {
        return false;
    }

    std::string combined;
    if (!href.empty() && href[0] == '/') {
        combined = href;
    } else {
        size_t slash = base_path.rfind('/');
        std::string dir = slash == std::string::npos ? "" : base_path.substr(0, slash + 1);
        combined = dir + href;
    }
    out->kind = LocationKind::File;
    out->value = normalize_path(combined);
    return true;
}

bool resolve_location(const Location& current, const std::string& href, Location* out) {
    if (current.kind == LocationKind::Url) {
        std::string resolved;
        if (!net::resolve_url(current.value, href, &resolved)) {
            return false;
        }
        out->kind = LocationKind::Url;
        out->value = resolved;
        return true;
    }
    return resolve_from_file(current.value, href, out);
}

// Loads and lays out `loc`. On failure, prints an explanatory message to
// `out` and returns false -- the caller is expected to keep whatever page
// (and history) it already had.
bool load_location(const Location& loc, std::ostream& out, render::LayoutResult* result) {
    std::string source;
    if (loc.kind == LocationKind::File) {
        if (!read_file(loc.value, source)) {
            out << "tinybrowse: could not read '" << loc.value << "'\n";
            return false;
        }
    } else {
        net::FetchResult fetch_result = net::fetch(loc.value);
        if (!fetch_result.ok) {
            out << "tinybrowse: could not fetch '" << loc.value << "': " << fetch_result.error << "\n";
            return false;
        }
        if (fetch_result.status_code >= 400) {
            out << "tinybrowse: '" << loc.value << "' returned HTTP " << fetch_result.status_code << "\n";
        }
        SignatureCheck sig = check_signature(fetch_result);
        if (!sig.ok) {
            out << "tinybrowse: refusing to render '" << loc.value << "': " << sig.message << "\n";
            return false;
        }
        if (!sig.message.empty()) {
            out << "tinybrowse: '" << loc.value << "': " << sig.message << "\n";
        }
        source = fetch_result.body;
    }
    *result = render_document_source(source);
    return true;
}

// Manual bounded parse (no std::stoul) so a pasted huge or garbage number
// can't throw std::out_of_range through this loop -- mirrors net/url.cpp's
// parse_port for the same reason.
bool parse_link_number(const std::string& s, size_t* out) {
    if (s.empty()) {
        return false;
    }
    size_t value = 0;
    for (char c : s) {
        if (!std::isdigit(static_cast<unsigned char>(c))) {
            return false;
        }
        value = value * 10 + static_cast<size_t>(c - '0');
        if (value > 1000000) {
            return false;  // far more links than any real page will ever have
        }
    }
    *out = value;
    return true;
}

}  // namespace

int run_repl(const Location& start, std::istream& in, std::ostream& out) {
    Location current = start;
    std::vector<Location> history;

    render::LayoutResult page;
    if (!load_location(current, out, &page)) {
        return 1;
    }
    render::print_to_terminal(page.lines, out);

    std::string line;
    for (;;) {
        out << "> ";
        if (!std::getline(in, line)) {
            out << '\n';
            return 0;
        }
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }

        if (line == "q" || line == "quit") {
            return 0;
        }

        if (line == "b" || line == "back") {
            if (history.empty()) {
                out << "tinybrowse: no previous page\n";
                continue;
            }
            Location previous = history.back();
            render::LayoutResult new_page;
            if (!load_location(previous, out, &new_page)) {
                continue;
            }
            history.pop_back();
            current = previous;
            page = std::move(new_page);
            render::print_to_terminal(page.lines, out);
            continue;
        }

        size_t number = 0;
        if (!parse_link_number(line, &number)) {
            out << "tinybrowse: unrecognized command '" << line << "'\n";
            continue;
        }
        if (number == 0 || number > page.links.size()) {
            out << "tinybrowse: no such link [" << line << "]\n";
            continue;
        }

        Location next;
        if (!resolve_location(current, page.links[number - 1], &next)) {
            out << "tinybrowse: cannot follow link [" << line << "] (unsupported scheme)\n";
            continue;
        }
        render::LayoutResult new_page;
        if (!load_location(next, out, &new_page)) {
            continue;
        }
        history.push_back(current);
        current = next;
        page = std::move(new_page);
        render::print_to_terminal(page.lines, out);
    }
}

int browse_file(const std::string& path) { return run_repl(Location{LocationKind::File, path}, std::cin, std::cout); }

int browse_url(const std::string& url) { return run_repl(Location{LocationKind::Url, url}, std::cin, std::cout); }

}  // namespace browser
