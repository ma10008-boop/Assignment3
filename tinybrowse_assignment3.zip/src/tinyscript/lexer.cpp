#include "tinyscript/lexer.h"

#include <cctype>
#include <cstdlib>
#include <unordered_map>

namespace tinyscript {

namespace {

const std::unordered_map<std::string, TokenType> kKeywords = {
    {"let", TokenType::Let},     {"fn", TokenType::Fn},         {"if", TokenType::If},
    {"else", TokenType::Else},   {"while", TokenType::While},   {"return", TokenType::Return},
    {"true", TokenType::True},   {"false", TokenType::False},   {"as", TokenType::As},
};

const std::unordered_map<std::string, NumKind> kNumericSuffixes = {
    {"u8", NumKind::U8}, {"u32", NumKind::U32}, {"u64", NumKind::U64}, {"i8", NumKind::I8},
    {"i32", NumKind::I32}, {"i64", NumKind::I64}, {"f32", NumKind::F32}, {"f64", NumKind::F64},
};

bool is_float_kind(NumKind k) { return k == NumKind::F32 || k == NumKind::F64; }
bool is_ident_start(char c) { return std::isalpha(static_cast<unsigned char>(c)) != 0 || c == '_'; }
bool is_ident_char(char c) { return std::isalnum(static_cast<unsigned char>(c)) != 0 || c == '_'; }

// Single-pass tokenizer; see tinyhtml/lexer.cpp for the same overall shape
// (a plain struct with methods, not a class hierarchy).
struct Lexer {
    const std::string& source;
    size_t pos = 0;
    int line = 1;
    std::vector<Token> tokens;

    explicit Lexer(const std::string& src) : source(src) {}

    char peek(size_t offset = 0) const {
        size_t i = pos + offset;
        return i < source.size() ? source[i] : '\0';
    }
    char advance() {
        char c = source[pos++];
        if (c == '\n') {
            ++line;
        }
        return c;
    }
    bool at_end() const { return pos >= source.size(); }

    void skip_whitespace_and_comments() {
        for (;;) {
            if (!at_end() && std::isspace(static_cast<unsigned char>(peek()))) {
                advance();
            } else if (peek() == '/' && peek(1) == '/') {
                while (!at_end() && peek() != '\n') {
                    advance();
                }
            } else {
                break;
            }
        }
    }

    void push(TokenType type, int tok_line, std::string text = "") {
        tokens.push_back(Token{type, std::move(text), 0, NumKind::I32, false, tok_line});
    }

    void lex_ident_or_keyword() {
        int start_line = line;
        std::string text;
        while (!at_end() && is_ident_char(peek())) {
            text.push_back(advance());
        }
        auto it = kKeywords.find(text);
        if (it != kKeywords.end()) {
            push(it->second, start_line);
        } else {
            push(TokenType::Ident, start_line, text);
        }
    }

    // NUMBER ::= INT_LITERAL | DECIMAL_LITERAL, each with an optional kind
    // suffix (docs/tinyscript-spec.md section 1).
    void lex_number() {
        int start_line = line;
        size_t value_start = pos;
        while (!at_end() && std::isdigit(static_cast<unsigned char>(peek()))) {
            advance();
        }

        bool is_decimal = false;
        if (peek() == '.' && std::isdigit(static_cast<unsigned char>(peek(1)))) {
            is_decimal = true;
            advance();  // '.'
            while (!at_end() && std::isdigit(static_cast<unsigned char>(peek()))) {
                advance();
            }
        }
        std::string digits = source.substr(value_start, pos - value_start);

        // Look ahead (without committing) for a suffix: a run of ident
        // characters immediately following the digits.
        size_t suffix_len = 0;
        while (is_ident_char(peek(suffix_len))) {
            ++suffix_len;
        }

        NumKind kind = is_decimal ? NumKind::F32 : NumKind::I32;
        bool explicit_suffix = false;
        if (suffix_len > 0) {
            std::string suffix_text = source.substr(pos, suffix_len);
            auto it = kNumericSuffixes.find(suffix_text);
            if (it != kNumericSuffixes.end() && (!is_decimal || is_float_kind(it->second))) {
                for (size_t i = 0; i < suffix_len; ++i) {
                    advance();  // now actually consume it
                }
                kind = it->second;
                explicit_suffix = true;
            }
            // Otherwise: not a valid suffix for this literal (unrecognized,
            // or an integer suffix on a decimal literal) -- leave it
            // unconsumed. It becomes its own token next (almost certainly
            // an Ident), which the parser will reject as a syntax error --
            // that diagnosis belongs there, not in the lexer.
        }

        Token tok;
        tok.type = TokenType::Number;
        tok.number = std::strtod(digits.c_str(), nullptr);
        tok.number_kind = kind;
        tok.number_kind_explicit = explicit_suffix;
        tok.line = start_line;
        tokens.push_back(tok);
    }

    // STRING has backslash escapes (\n \t \\ \"), unlike tinyhtml's
    // attribute strings -- see docs/tinyscript-spec.md section 1.
    void lex_string() {
        int start_line = line;
        advance();  // opening '"'
        std::string value;
        while (!at_end() && peek() != '"' && peek() != '\n') {
            char c = advance();
            if (c != '\\' || at_end()) {
                value.push_back(c);
                continue;
            }
            char esc = advance();
            switch (esc) {
                case 'n':
                    value.push_back('\n');
                    break;
                case 't':
                    value.push_back('\t');
                    break;
                case '\\':
                    value.push_back('\\');
                    break;
                case '"':
                    value.push_back('"');
                    break;
                default:
                    // Unrecognized escape: pass both characters through
                    // literally rather than erroring -- keeps the lexer total.
                    value.push_back('\\');
                    value.push_back(esc);
                    break;
            }
        }
        if (peek() == '"') {
            advance();  // closing quote; if missing (EOF/newline), the string
                        // just ends early -- no infinite loop either way
        }
        push(TokenType::String, start_line, value);
    }
};

}  // namespace

std::vector<Token> lex(const std::string& source) {
    Lexer lexer(source);

    while (true) {
        lexer.skip_whitespace_and_comments();
        if (lexer.at_end()) {
            break;
        }

        char c = lexer.peek();
        int line = lexer.line;

        if (is_ident_start(c)) {
            lexer.lex_ident_or_keyword();
            continue;
        }
        if (std::isdigit(static_cast<unsigned char>(c))) {
            lexer.lex_number();
            continue;
        }
        if (c == '"') {
            lexer.lex_string();
            continue;
        }

        switch (c) {
            case '+':
                lexer.advance();
                lexer.push(TokenType::Plus, line);
                continue;
            case '-':
                lexer.advance();
                if (lexer.peek() == '>') {
                    lexer.advance();
                    lexer.push(TokenType::Arrow, line);
                } else {
                    lexer.push(TokenType::Minus, line);
                }
                continue;
            case '*':
                lexer.advance();
                lexer.push(TokenType::Star, line);
                continue;
            case '/':
                lexer.advance();
                lexer.push(TokenType::Slash, line);
                continue;
            case '%':
                lexer.advance();
                lexer.push(TokenType::Percent, line);
                continue;
            case '=':
                lexer.advance();
                if (lexer.peek() == '=') {
                    lexer.advance();
                    lexer.push(TokenType::EqualEqual, line);
                } else {
                    lexer.push(TokenType::Equal, line);
                }
                continue;
            case '!':
                lexer.advance();
                if (lexer.peek() == '=') {
                    lexer.advance();
                    lexer.push(TokenType::BangEqual, line);
                } else {
                    lexer.push(TokenType::Bang, line);
                }
                continue;
            case '<':
                lexer.advance();
                if (lexer.peek() == '=') {
                    lexer.advance();
                    lexer.push(TokenType::LessEqual, line);
                } else {
                    lexer.push(TokenType::Less, line);
                }
                continue;
            case '>':
                lexer.advance();
                if (lexer.peek() == '=') {
                    lexer.advance();
                    lexer.push(TokenType::GreaterEqual, line);
                } else {
                    lexer.push(TokenType::Greater, line);
                }
                continue;
            case '&':
                lexer.advance();
                if (lexer.peek() == '&') {
                    lexer.advance();
                    lexer.push(TokenType::AmpAmp, line);
                }
                // A lone '&' has no meaning in the grammar; dropped so the
                // lexer stays total. The parser will see the gap and
                // diagnose it via whatever comes next.
                continue;
            case '|':
                lexer.advance();
                if (lexer.peek() == '|') {
                    lexer.advance();
                    lexer.push(TokenType::PipePipe, line);
                }
                continue;
            case '(':
                lexer.advance();
                lexer.push(TokenType::LParen, line);
                continue;
            case ')':
                lexer.advance();
                lexer.push(TokenType::RParen, line);
                continue;
            case '{':
                lexer.advance();
                lexer.push(TokenType::LBrace, line);
                continue;
            case '}':
                lexer.advance();
                lexer.push(TokenType::RBrace, line);
                continue;
            case '[':
                lexer.advance();
                lexer.push(TokenType::LBracket, line);
                continue;
            case ']':
                lexer.advance();
                lexer.push(TokenType::RBracket, line);
                continue;
            case ',':
                lexer.advance();
                lexer.push(TokenType::Comma, line);
                continue;
            case ';':
                lexer.advance();
                lexer.push(TokenType::Semicolon, line);
                continue;
            case ':':
                lexer.advance();
                lexer.push(TokenType::Colon, line);
                continue;
            default:
                // Unrecognized character: skip it to guarantee forward
                // progress (never loop forever on adversarial input).
                lexer.advance();
                continue;
        }
    }

    lexer.tokens.push_back(Token{TokenType::EndOfFile, "", 0, NumKind::I32, false, lexer.line});
    return lexer.tokens;
}

}  // namespace tinyscript
