#pragma once

#include <cstdint>
#include <vector>

#include "tinyscript/diagnostic.h"

namespace tinyscript {

// The eight numeric kinds every tinyscript/typyscript number carries -- see
// docs/tinyscript-spec.md section 3 (Values). There is no generic
// "number": every numeric value is concretely one of these. Deliberately a
// separate enum from ValueType (tinyscript/value.h) and TypeKind
// (tinyscript/type.h) -- see docs/instructor/tinyscript-design-notes.md for
// why the three are kept distinct rather than collapsed into one.
enum class NumKind : uint8_t { U8, U32, U64, I8, I32, I64, F32, F64 };

// The result kind when two (possibly different) numeric kinds meet in a
// binary operator -- this *is* the table in docs/tinyscript-spec.md
// section 4, as literal data, not a derived rule.
extern const NumKind kPromotionTable[8][8];
NumKind promote_kind(NumKind a, NumKind b);

// Wrapping arithmetic for the six integer kinds: the result is computed
// modulo 2^n for an n-bit kind (docs/tinyscript-spec.md section 4,
// "Overflow and casts"). Native signed +/-/* overflow is undefined
// behavior in C++, so the signed versions are implemented via an unsigned
// round-trip rather than raw signed arithmetic -- see numeric.cpp.
uint8_t wrap_add_u8(uint8_t a, uint8_t b);
uint8_t wrap_sub_u8(uint8_t a, uint8_t b);
uint8_t wrap_mul_u8(uint8_t a, uint8_t b);
uint32_t wrap_add_u32(uint32_t a, uint32_t b);
uint32_t wrap_sub_u32(uint32_t a, uint32_t b);
uint32_t wrap_mul_u32(uint32_t a, uint32_t b);
uint64_t wrap_add_u64(uint64_t a, uint64_t b);
uint64_t wrap_sub_u64(uint64_t a, uint64_t b);
uint64_t wrap_mul_u64(uint64_t a, uint64_t b);
int8_t wrap_add_i8(int8_t a, int8_t b);
int8_t wrap_sub_i8(int8_t a, int8_t b);
int8_t wrap_mul_i8(int8_t a, int8_t b);
int32_t wrap_add_i32(int32_t a, int32_t b);
int32_t wrap_sub_i32(int32_t a, int32_t b);
int32_t wrap_mul_i32(int32_t a, int32_t b);
int64_t wrap_add_i64(int64_t a, int64_t b);
int64_t wrap_sub_i64(int64_t a, int64_t b);
int64_t wrap_mul_i64(int64_t a, int64_t b);

// Integer division/modulo. Division (native, signed or unsigned) by zero
// is itself undefined behavior in C++, so both are checked up front: a
// zero divisor records a Diagnostic at `line` and yields 0 rather than
// invoking the native UB. The signed versions additionally special-case
// the most-negative-value / -1 case (the one other way integer division
// can overflow), wrapping to the most negative value instead of invoking
// UB there either. `diags` must not be null.
uint8_t wrap_div_u8(uint8_t a, uint8_t b, int line, std::vector<Diagnostic>* diags);
uint8_t wrap_mod_u8(uint8_t a, uint8_t b, int line, std::vector<Diagnostic>* diags);
uint32_t wrap_div_u32(uint32_t a, uint32_t b, int line, std::vector<Diagnostic>* diags);
uint32_t wrap_mod_u32(uint32_t a, uint32_t b, int line, std::vector<Diagnostic>* diags);
uint64_t wrap_div_u64(uint64_t a, uint64_t b, int line, std::vector<Diagnostic>* diags);
uint64_t wrap_mod_u64(uint64_t a, uint64_t b, int line, std::vector<Diagnostic>* diags);
int8_t wrap_div_i8(int8_t a, int8_t b, int line, std::vector<Diagnostic>* diags);
int8_t wrap_mod_i8(int8_t a, int8_t b, int line, std::vector<Diagnostic>* diags);
int32_t wrap_div_i32(int32_t a, int32_t b, int line, std::vector<Diagnostic>* diags);
int32_t wrap_mod_i32(int32_t a, int32_t b, int line, std::vector<Diagnostic>* diags);
int64_t wrap_div_i64(int64_t a, int64_t b, int line, std::vector<Diagnostic>* diags);
int64_t wrap_mod_i64(int64_t a, int64_t b, int line, std::vector<Diagnostic>* diags);

}  // namespace tinyscript
