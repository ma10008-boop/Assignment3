#include "tinyscript/value.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <limits>

namespace tinyscript {

bool is_numeric_value(ValueType t) {
    switch (t) {
        case ValueType::U8:
        case ValueType::U32:
        case ValueType::U64:
        case ValueType::I8:
        case ValueType::I32:
        case ValueType::I64:
        case ValueType::F32:
        case ValueType::F64:
            return true;
        default:
            return false;
    }
}

NumKind numeric_kind_of(ValueType t) {
    switch (t) {
        case ValueType::U8:
            return NumKind::U8;
        case ValueType::U32:
            return NumKind::U32;
        case ValueType::U64:
            return NumKind::U64;
        case ValueType::I8:
            return NumKind::I8;
        case ValueType::I32:
            return NumKind::I32;
        case ValueType::I64:
            return NumKind::I64;
        case ValueType::F32:
            return NumKind::F32;
        default:
            return NumKind::F64;
    }
}

namespace {

bool is_float_kind(NumKind k) { return k == NumKind::F32 || k == NumKind::F64; }

// Exact for every kind except u64/i64 magnitudes beyond 2^53 -- a
// documented simplification (double's mantissa can't distinguish them).
double numeric_as_double(const Value& v) {
    switch (v.type) {
        case ValueType::U8:
            return static_cast<double>(v.u8_val);
        case ValueType::U32:
            return static_cast<double>(v.u32_val);
        case ValueType::U64:
            return static_cast<double>(v.u64_val);
        case ValueType::I8:
            return static_cast<double>(v.i8_val);
        case ValueType::I32:
            return static_cast<double>(v.i32_val);
        case ValueType::I64:
            return static_cast<double>(v.i64_val);
        case ValueType::F32:
            return static_cast<double>(v.f32_val);
        case ValueType::F64:
            return v.f64_val;
        default:
            return 0.0;
    }
}

// Sign/zero-extends `v`'s value to a 64-bit pattern, per its own kind's
// signedness -- equivalent to what a CPU does loading the value into a
// 64-bit register. Once extended this way, producing any integer target
// (wider, narrower, or reinterpreted) is just "mask to the target's
// width" -- see make_int_from_bits.
uint64_t extend_int_to_u64_bits(const Value& v) {
    switch (v.type) {
        case ValueType::U8:
            return static_cast<uint64_t>(v.u8_val);
        case ValueType::U32:
            return static_cast<uint64_t>(v.u32_val);
        case ValueType::U64:
            return v.u64_val;
        case ValueType::I8: {
            int64_t se = v.i8_val;  // widening signed->signed: well-defined, sign-extends
            uint64_t bits;
            std::memcpy(&bits, &se, sizeof(bits));
            return bits;
        }
        case ValueType::I32: {
            int64_t se = v.i32_val;
            uint64_t bits;
            std::memcpy(&bits, &se, sizeof(bits));
            return bits;
        }
        case ValueType::I64: {
            int64_t se = v.i64_val;
            uint64_t bits;
            std::memcpy(&bits, &se, sizeof(bits));
            return bits;
        }
        default:
            return 0;
    }
}

Value make_int_from_bits(uint64_t bits, NumKind target) {
    Value out;
    switch (target) {
        case NumKind::U8:
            out.type = ValueType::U8;
            out.u8_val = static_cast<uint8_t>(bits & 0xFFu);
            return out;
        case NumKind::U32:
            out.type = ValueType::U32;
            out.u32_val = static_cast<uint32_t>(bits & 0xFFFFFFFFull);
            return out;
        case NumKind::U64:
            out.type = ValueType::U64;
            out.u64_val = bits;
            return out;
        case NumKind::I8: {
            uint8_t b = static_cast<uint8_t>(bits & 0xFFu);
            int8_t v;
            std::memcpy(&v, &b, sizeof(v));
            out.type = ValueType::I8;
            out.i8_val = v;
            return out;
        }
        case NumKind::I32: {
            uint32_t b = static_cast<uint32_t>(bits & 0xFFFFFFFFull);
            int32_t v;
            std::memcpy(&v, &b, sizeof(v));
            out.type = ValueType::I32;
            out.i32_val = v;
            return out;
        }
        case NumKind::I64: {
            int64_t v;
            std::memcpy(&v, &bits, sizeof(v));
            out.type = ValueType::I64;
            out.i64_val = v;
            return out;
        }
        default:
            return out;  // unreachable: target is never a float kind here
    }
}

// Float->unsigned-int saturation. Compares against exact powers of two
// (always exactly representable in double) rather than a type's MAX value
// (which for 64-bit targets is NOT exactly representable in double) to
// avoid any rounding ambiguity right at the boundary.
uint64_t saturate_to_unsigned_bits(double v, int bits) {
    if (std::isnan(v) || v <= 0.0) {
        return 0;
    }
    double limit = std::ldexp(1.0, bits);  // 2^bits, exact
    if (v >= limit) {
        return (bits >= 64) ? std::numeric_limits<uint64_t>::max()
                             : ((uint64_t{1} << bits) - 1);
    }
    return static_cast<uint64_t>(v);  // safe: 0 <= v < 2^bits
}

// Float->signed-int saturation, same boundary-safety reasoning as above.
int64_t saturate_to_signed_bits(double v, int bits) {
    if (std::isnan(v)) {
        return 0;
    }
    double lower = -std::ldexp(1.0, bits - 1);           // -2^(bits-1), exact
    double upper_exclusive = std::ldexp(1.0, bits - 1);  // 2^(bits-1), exact
    if (v <= lower) {
        return (bits >= 64) ? std::numeric_limits<int64_t>::min()
                             : -(int64_t{1} << (bits - 1));
    }
    if (v >= upper_exclusive) {
        return (bits >= 64) ? std::numeric_limits<int64_t>::max()
                             : (int64_t{1} << (bits - 1)) - 1;
    }
    return static_cast<int64_t>(v);  // safe: -2^(bits-1) < v < 2^(bits-1)
}

}  // namespace

Value::Value(Value&& other) noexcept
    : type(other.type),
      u8_val(other.u8_val),
      u32_val(other.u32_val),
      u64_val(other.u64_val),
      i8_val(other.i8_val),
      i32_val(other.i32_val),
      i64_val(other.i64_val),
      f32_val(other.f32_val),
      f64_val(other.f64_val),
      bool_val(other.bool_val),
      string_val(std::move(other.string_val)),
      element_val(other.element_val),
      function_decl(other.function_decl),
      result_is_ok(other.result_is_ok),
      payload(other.payload),
      array_length(other.array_length) {
    other.payload = nullptr;  // ownership transferred; `other` is now empty
    other.array_length = 0;
}

Value& Value::operator=(Value&& other) noexcept {
    if (this == &other) {
        return *this;
    }
    free_value(this);  // release whatever *this currently owns first
    type = other.type;
    u8_val = other.u8_val;
    u32_val = other.u32_val;
    u64_val = other.u64_val;
    i8_val = other.i8_val;
    i32_val = other.i32_val;
    i64_val = other.i64_val;
    f32_val = other.f32_val;
    f64_val = other.f64_val;
    bool_val = other.bool_val;
    string_val = std::move(other.string_val);
    element_val = other.element_val;
    function_decl = other.function_decl;
    result_is_ok = other.result_is_ok;
    payload = other.payload;
    array_length = other.array_length;
    other.payload = nullptr;  // ownership transferred; `other` is now empty
    other.array_length = 0;
    return *this;
}

Value copy_value(const Value& src) {
    Value out;
    out.type = src.type;
    out.u8_val = src.u8_val;
    out.u32_val = src.u32_val;
    out.u64_val = src.u64_val;
    out.i8_val = src.i8_val;
    out.i32_val = src.i32_val;
    out.i64_val = src.i64_val;
    out.f32_val = src.f32_val;
    out.f64_val = src.f64_val;
    out.bool_val = src.bool_val;
    out.string_val = src.string_val;
    out.element_val = src.element_val;    // non-owning: share the pointer
    out.function_decl = src.function_decl;  // non-owning: share the pointer
    out.result_is_ok = src.result_is_ok;
    out.array_length = src.array_length;

    if (src.type == ValueType::Result) {
        if (src.payload != nullptr) {
            out.payload = new Value(copy_value(*src.payload));
        }
    } else if (src.type == ValueType::Array) {
        if (src.array_length > 0) {
            out.payload = new Value[src.array_length];
            for (size_t i = 0; i < src.array_length; ++i) {
                out.payload[i] = copy_value(src.payload[i]);
            }
        }
    }
    return out;
}

void free_value(Value* v) {
    if (v == nullptr) {
        return;
    }
    if (v->type == ValueType::Result) {
        if (v->payload != nullptr) {
            free_value(v->payload);
            delete v->payload;
        }
    } else if (v->type == ValueType::Array) {
        if (v->payload != nullptr) {
            for (size_t i = 0; i < v->array_length; ++i) {
                free_value(&v->payload[i]);
            }
            delete[] v->payload;
        }
    }
}

Value make_unit() { return Value(); }

Value make_string(std::string s) {
    Value v;
    v.type = ValueType::String;
    v.string_val = std::move(s);
    return v;
}

Value make_bool(bool b) {
    Value v;
    v.type = ValueType::Bool;
    v.bool_val = b;
    return v;
}

Value make_u8(uint8_t v) {
    Value out;
    out.type = ValueType::U8;
    out.u8_val = v;
    return out;
}
Value make_u32(uint32_t v) {
    Value out;
    out.type = ValueType::U32;
    out.u32_val = v;
    return out;
}
Value make_u64(uint64_t v) {
    Value out;
    out.type = ValueType::U64;
    out.u64_val = v;
    return out;
}
Value make_i8(int8_t v) {
    Value out;
    out.type = ValueType::I8;
    out.i8_val = v;
    return out;
}
Value make_i32(int32_t v) {
    Value out;
    out.type = ValueType::I32;
    out.i32_val = v;
    return out;
}
Value make_i64(int64_t v) {
    Value out;
    out.type = ValueType::I64;
    out.i64_val = v;
    return out;
}
Value make_f32(float v) {
    Value out;
    out.type = ValueType::F32;
    out.f32_val = v;
    return out;
}
Value make_f64(double v) {
    Value out;
    out.type = ValueType::F64;
    out.f64_val = v;
    return out;
}

bool is_truthy(const Value& v) {
    switch (v.type) {
        case ValueType::Bool:
            return v.bool_val;
        case ValueType::Unit:
            return false;
        case ValueType::String:
            return !v.string_val.empty();
        case ValueType::U8:
            return v.u8_val != 0;
        case ValueType::U32:
            return v.u32_val != 0;
        case ValueType::U64:
            return v.u64_val != 0;
        case ValueType::I8:
            return v.i8_val != 0;
        case ValueType::I32:
            return v.i32_val != 0;
        case ValueType::I64:
            return v.i64_val != 0;
        case ValueType::F32:
            return v.f32_val != 0;
        case ValueType::F64:
            return v.f64_val != 0;
        case ValueType::Element:
        case ValueType::Function:
        case ValueType::Result:
        case ValueType::Array:
            return true;
    }
    return false;
}

std::string to_display_string(const Value& v) {
    char buf[64];
    switch (v.type) {
        case ValueType::String:
            return v.string_val;
        case ValueType::Bool:
            return v.bool_val ? "true" : "false";
        case ValueType::Unit:
            return "()";
        case ValueType::U8:
            return std::to_string(v.u8_val);
        case ValueType::U32:
            return std::to_string(v.u32_val);
        case ValueType::U64:
            return std::to_string(v.u64_val);
        case ValueType::I8:
            return std::to_string(v.i8_val);
        case ValueType::I32:
            return std::to_string(v.i32_val);
        case ValueType::I64:
            return std::to_string(v.i64_val);
        case ValueType::F32:
            std::snprintf(buf, sizeof(buf), "%g", static_cast<double>(v.f32_val));
            return buf;
        case ValueType::F64:
            std::snprintf(buf, sizeof(buf), "%g", v.f64_val);
            return buf;
        case ValueType::Element:
            return "[element]";
        case ValueType::Function:
            return "[function]";
        case ValueType::Result:
            return (v.result_is_ok ? "Ok(" : "Err(") + to_display_string(*v.payload) + ")";
        case ValueType::Array: {
            std::string out = "[";
            for (size_t i = 0; i < v.array_length; ++i) {
                if (i > 0) {
                    out += ", ";
                }
                out += to_display_string(v.payload[i]);
            }
            out += "]";
            return out;
        }
    }
    return "";
}

bool values_equal(const Value& a, const Value& b) {
    if (is_numeric_value(a.type) && is_numeric_value(b.type)) {
        if (a.type == b.type) {
            switch (a.type) {
                case ValueType::U8:
                    return a.u8_val == b.u8_val;
                case ValueType::U32:
                    return a.u32_val == b.u32_val;
                case ValueType::U64:
                    return a.u64_val == b.u64_val;
                case ValueType::I8:
                    return a.i8_val == b.i8_val;
                case ValueType::I32:
                    return a.i32_val == b.i32_val;
                case ValueType::I64:
                    return a.i64_val == b.i64_val;
                case ValueType::F32:
                    return a.f32_val == b.f32_val;
                case ValueType::F64:
                    return a.f64_val == b.f64_val;
                default:
                    return false;
            }
        }
        // Different numeric kinds: compare "as if" promoted (numeric.h).
        // Approximated via double -- exact except for u64/i64 magnitudes
        // beyond 2^53, a documented simplification for this language.
        return numeric_as_double(a) == numeric_as_double(b);
    }
    if (a.type != b.type) {
        return false;
    }
    switch (a.type) {
        case ValueType::String:
            return a.string_val == b.string_val;
        case ValueType::Bool:
            return a.bool_val == b.bool_val;
        case ValueType::Unit:
            return true;
        case ValueType::Element:
            return a.element_val == b.element_val;
        case ValueType::Function:
            return a.function_decl == b.function_decl;
        case ValueType::Result:
            if (a.result_is_ok != b.result_is_ok) {
                return false;
            }
            return values_equal(*a.payload, *b.payload);
        case ValueType::Array:
            if (a.array_length != b.array_length) {
                return false;
            }
            for (size_t i = 0; i < a.array_length; ++i) {
                if (!values_equal(a.payload[i], b.payload[i])) {
                    return false;
                }
            }
            return true;
        default:
            return false;
    }
}

Value cast_numeric(const Value& src, NumKind target, int line,
                    std::vector<Diagnostic>* diags) {
    if (!is_numeric_value(src.type)) {
        diags->push_back(Diagnostic{"cannot cast a non-numeric value", line});
        return make_unit();
    }

    NumKind src_kind = numeric_kind_of(src.type);
    bool src_is_float = is_float_kind(src_kind);
    bool target_is_float = is_float_kind(target);

    if (target_is_float) {
        double v = numeric_as_double(src);
        Value out;
        if (target == NumKind::F32) {
            out.type = ValueType::F32;
            out.f32_val = static_cast<float>(v);
        } else {
            out.type = ValueType::F64;
            out.f64_val = v;
        }
        return out;
    }

    if (src_is_float) {
        double v = numeric_as_double(src);
        Value out;
        switch (target) {
            case NumKind::U8:
                out.type = ValueType::U8;
                out.u8_val = static_cast<uint8_t>(saturate_to_unsigned_bits(v, 8));
                break;
            case NumKind::U32:
                out.type = ValueType::U32;
                out.u32_val = static_cast<uint32_t>(saturate_to_unsigned_bits(v, 32));
                break;
            case NumKind::U64:
                out.type = ValueType::U64;
                out.u64_val = saturate_to_unsigned_bits(v, 64);
                break;
            case NumKind::I8:
                out.type = ValueType::I8;
                out.i8_val = static_cast<int8_t>(saturate_to_signed_bits(v, 8));
                break;
            case NumKind::I32:
                out.type = ValueType::I32;
                out.i32_val = static_cast<int32_t>(saturate_to_signed_bits(v, 32));
                break;
            case NumKind::I64:
                out.type = ValueType::I64;
                out.i64_val = saturate_to_signed_bits(v, 64);
                break;
            default:
                break;  // unreachable: target_is_float already handled above
        }
        return out;
    }

    // int -> int: wraparound, via the sign/zero-extend-then-mask technique.
    return make_int_from_bits(extend_int_to_u64_bits(src), target);
}

}  // namespace tinyscript
