#pragma once

#include <string>
#include <unordered_map>
#include <vector>

#include "tinyhtml/dom.h"
#include "tinyscript/ast.h"
#include "tinyscript/diagnostic.h"
#include "tinyscript/value.h"

namespace tinyscript {

// A single scope's variable bindings.
using Scope = std::unordered_map<std::string, Value>;

// A builtin callable. `interp` gives access to whatever context the
// builtin needs (e.g. dom_api.h's builtins read Interpreter::document);
// core language builtins (Ok/Err/print/...) just ignore it.
using BuiltinFn = Value (*)(struct Interpreter& interp, std::vector<Value>& args, int line,
                             std::vector<Diagnostic>* diags);

struct BuiltinInfo {
    int arity;
    BuiltinFn fn;
};

// Execution state shared across every <script> block in one document: one
// flat function table (functions hoist document-wide, see docs/
// tinyscript-spec.md section 3), one global scope, and one builtin
// registry, so a variable/function/builtin from one block is visible to
// another (§3, §8). Phase 4 (browser wiring) constructs one Interpreter
// per document and calls collect_functions/execute_program once per
// <script> block's Program, in document order.
struct Interpreter {
    std::unordered_map<std::string, Stmt*> functions;  // non-owning: point into each Program's AST
    Scope globals;

    // Builtins beyond the core language set (Ok/Err/is_ok/is_err/unwrap/
    // unwrap_err/array_new/array_len/print, always available -- see
    // interpreter.cpp) are registered here. This is how src/tinyscript/
    // dom_api.h/.cpp adds the DOM API without the core interpreter needing
    // to hardcode anything DOM-specific; empty for a document with no DOM
    // tie-in (e.g. the unit tests in tests/tinyscript/).
    std::unordered_map<std::string, BuiltinInfo> extra_builtins;

    // Context for whatever's registered in extra_builtins. Unused by the
    // core language itself; dom_api.h's register_dom_api sets this.
    tinyhtml::Node* document = nullptr;
};

// Registers (or overwrites) a builtin under `name`, expecting exactly
// `arity` arguments. A name already present in the core language builtin
// set cannot be overridden this way -- the core set is checked first.
void register_builtin(Interpreter& interp, const std::string& name, int arity, BuiltinFn fn);

// Frees every Value a scope owns (but not the Scope object itself). Call
// this before a Scope (or Interpreter::globals) goes out of scope/is torn
// down -- Value has no destructor by design (docs/instructor/
// tinyscript-design-notes.md), so nothing does this automatically.
void free_scope(Scope& scope);

// Collects every top-level `fn` declaration in `program` into `interp`'s
// function table (hoisting). Call this for every block's Program before
// executing any of them, so a function declared in a later block is
// callable from an earlier one.
void collect_functions(Interpreter& interp, Program& program);

// Executes `program`'s top-level statements against `interp`, in order.
// Never throws: a runtime error is recorded as a Diagnostic and execution
// continues with the next statement (docs/tinyscript-spec.md
// section 8).
void execute_program(Interpreter& interp, Program& program, std::vector<Diagnostic>* diags);

}  // namespace tinyscript
