#include "tinyscript/parser.h"

#include <unordered_map>
#include <utility>

#include "tinyscript/lexer.h"

namespace tinyscript {

namespace {

const std::unordered_map<std::string, NumKind> kNumericKindNames = {
    {"u8", NumKind::U8}, {"u32", NumKind::U32}, {"u64", NumKind::U64}, {"i8", NumKind::I8},
    {"i32", NumKind::I32}, {"i64", NumKind::I64}, {"f32", NumKind::F32}, {"f64", NumKind::F64},
};

bool numeric_kind_from_name(const std::string& name, NumKind* out) {
    auto it = kNumericKindNames.find(name);
    if (it == kNumericKindNames.end()) {
        return false;
    }
    *out = it->second;
    return true;
}

TypeKind type_kind_of_numeric(NumKind k) {
    switch (k) {
        case NumKind::U8:
            return TypeKind::U8;
        case NumKind::U32:
            return TypeKind::U32;
        case NumKind::U64:
            return TypeKind::U64;
        case NumKind::I8:
            return TypeKind::I8;
        case NumKind::I32:
            return TypeKind::I32;
        case NumKind::I64:
            return TypeKind::I64;
        case NumKind::F32:
            return TypeKind::F32;
        default:
            return TypeKind::F64;
    }
}

std::string binary_op_text(TokenType t) {
    switch (t) {
        case TokenType::Plus:
            return "+";
        case TokenType::Minus:
            return "-";
        case TokenType::Star:
            return "*";
        case TokenType::Slash:
            return "/";
        case TokenType::Percent:
            return "%";
        case TokenType::EqualEqual:
            return "==";
        case TokenType::BangEqual:
            return "!=";
        case TokenType::Less:
            return "<";
        case TokenType::Greater:
            return ">";
        case TokenType::LessEqual:
            return "<=";
        case TokenType::GreaterEqual:
            return ">=";
        case TokenType::AmpAmp:
            return "&&";
        case TokenType::PipePipe:
            return "||";
        default:
            return "";
    }
}

// Recursive-descent parser over the token stream. See docs/
// tinyscript-spec.md section 2 for the shared grammar, and docs/
// typyscript-spec.md section 1 for the annotation productions parsed here
// (always syntactically legal, regardless of dialect -- only typyscript's
// checker requires them).
struct Parser {
    std::vector<Token> tokens;
    size_t pos = 0;
    std::vector<Diagnostic>* diags;

    Parser(std::vector<Token> toks, std::vector<Diagnostic>* d) : tokens(std::move(toks)), diags(d) {}

    const Token& peek() const { return tokens[pos]; }  // tokens always ends in EndOfFile
    const Token& advance() {
        const Token& t = tokens[pos];
        if (t.type != TokenType::EndOfFile) {
            ++pos;
        }
        return t;
    }
    bool check(TokenType type) const { return peek().type == type; }
    bool at_end() const { return check(TokenType::EndOfFile); }

    void error(const std::string& message) { diags->push_back(Diagnostic{message, peek().line}); }

    // Consumes `type` if present; otherwise records a diagnostic and does
    // NOT consume the unexpected token (so a caller further up can decide
    // how to resynchronize).
    void expect(TokenType type, const std::string& message) {
        if (check(type)) {
            advance();
            return;
        }
        error(message);
    }

    Expr* make_binary(Expr* left, const std::string& op, Expr* right, int line) {
        Expr* e = new Expr();
        e->type = ExprType::Binary;
        e->line = line;
        e->text = op;
        e->left = left;
        e->right = right;
        return e;
    }

    // ---- Types (docs/typyscript-spec.md section 1) ----

    Type* parse_type() {
        if (check(TokenType::LParen)) {
            advance();
            expect(TokenType::RParen, "expected ')' to close '()' (the Unit type)");
            return make_type(TypeKind::Unit);
        }
        if (!check(TokenType::Ident)) {
            error("expected a type");
            return make_type(TypeKind::Unit);
        }
        std::string name = advance().text;

        NumKind num_kind;
        if (numeric_kind_from_name(name, &num_kind)) {
            return make_type(type_kind_of_numeric(num_kind));
        }
        if (name == "String") {
            return make_type(TypeKind::String);
        }
        if (name == "Bool") {
            return make_type(TypeKind::Bool);
        }
        if (name == "Element") {
            return make_type(TypeKind::Element);
        }
        if (name == "Result") {
            expect(TokenType::Less, "expected '<' after 'Result'");
            Type* ok = parse_type();
            expect(TokenType::Comma, "expected ',' in Result<T, E>");
            Type* err = parse_type();
            expect(TokenType::Greater, "expected '>' after Result<T, E>");
            Type* t = make_type(TypeKind::Result);
            t->result_ok_type = ok;
            t->result_err_type = err;
            return t;
        }
        if (name == "Array") {
            expect(TokenType::Less, "expected '<' after 'Array'");
            Type* elem = parse_type();
            expect(TokenType::Greater, "expected '>' after Array<T>");
            Type* t = make_type(TypeKind::Array);
            t->array_element_type = elem;
            return t;
        }
        error("unknown type '" + name + "'");
        return make_type(TypeKind::Unit);
    }

    // ---- Expressions, lowest to highest precedence ----

    Expr* parse_expression() { return parse_logic_or(); }

    Expr* parse_logic_or() {
        Expr* left = parse_logic_and();
        while (check(TokenType::PipePipe)) {
            int line = advance().line;
            left = make_binary(left, "||", parse_logic_and(), line);
        }
        return left;
    }

    Expr* parse_logic_and() {
        Expr* left = parse_equality();
        while (check(TokenType::AmpAmp)) {
            int line = advance().line;
            left = make_binary(left, "&&", parse_equality(), line);
        }
        return left;
    }

    Expr* parse_equality() {
        Expr* left = parse_comparison();
        while (check(TokenType::EqualEqual) || check(TokenType::BangEqual)) {
            Token op = advance();
            left = make_binary(left, binary_op_text(op.type), parse_comparison(), op.line);
        }
        return left;
    }

    Expr* parse_comparison() {
        Expr* left = parse_term();
        while (check(TokenType::Less) || check(TokenType::Greater) || check(TokenType::LessEqual) ||
               check(TokenType::GreaterEqual)) {
            Token op = advance();
            left = make_binary(left, binary_op_text(op.type), parse_term(), op.line);
        }
        return left;
    }

    Expr* parse_term() {
        Expr* left = parse_factor();
        while (check(TokenType::Plus) || check(TokenType::Minus)) {
            Token op = advance();
            left = make_binary(left, binary_op_text(op.type), parse_factor(), op.line);
        }
        return left;
    }

    Expr* parse_factor() {
        Expr* left = parse_cast();
        while (check(TokenType::Star) || check(TokenType::Slash) || check(TokenType::Percent)) {
            Token op = advance();
            left = make_binary(left, binary_op_text(op.type), parse_cast(), op.line);
        }
        return left;
    }

    Expr* parse_cast() {
        Expr* operand = parse_unary();
        while (check(TokenType::As)) {
            int line = advance().line;
            NumKind target = NumKind::I32;
            if (check(TokenType::Ident) && numeric_kind_from_name(peek().text, &target)) {
                advance();
            } else {
                error("expected a numeric type after 'as'");
            }
            Expr* cast_expr = new Expr();
            cast_expr->type = ExprType::Cast;
            cast_expr->line = line;
            cast_expr->cast_operand = operand;
            cast_expr->cast_target = target;
            operand = cast_expr;
        }
        return operand;
    }

    Expr* parse_unary() {
        if (check(TokenType::Bang) || check(TokenType::Minus)) {
            Token op = advance();
            Expr* e = new Expr();
            e->type = ExprType::Unary;
            e->line = op.line;
            e->text = (op.type == TokenType::Bang) ? "!" : "-";
            e->left = parse_unary();
            return e;
        }
        return parse_postfix();
    }

    Expr* parse_postfix() {
        Expr* e = parse_primary();
        for (;;) {
            if (check(TokenType::LParen)) {
                int line = advance().line;
                std::vector<Expr*> args;
                if (!check(TokenType::RParen)) {
                    args.push_back(parse_expression());
                    while (check(TokenType::Comma)) {
                        advance();
                        args.push_back(parse_expression());
                    }
                }
                expect(TokenType::RParen, "expected ')' after call arguments");
                Expr* call = new Expr();
                call->type = ExprType::Call;
                call->line = line;
                call->left = e;
                call->args = std::move(args);
                e = call;
            } else if (check(TokenType::LBracket)) {
                int line = advance().line;
                Expr* index = parse_expression();
                expect(TokenType::RBracket, "expected ']' after index expression");
                Expr* idx = new Expr();
                idx->type = ExprType::Index;
                idx->line = line;
                idx->index_array = e;
                idx->index_expr = index;
                e = idx;
            } else {
                break;
            }
        }
        return e;
    }

    Expr* parse_primary() {
        if (check(TokenType::Number)) {
            Token t = advance();
            Expr* e = new Expr();
            e->type = ExprType::Number;
            e->line = t.line;
            e->number = t.number;
            e->literal_kind = t.number_kind;
            e->literal_kind_explicit = t.number_kind_explicit;
            return e;
        }
        if (check(TokenType::String)) {
            Token t = advance();
            Expr* e = new Expr();
            e->type = ExprType::String;
            e->line = t.line;
            e->text = t.text;
            return e;
        }
        if (check(TokenType::True) || check(TokenType::False)) {
            Token t = advance();
            Expr* e = new Expr();
            e->type = ExprType::Bool;
            e->line = t.line;
            e->boolean = (t.type == TokenType::True);
            return e;
        }
        if (check(TokenType::Ident)) {
            Token t = advance();
            Expr* e = new Expr();
            e->type = ExprType::Ident;
            e->line = t.line;
            e->text = t.text;
            return e;
        }
        if (check(TokenType::LParen)) {
            advance();
            Expr* inner = parse_expression();
            expect(TokenType::RParen, "expected ')'");
            return inner;
        }
        if (check(TokenType::LBracket)) {
            int line = advance().line;
            std::vector<Expr*> elements;
            if (!check(TokenType::RBracket)) {
                elements.push_back(parse_expression());
                while (check(TokenType::Comma)) {
                    advance();
                    elements.push_back(parse_expression());
                }
            }
            expect(TokenType::RBracket, "expected ']' after array literal");
            Expr* e = new Expr();
            e->type = ExprType::ArrayLiteral;
            e->line = line;
            e->array_elements = std::move(elements);
            return e;
        }

        error("expected an expression");
        // Safe fallback so callers always get a non-null Expr* without
        // consuming the unexpected token.
        Expr* e = new Expr();
        e->type = ExprType::Bool;
        e->line = peek().line;
        e->boolean = false;
        return e;
    }

    // ---- Statements ----

    std::vector<Stmt*> parse_block() {
        std::vector<Stmt*> stmts;
        expect(TokenType::LBrace, "expected '{'");
        while (!at_end() && !check(TokenType::RBrace)) {
            size_t before = pos;
            Stmt* s = parse_statement();
            if (s != nullptr) {
                stmts.push_back(s);
            }
            if (pos == before && !at_end()) {
                advance();  // guarantee forward progress no matter what
            }
        }
        expect(TokenType::RBrace, "expected '}'");
        return stmts;
    }

    Stmt* parse_var_decl() {
        int line = advance().line;  // 'let'
        std::string name;
        if (check(TokenType::Ident)) {
            name = advance().text;
        } else {
            error("expected variable name after 'let'");
        }
        Type* annotation = nullptr;
        if (check(TokenType::Colon)) {
            advance();
            annotation = parse_type();
        }
        Expr* init = nullptr;
        if (check(TokenType::Equal)) {
            advance();
            init = parse_expression();
        }
        expect(TokenType::Semicolon, "expected ';' after variable declaration");

        Stmt* stmt = new Stmt();
        stmt->type = StmtType::VarDecl;
        stmt->line = line;
        stmt->var_name = name;
        stmt->var_type_annotation = annotation;
        stmt->var_init = init;
        return stmt;
    }

    Stmt* parse_if() {
        int line = advance().line;  // 'if'
        expect(TokenType::LParen, "expected '(' after 'if'");
        Expr* cond = parse_expression();
        expect(TokenType::RParen, "expected ')' after if condition");
        std::vector<Stmt*> then_body = parse_block();
        std::vector<Stmt*> else_body;
        if (check(TokenType::Else)) {
            advance();
            if (check(TokenType::If)) {
                else_body.push_back(parse_if());
            } else {
                else_body = parse_block();
            }
        }
        Stmt* stmt = new Stmt();
        stmt->type = StmtType::If;
        stmt->line = line;
        stmt->expr = cond;
        stmt->body = std::move(then_body);
        stmt->else_body = std::move(else_body);
        return stmt;
    }

    Stmt* parse_while() {
        int line = advance().line;  // 'while'
        expect(TokenType::LParen, "expected '(' after 'while'");
        Expr* cond = parse_expression();
        expect(TokenType::RParen, "expected ')' after while condition");
        Stmt* stmt = new Stmt();
        stmt->type = StmtType::While;
        stmt->line = line;
        stmt->expr = cond;
        stmt->body = parse_block();
        return stmt;
    }

    Stmt* parse_func_decl() {
        int line = advance().line;  // 'fn'
        std::string name;
        if (check(TokenType::Ident)) {
            name = advance().text;
        } else {
            error("expected function name after 'fn'");
        }
        expect(TokenType::LParen, "expected '(' after function name");
        std::vector<std::string> params;
        std::vector<Type*> param_types;
        if (!check(TokenType::RParen)) {
            for (;;) {
                std::string pname;
                if (check(TokenType::Ident)) {
                    pname = advance().text;
                } else {
                    error("expected parameter name");
                }
                Type* ptype = nullptr;
                if (check(TokenType::Colon)) {
                    advance();
                    ptype = parse_type();
                }
                params.push_back(pname);
                param_types.push_back(ptype);
                if (check(TokenType::Comma)) {
                    advance();
                    continue;
                }
                break;
            }
        }
        expect(TokenType::RParen, "expected ')' after parameters");
        Type* return_type = nullptr;
        if (check(TokenType::Arrow)) {
            advance();
            return_type = parse_type();
        }

        Stmt* stmt = new Stmt();
        stmt->type = StmtType::FuncDecl;
        stmt->line = line;
        stmt->func_name = name;
        stmt->param_names = std::move(params);
        stmt->param_type_annotations = std::move(param_types);
        stmt->return_type_annotation = return_type;
        stmt->body = parse_block();
        return stmt;
    }

    Stmt* parse_return() {
        int line = advance().line;  // 'return'
        Expr* value = nullptr;
        if (!check(TokenType::Semicolon)) {
            value = parse_expression();
        }
        expect(TokenType::Semicolon, "expected ';' after return statement");
        Stmt* stmt = new Stmt();
        stmt->type = StmtType::Return;
        stmt->line = line;
        stmt->expr = value;
        return stmt;
    }

    Stmt* parse_block_stmt() {
        int line = peek().line;
        Stmt* stmt = new Stmt();
        stmt->type = StmtType::Block;
        stmt->line = line;
        stmt->body = parse_block();
        return stmt;
    }

    // Assign and ExprStmt both start with an expression-shaped prefix (a
    // Lvalue is exactly what Postfix parses for a bare identifier or a
    // chain of subscripts). Parse the expression once; if '=' follows and
    // the expression has a valid Lvalue shape, reinterpret it as an
    // assignment target instead of backtracking.
    Stmt* parse_assign_or_expr_stmt() {
        int line = peek().line;
        Expr* expr = parse_expression();

        if (check(TokenType::Equal)) {
            advance();
            Expr* rhs = parse_expression();
            expect(TokenType::Semicolon, "expected ';' after assignment");

            Stmt* stmt = new Stmt();
            stmt->type = StmtType::Assign;
            stmt->line = line;
            stmt->expr = rhs;
            if (expr->type == ExprType::Ident) {
                stmt->assign_name = expr->text;
                free_expr(expr);  // only the name was needed; the Ident node itself isn't kept
            } else if (expr->type == ExprType::Index) {
                stmt->assign_index_target = expr;  // Stmt now owns this Index node
            } else {
                error("invalid assignment target");
                free_expr(expr);
            }
            return stmt;
        }

        expect(TokenType::Semicolon, "expected ';' after expression");
        Stmt* stmt = new Stmt();
        stmt->type = StmtType::ExprStmt;
        stmt->line = line;
        stmt->expr = expr;
        return stmt;
    }

    Stmt* parse_statement() {
        if (check(TokenType::Let)) {
            return parse_var_decl();
        }
        if (check(TokenType::If)) {
            return parse_if();
        }
        if (check(TokenType::While)) {
            return parse_while();
        }
        if (check(TokenType::Fn)) {
            return parse_func_decl();
        }
        if (check(TokenType::Return)) {
            return parse_return();
        }
        if (check(TokenType::LBrace)) {
            return parse_block_stmt();
        }
        return parse_assign_or_expr_stmt();
    }

    Program parse_program() {
        Program prog;
        while (!at_end()) {
            size_t before = pos;
            Stmt* s = parse_statement();
            if (s != nullptr) {
                prog.statements.push_back(s);
            }
            if (pos == before && !at_end()) {
                advance();  // guarantee forward progress no matter what
            }
        }
        return prog;
    }
};

}  // namespace

ParseResult parse(const std::string& source) {
    ParseResult result;
    Parser parser(lex(source), &result.diagnostics);
    result.program = parser.parse_program();
    return result;
}

}  // namespace tinyscript
