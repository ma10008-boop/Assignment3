#include "tinyscript/typecheck.h"

#include <unordered_map>

namespace tinyscript {

namespace {

bool is_numeric_kind(TypeKind k) {
    switch (k) {
        case TypeKind::U8:
        case TypeKind::U32:
        case TypeKind::U64:
        case TypeKind::I8:
        case TypeKind::I32:
        case TypeKind::I64:
        case TypeKind::F32:
        case TypeKind::F64:
            return true;
        default:
            return false;
    }
}

TypeKind type_kind_of_num(NumKind k) {
    switch (k) {
        case NumKind::U8:
            return TypeKind::U8;
        case NumKind::U32:
            return TypeKind::U32;
        case NumKind::U64:
            return TypeKind::U64;
        case NumKind::I8:
            return TypeKind::I8;
        case NumKind::I32:
            return TypeKind::I32;
        case NumKind::I64:
            return TypeKind::I64;
        case NumKind::F32:
            return TypeKind::F32;
        default:
            return TypeKind::F64;
    }
}

bool is_flexible_literal(const Expr* e) {
    return e->type == ExprType::Number && !e->literal_kind_explicit;
}

bool types_equal(const Type& a, const Type& b) {
    if (a.kind != b.kind) {
        return false;
    }
    switch (a.kind) {
        case TypeKind::Result:
            return types_equal(*a.result_ok_type, *b.result_ok_type) &&
                   types_equal(*a.result_err_type, *b.result_err_type);
        case TypeKind::Array:
            return types_equal(*a.array_element_type, *b.array_element_type);
        default:
            return true;
    }
}

Type any_type() { return Type(); }  // Type::kind defaults to TypeKind::Any

Type bool_type() {
    Type t;
    t.kind = TypeKind::Bool;
    return t;
}

Type unit_type() {
    Type t;
    t.kind = TypeKind::Unit;
    return t;
}

Type element_type() {
    Type t;
    t.kind = TypeKind::Element;
    return t;
}

Type string_type() {
    Type t;
    t.kind = TypeKind::String;
    return t;
}

Type result_of(Type ok, Type err) {
    Type out;
    out.kind = TypeKind::Result;
    out.result_ok_type = new Type(std::move(ok));
    out.result_err_type = new Type(std::move(err));
    return out;
}

// A single scope's declared variable types, mirroring interpreter.cpp's
// Scope but for static types instead of runtime values. Entries either
// point into the AST (an annotation the parser already allocated) or into
// `CheckState::owned_fallback_types` (see below) -- never owned directly
// by the scope map itself.
using TypeScope = std::unordered_map<std::string, Type*>;

struct FunctionSig {
    std::vector<Type*> param_types;  // non-owning; nullptr entries -> treated as Any
    Type* return_type = nullptr;     // non-owning; nullptr -> treated as Any
};

struct CheckState {
    std::unordered_map<std::string, FunctionSig> functions;
    TypeScope globals;
    std::vector<TypeScope*> scopes;  // innermost last; scopes[0] is always &globals
    Type* current_return_type = nullptr;  // non-owning; set while checking inside a function body
    TypeTable* table;                     // may be nullptr
    std::vector<Diagnostic>* diags;

    // Fallback Types synthesized when an annotation is missing or a
    // builtin's element/payload type can't be inferred from context --
    // these aren't owned by the AST, so CheckState owns them instead and
    // frees them all when checking finishes.
    std::vector<Type*> owned_fallback_types;

    Type* new_fallback(TypeKind kind) {
        Type* t = make_type(kind);
        owned_fallback_types.push_back(t);
        return t;
    }
};

void report(CheckState& state, int line, const std::string& message) {
    state.diags->push_back(Diagnostic{message, line});
}

Type* lookup_variable_type(CheckState& state, const std::string& name) {
    for (auto it = state.scopes.rbegin(); it != state.scopes.rend(); ++it) {
        auto found = (*it)->find(name);
        if (found != (*it)->end()) {
            return found->second;
        }
    }
    return nullptr;
}

Type infer_expr_type(CheckState& state, Expr* expr, const Type* expected);

// Infers `expr`'s type purely for its side effects (recording diagnostics
// and populating the TypeTable) when the caller has no use for the result
// itself -- e.g. a statement-level expression, or an argument list being
// walked just to keep checking the rest of the program after an earlier
// error. Frees the computed Type immediately.
void infer_and_discard(CheckState& state, Expr* expr, const Type* expected) {
    Type t = infer_expr_type(state, expr, expected);
    release_type(t);
}

// Records `type`'s value into the shared TypeTable (if any) and returns a
// moved-from copy of it -- the one place infer_expr_type's callers get
// their result from, so every computed type is captured for `type_of()`
// without every call site needing to remember to do it.
Type finish(CheckState& state, const Expr* expr, Type type) {
    if (state.table != nullptr) {
        state.table->insert_or_assign(expr, copy_type(type));
    }
    return type;
}

// Infers both operands of a binary numeric/comparison operator, letting a
// bare (unsuffixed) literal on either side adopt the other's concrete
// type -- docs/typyscript-spec.md section 2's checking rule.
// Caller owns (and must release_type) *out_left/*out_right afterward.
void infer_binary_operands(CheckState& state, Expr* left, Expr* right, const Type* outer_expected,
                            Type* out_left, Type* out_right) {
    bool left_flex = is_flexible_literal(left);
    bool right_flex = is_flexible_literal(right);

    if (left_flex && right_flex) {
        const Type* ctx = (outer_expected != nullptr && is_numeric_kind(outer_expected->kind))
                               ? outer_expected
                               : nullptr;
        *out_left = infer_expr_type(state, left, ctx);
        *out_right = infer_expr_type(state, right, ctx);
    } else if (left_flex) {
        *out_right = infer_expr_type(state, right, nullptr);
        *out_left = infer_expr_type(state, left, out_right);
    } else if (right_flex) {
        *out_left = infer_expr_type(state, left, nullptr);
        *out_right = infer_expr_type(state, right, out_left);
    } else {
        *out_left = infer_expr_type(state, left, nullptr);
        *out_right = infer_expr_type(state, right, nullptr);
    }
}

// Checks a fixed-arity builtin's arguments against `param_kinds`, reporting
// a diagnostic per mismatched argument. Concrete-kind-only (Element/String)
// -- none of the DOM builtins take a numeric or Result parameter, so no
// promotion/literal-polymorphism handling is needed here, unlike the
// user-declared-function argument check below.
void check_fixed_args(CheckState& state, Expr* expr, const std::string& name,
                       const std::vector<TypeKind>& param_kinds) {
    std::vector<Expr*>& args = expr->args;
    if (args.size() != param_kinds.size()) {
        report(state, expr->line, "wrong number of arguments to '" + name + "'");
        for (Expr* a : args) {
            infer_and_discard(state, a, nullptr);
        }
        return;
    }
    for (size_t i = 0; i < args.size(); ++i) {
        Type param_expected;
        param_expected.kind = param_kinds[i];
        Type actual = infer_expr_type(state, args[i], &param_expected);
        if (actual.kind != TypeKind::Any && actual.kind != param_kinds[i]) {
            report(state, args[i]->line,
                   "argument " + std::to_string(i + 1) + " to '" + name + "' has the wrong type");
        }
        release_type(actual);
    }
}

Type infer_call_type(CheckState& state, Expr* expr, const Type* expected) {
    if (expr->left == nullptr || expr->left->type != ExprType::Ident) {
        report(state, expr->line, "call target must be a function name");
        for (Expr* a : expr->args) {
            infer_and_discard(state, a, nullptr);
        }
        return any_type();
    }
    const std::string& name = expr->left->text;
    std::vector<Expr*>& args = expr->args;

    auto require_arity = [&](size_t n) -> bool {
        if (args.size() != n) {
            report(state, expr->line, "wrong number of arguments to '" + name + "'");
            for (Expr* a : args) {
                infer_and_discard(state, a, nullptr);
            }
            return false;
        }
        return true;
    };

    if (name == "Ok" || name == "Err") {
        if (!require_arity(1)) {
            return any_type();
        }
        const Type* payload_expected = nullptr;
        if (expected != nullptr && expected->kind == TypeKind::Result) {
            payload_expected = (name == "Ok") ? expected->result_ok_type : expected->result_err_type;
        }
        Type payload_type = infer_expr_type(state, args[0], payload_expected);
        Type out;
        out.kind = TypeKind::Result;
        if (name == "Ok") {
            out.result_ok_type = new Type(std::move(payload_type));
            out.result_err_type = new Type(expected && expected->kind == TypeKind::Result
                                                ? copy_type(*expected->result_err_type)
                                                : any_type());
        } else {
            out.result_err_type = new Type(std::move(payload_type));
            out.result_ok_type = new Type(expected && expected->kind == TypeKind::Result
                                               ? copy_type(*expected->result_ok_type)
                                               : any_type());
        }
        return out;
    }
    if (name == "is_ok" || name == "is_err") {
        if (!require_arity(1)) {
            return any_type();
        }
        Type arg_type = infer_expr_type(state, args[0], nullptr);
        if (arg_type.kind != TypeKind::Result && arg_type.kind != TypeKind::Any) {
            report(state, expr->line, "'" + name + "' requires a Result value");
        }
        release_type(arg_type);
        return bool_type();
    }
    if (name == "unwrap" || name == "unwrap_err") {
        if (!require_arity(1)) {
            return any_type();
        }
        Type arg_type = infer_expr_type(state, args[0], nullptr);
        if (arg_type.kind == TypeKind::Any) {
            release_type(arg_type);
            return any_type();
        }
        if (arg_type.kind != TypeKind::Result) {
            report(state, expr->line, "'" + name + "' requires a Result value");
            release_type(arg_type);
            return any_type();
        }
        Type* payload = (name == "unwrap") ? arg_type.result_ok_type : arg_type.result_err_type;
        Type result = payload != nullptr ? copy_type(*payload) : any_type();
        release_type(arg_type);
        return result;
    }
    if (name == "array_new") {
        if (!require_arity(1)) {
            return any_type();
        }
        Type len_type = infer_expr_type(state, args[0], nullptr);
        if (!is_numeric_kind(len_type.kind) && len_type.kind != TypeKind::Any) {
            report(state, expr->line, "array_new's length argument must be numeric");
        }
        release_type(len_type);
        if (expected == nullptr || expected->kind != TypeKind::Array) {
            report(state, expr->line,
                   "cannot infer array_new's element type here -- use it directly in an "
                   "annotated 'let'");
            Type out;
            out.kind = TypeKind::Array;
            out.array_element_type = state.new_fallback(TypeKind::Any);
            return out;
        }
        Type out;
        out.kind = TypeKind::Array;
        out.array_element_type = new Type(copy_type(*expected->array_element_type));
        return out;
    }
    if (name == "array_len") {
        if (!require_arity(1)) {
            return any_type();
        }
        Type arr_type = infer_expr_type(state, args[0], nullptr);
        if (arr_type.kind != TypeKind::Array && arr_type.kind != TypeKind::Any) {
            report(state, expr->line, "array_len() requires an Array value");
        }
        release_type(arr_type);
        Type out;
        out.kind = TypeKind::U64;
        return out;
    }
    if (name == "print") {
        if (!require_arity(1)) {
            return any_type();
        }
        infer_and_discard(state, args[0], nullptr);  // any type is accepted
        return unit_type();
    }

    // The DOM API (docs/tinyscript-spec.md section 7) is
    // registered as a runtime builtin by dom_api.cpp/register_dom_api, not
    // through state.functions -- the checker has no visibility into that
    // registration, so its fixed signatures are hardcoded here too, the
    // same way Ok/Err/etc. above are.
    if (name == "getElementById") {
        check_fixed_args(state, expr, name, {TypeKind::String});
        return result_of(element_type(), unit_type());
    }
    if (name == "getAttribute") {
        check_fixed_args(state, expr, name, {TypeKind::Element, TypeKind::String});
        return result_of(string_type(), unit_type());
    }
    if (name == "setAttribute") {
        check_fixed_args(state, expr, name, {TypeKind::Element, TypeKind::String, TypeKind::String});
        return unit_type();
    }
    if (name == "setText" || name == "setHtml") {
        check_fixed_args(state, expr, name, {TypeKind::Element, TypeKind::String});
        return unit_type();
    }
    if (name == "on") {
        check_fixed_args(state, expr, name, {TypeKind::Element, TypeKind::String, TypeKind::String});
        return unit_type();
    }

    auto func_it = state.functions.find(name);
    if (func_it == state.functions.end()) {
        report(state, expr->line, "call to undefined function '" + name + "'");
        for (Expr* a : args) {
            infer_and_discard(state, a, nullptr);
        }
        return any_type();
    }
    const FunctionSig& sig = func_it->second;
    if (args.size() != sig.param_types.size()) {
        report(state, expr->line, "wrong number of arguments to '" + name + "'");
        for (Expr* a : args) {
            infer_and_discard(state, a, nullptr);
        }
        return any_type();
    }
    for (size_t i = 0; i < args.size(); ++i) {
        Type param_expected = sig.param_types[i] != nullptr ? copy_type(*sig.param_types[i]) : any_type();
        Type arg_type = infer_expr_type(state, args[i], &param_expected);
        if (param_expected.kind != TypeKind::Any && arg_type.kind != TypeKind::Any &&
            !types_equal(arg_type, param_expected)) {
            report(state, args[i]->line, "argument " + std::to_string(i + 1) + " to '" + name +
                                              "' has the wrong type");
        }
        release_type(param_expected);
        release_type(arg_type);
    }
    return sig.return_type != nullptr ? copy_type(*sig.return_type) : any_type();
}

Type infer_expr_type(CheckState& state, Expr* expr, const Type* expected) {
    switch (expr->type) {
        case ExprType::Number: {
            Type out;
            if (!expr->literal_kind_explicit && expected != nullptr &&
                is_numeric_kind(expected->kind)) {
                out.kind = expected->kind;
            } else {
                out.kind = type_kind_of_num(expr->literal_kind);
            }
            return finish(state, expr, std::move(out));
        }
        case ExprType::String: {
            Type out;
            out.kind = TypeKind::String;
            return finish(state, expr, std::move(out));
        }
        case ExprType::Bool:
            return finish(state, expr, bool_type());
        case ExprType::Ident: {
            Type* found = lookup_variable_type(state, expr->text);
            if (found == nullptr) {
                report(state, expr->line, "undefined variable '" + expr->text + "'");
                return finish(state, expr, any_type());
            }
            return finish(state, expr, copy_type(*found));
        }
        case ExprType::Unary: {
            if (expr->text == "!") {
                Type bool_expected = bool_type();
                Type operand = infer_expr_type(state, expr->left, &bool_expected);
                release_type(bool_expected);
                if (operand.kind != TypeKind::Bool && operand.kind != TypeKind::Any) {
                    report(state, expr->line, "'!' requires a Bool operand");
                }
                release_type(operand);
                return finish(state, expr, bool_type());
            }
            // unary '-'
            Type operand = infer_expr_type(state, expr->left, expected);
            if (!is_numeric_kind(operand.kind) && operand.kind != TypeKind::Any) {
                report(state, expr->line, "unary '-' requires a numeric operand");
                release_type(operand);
                return finish(state, expr, any_type());
            }
            return finish(state, expr, std::move(operand));
        }
        case ExprType::Binary: {
            const std::string& op = expr->text;
            if (op == "&&" || op == "||") {
                Type bool_expected = bool_type();
                Type l = infer_expr_type(state, expr->left, &bool_expected);
                Type r = infer_expr_type(state, expr->right, &bool_expected);
                release_type(bool_expected);
                if ((l.kind != TypeKind::Bool && l.kind != TypeKind::Any) ||
                    (r.kind != TypeKind::Bool && r.kind != TypeKind::Any)) {
                    report(state, expr->line, "'" + op + "' requires Bool operands");
                }
                release_type(l);
                release_type(r);
                return finish(state, expr, bool_type());
            }
            if (op == "==" || op == "!=") {
                Type l, r;
                infer_binary_operands(state, expr->left, expr->right, nullptr, &l, &r);
                if (l.kind != TypeKind::Any && r.kind != TypeKind::Any && !types_equal(l, r)) {
                    report(state, expr->line, "'" + op + "' requires operands of the same type");
                }
                release_type(l);
                release_type(r);
                return finish(state, expr, bool_type());
            }
            // arithmetic and relational operators: both numeric, except
            // '+' also accepts two Strings (concatenation). Concrete kinds
            // must agree exactly, same as the numeric rule below -- no
            // implicit conversion, so String + non-String is rejected here
            // even though tinyscript's *runtime* auto-coerces the
            // non-string side for '+' (docs/tinyscript-spec.md
            // section 3); that coercion has no static counterpart.
            Type l, r;
            infer_binary_operands(state, expr->left, expr->right, expected, &l, &r);
            if (op == "+" && (l.kind == TypeKind::String || r.kind == TypeKind::String)) {
                bool l_str_ok = l.kind == TypeKind::String || l.kind == TypeKind::Any;
                bool r_str_ok = r.kind == TypeKind::String || r.kind == TypeKind::Any;
                if (!l_str_ok || !r_str_ok) {
                    report(state, expr->line,
                           "'+' between a String and a non-String has no implicit conversion");
                }
                release_type(l);
                release_type(r);
                return finish(state, expr, string_type());
            }
            bool l_ok = is_numeric_kind(l.kind) || l.kind == TypeKind::Any;
            bool r_ok = is_numeric_kind(r.kind) || r.kind == TypeKind::Any;
            bool is_relational = (op == "<" || op == ">" || op == "<=" || op == ">=");
            if (!l_ok || !r_ok) {
                report(state, expr->line, "operator '" + op + "' requires numeric operands");
                release_type(l);
                release_type(r);
                return finish(state, expr, is_relational ? bool_type() : any_type());
            }
            if (l.kind != TypeKind::Any && r.kind != TypeKind::Any && l.kind != r.kind) {
                report(state, expr->line,
                       "operands of '" + op + "' have different kinds -- use an explicit 'as'");
            }
            if (is_relational) {
                release_type(l);
                release_type(r);
                return finish(state, expr, bool_type());
            }
            // Result kind: whichever side is concrete (they should agree,
            // or a mismatch was already reported above); Any if both are.
            // Neither l nor r can own sub-Types here (both are numeric or
            // Any), so no release is needed before reusing l.kind/r.kind.
            Type out;
            out.kind = (l.kind != TypeKind::Any) ? l.kind : r.kind;
            release_type(l);
            release_type(r);
            return finish(state, expr, std::move(out));
        }
        case ExprType::Call:
            return finish(state, expr, infer_call_type(state, expr, expected));
        case ExprType::Cast: {
            Type operand = infer_expr_type(state, expr->cast_operand, nullptr);
            if (!is_numeric_kind(operand.kind) && operand.kind != TypeKind::Any) {
                report(state, expr->line, "'as' requires a numeric operand");
            }
            release_type(operand);
            Type out;
            out.kind = type_kind_of_num(expr->cast_target);
            return finish(state, expr, std::move(out));
        }
        case ExprType::ArrayLiteral: {
            const Type* elem_expected =
                (expected != nullptr && expected->kind == TypeKind::Array) ? expected->array_element_type
                                                                            : nullptr;
            Type elem_type;
            bool have_elem_type = false;
            for (Expr* e : expr->array_elements) {
                // Prefer the outer annotation's element type as context if
                // there is one; otherwise, once the first element has
                // established a concrete type, later flexible-literal
                // elements adopt *that* instead.
                const Type* ctx = elem_expected != nullptr ? elem_expected
                                   : have_elem_type          ? &elem_type
                                                              : nullptr;
                Type this_type = infer_expr_type(state, e, ctx);
                if (!have_elem_type) {
                    elem_type = std::move(this_type);
                    have_elem_type = true;
                } else {
                    if (elem_type.kind != TypeKind::Any && this_type.kind != TypeKind::Any &&
                        !types_equal(elem_type, this_type)) {
                        report(state, e->line, "array literal elements must all have the same type");
                    }
                    release_type(this_type);
                }
            }
            Type out;
            out.kind = TypeKind::Array;
            out.array_element_type = new Type(have_elem_type ? std::move(elem_type) : any_type());
            return finish(state, expr, std::move(out));
        }
        case ExprType::Index: {
            Type arr_type = infer_expr_type(state, expr->index_array, nullptr);
            Type idx_type = infer_expr_type(state, expr->index_expr, nullptr);
            if (!is_numeric_kind(idx_type.kind) && idx_type.kind != TypeKind::Any) {
                report(state, expr->line, "array index must be numeric");
            }
            release_type(idx_type);
            if (arr_type.kind == TypeKind::Any) {
                release_type(arr_type);
                return finish(state, expr, any_type());
            }
            if (arr_type.kind != TypeKind::Array) {
                report(state, expr->line, "indexing a non-Array value");
                release_type(arr_type);
                return finish(state, expr, any_type());
            }
            Type result = arr_type.array_element_type != nullptr
                              ? copy_type(*arr_type.array_element_type)
                              : any_type();
            release_type(arr_type);
            return finish(state, expr, std::move(result));
        }
    }
    return any_type();  // unreachable
}

void check_stmt(CheckState& state, Stmt* stmt);

void check_block(CheckState& state, std::vector<Stmt*>& body) {
    TypeScope scope;
    state.scopes.push_back(&scope);
    for (Stmt* s : body) {
        check_stmt(state, s);
    }
    state.scopes.pop_back();
}

void check_stmt(CheckState& state, Stmt* stmt) {
    switch (stmt->type) {
        case StmtType::VarDecl: {
            // A top-level VarDecl was already validated and registered by
            // collect_declarations (Phase A) -- state.scopes.back() ==
            // &state.globals exactly when the current statement is
            // top-level, since every nested scope (block/function) pushes
            // its own frame. Re-reporting a missing annotation here would
            // double-count it; only a *nested* VarDecl needs this check,
            // since Phase A never looks inside blocks/functions.
            bool is_top_level = (state.scopes.back() == &state.globals);
            if (stmt->var_type_annotation == nullptr) {
                if (!is_top_level) {
                    report(state, stmt->line, "missing type annotation for '" + stmt->var_name + "'");
                }
                if (stmt->var_init != nullptr) {
                    infer_and_discard(state, stmt->var_init, nullptr);
                }
                if (!is_top_level) {
                    (*state.scopes.back())[stmt->var_name] = state.new_fallback(TypeKind::Any);
                }
                break;
            }
            if (stmt->var_init != nullptr) {
                Type actual = infer_expr_type(state, stmt->var_init, stmt->var_type_annotation);
                if (actual.kind != TypeKind::Any &&
                    !types_equal(actual, *stmt->var_type_annotation)) {
                    report(state, stmt->line,
                           "initializer for '" + stmt->var_name + "' does not match its declared type");
                }
                release_type(actual);
            }
            (*state.scopes.back())[stmt->var_name] = stmt->var_type_annotation;
            break;
        }
        case StmtType::Assign: {
            if (stmt->assign_index_target != nullptr) {
                Expr* index_node = stmt->assign_index_target;
                Type arr_type = infer_expr_type(state, index_node->index_array, nullptr);
                Type idx_type = infer_expr_type(state, index_node->index_expr, nullptr);
                if (!is_numeric_kind(idx_type.kind) && idx_type.kind != TypeKind::Any) {
                    report(state, stmt->line, "array index must be numeric");
                }
                release_type(idx_type);
                const Type* elem_expected =
                    (arr_type.kind == TypeKind::Array) ? arr_type.array_element_type : nullptr;
                Type rhs = infer_expr_type(state, stmt->expr, elem_expected);
                if (arr_type.kind != TypeKind::Any && arr_type.kind != TypeKind::Array) {
                    report(state, stmt->line, "indexing a non-Array value");
                } else if (elem_expected != nullptr && elem_expected->kind != TypeKind::Any &&
                           rhs.kind != TypeKind::Any && !types_equal(rhs, *elem_expected)) {
                    report(state, stmt->line, "assigned value does not match the array's element type");
                }
                release_type(rhs);
                release_type(arr_type);
            } else if (!stmt->assign_name.empty()) {
                Type* target = lookup_variable_type(state, stmt->assign_name);
                if (target == nullptr) {
                    report(state, stmt->line,
                           "assignment to undefined variable '" + stmt->assign_name + "'");
                    infer_and_discard(state, stmt->expr, nullptr);
                } else {
                    Type rhs = infer_expr_type(state, stmt->expr, target);
                    if (target->kind != TypeKind::Any && rhs.kind != TypeKind::Any &&
                        !types_equal(rhs, *target)) {
                        report(state, stmt->line,
                               "assigned value does not match '" + stmt->assign_name + "'s type");
                    }
                    release_type(rhs);
                }
            } else {
                infer_and_discard(state, stmt->expr, nullptr);
            }
            break;
        }
        case StmtType::If: {
            Type bool_expected = bool_type();
            infer_and_discard(state, stmt->expr, &bool_expected);
            release_type(bool_expected);
            check_block(state, stmt->body);
            check_block(state, stmt->else_body);
            break;
        }
        case StmtType::While: {
            Type bool_expected = bool_type();
            infer_and_discard(state, stmt->expr, &bool_expected);
            release_type(bool_expected);
            check_block(state, stmt->body);
            break;
        }
        case StmtType::FuncDecl: {
            // Signature already validated/registered by collect_declarations;
            // here we just check the body.
            TypeScope param_scope;
            for (size_t i = 0; i < stmt->param_names.size(); ++i) {
                Type* ptype = (i < stmt->param_type_annotations.size() && stmt->param_type_annotations[i])
                                   ? stmt->param_type_annotations[i]
                                   : state.new_fallback(TypeKind::Any);
                param_scope[stmt->param_names[i]] = ptype;
            }
            std::vector<TypeScope*> saved_scopes = {&state.globals, &param_scope};
            std::swap(state.scopes, saved_scopes);
            Type* saved_return = state.current_return_type;
            state.current_return_type =
                stmt->return_type_annotation != nullptr ? stmt->return_type_annotation
                                                          : state.new_fallback(TypeKind::Any);
            for (Stmt* s : stmt->body) {
                check_stmt(state, s);
            }
            state.current_return_type = saved_return;
            std::swap(state.scopes, saved_scopes);
            break;
        }
        case StmtType::Return: {
            if (stmt->expr != nullptr) {
                Type actual = infer_expr_type(state, stmt->expr, state.current_return_type);
                if (state.current_return_type != nullptr &&
                    state.current_return_type->kind != TypeKind::Any && actual.kind != TypeKind::Any &&
                    !types_equal(actual, *state.current_return_type)) {
                    report(state, stmt->line, "returned value does not match the function's return type");
                }
                release_type(actual);
            } else if (state.current_return_type != nullptr &&
                       state.current_return_type->kind != TypeKind::Unit &&
                       state.current_return_type->kind != TypeKind::Any) {
                report(state, stmt->line, "function must return a value");
            }
            break;
        }
        case StmtType::ExprStmt:
            infer_and_discard(state, stmt->expr, nullptr);
            break;
        case StmtType::Block:
            check_block(state, stmt->body);
            break;
    }
}

// Phase A: collect every block's top-level declarations before checking
// any block's body (required -- functions/globals hoist document-wide,
// docs/tinyscript-spec.md section 3). Validates that every
// annotation typyscript requires is actually present; a missing one is a
// Diagnostic, and the declaration is registered as Any so later checks
// against it don't cascade into unrelated spurious errors.
void collect_declarations(CheckState& state, Program& program) {
    for (Stmt* stmt : program.statements) {
        if (stmt->type == StmtType::FuncDecl) {
            FunctionSig sig;
            for (size_t i = 0; i < stmt->param_names.size(); ++i) {
                Type* ptype =
                    (i < stmt->param_type_annotations.size()) ? stmt->param_type_annotations[i] : nullptr;
                if (ptype == nullptr) {
                    report(state, stmt->line, "missing type annotation for parameter '" +
                                                   stmt->param_names[i] + "' of '" + stmt->func_name + "'");
                }
                sig.param_types.push_back(ptype);  // nullptr -> treated as Any everywhere else
            }
            if (stmt->return_type_annotation == nullptr) {
                report(state, stmt->line, "function '" + stmt->func_name + "' is missing a return type "
                                           "('-> ()' if it returns nothing)");
            }
            sig.return_type = stmt->return_type_annotation;
            state.functions[stmt->func_name] = sig;
        } else if (stmt->type == StmtType::VarDecl) {
            if (stmt->var_type_annotation == nullptr) {
                report(state, stmt->line, "missing type annotation for '" + stmt->var_name + "'");
                state.globals[stmt->var_name] = state.new_fallback(TypeKind::Any);
            } else {
                state.globals[stmt->var_name] = stmt->var_type_annotation;
            }
        }
    }
}

}  // namespace

Type type_of(const TypeTable& table, const Expr* expr) {
    auto it = table.find(expr);
    return it != table.end() ? copy_type(it->second) : any_type();
}

bool typecheck_document(const std::vector<Program*>& blocks, TypeTable* out_table,
                         std::vector<Diagnostic>* diags) {
    CheckState state;
    state.table = out_table;
    state.diags = diags;
    state.scopes.push_back(&state.globals);

    // Phase A: collect every block's declarations before checking any
    // block's body (required for cross-block hoisting -- see
    // collect_declarations). Phase B: check every block's body, whether
    // or not Phase A already found problems -- diagnostics accumulate
    // from both phases, and it's all-or-nothing regardless of which phase
    // a given diagnostic came from (docs/typyscript-spec.md
    // section 4).
    for (Program* block : blocks) {
        collect_declarations(state, *block);
    }
    for (Program* block : blocks) {
        for (Stmt* stmt : block->statements) {
            check_stmt(state, stmt);
        }
    }

    for (Type* t : state.owned_fallback_types) {
        free_type(t);
    }

    return diags->empty();
}

}  // namespace tinyscript
