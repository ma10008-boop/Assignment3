#pragma once

#include <string>
#include <vector>

#include "tinyscript/ast.h"
#include "tinyscript/diagnostic.h"

namespace tinyscript {

struct ParseResult {
    Program program;
    std::vector<Diagnostic> diagnostics;
};

// Parses tinyscript/typyscript source per docs/tinyscript-spec.md
// (both dialects share one grammar -- annotations are always syntactically
// legal here; only typyscript's checker requires them, see docs/
// typyscript-spec.md). Never throws; on malformed input returns a partial
// program plus diagnostics.
ParseResult parse(const std::string& source);

}  // namespace tinyscript
