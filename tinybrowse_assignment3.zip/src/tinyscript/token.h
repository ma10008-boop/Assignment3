#pragma once

#include <string>

#include "tinyscript/numeric.h"

namespace tinyscript {

// See docs/tinyscript-spec.md section 1 (Lexical grammar).
enum class TokenType {
    Ident,
    Number,
    String,

    // keywords
    Let,
    Fn,
    If,
    Else,
    While,
    Return,
    True,
    False,
    As,

    // operators
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    EqualEqual,
    BangEqual,
    Less,
    Greater,
    LessEqual,
    GreaterEqual,
    AmpAmp,
    PipePipe,
    Bang,
    Equal,

    // punctuation
    LParen,
    RParen,
    LBrace,
    RBrace,
    LBracket,
    RBracket,
    Comma,
    Semicolon,
    Colon,
    Arrow,  // "->"

    EndOfFile,
};

struct Token {
    TokenType type;
    std::string text;                    // identifier name, string literal contents, etc.
    double number = 0;                   // valid when type == Number
    NumKind number_kind = NumKind::I32;  // valid when type == Number: the literal's kind
    bool number_kind_explicit = false;   // valid when type == Number: true iff a suffix was written
    int line;
};

}  // namespace tinyscript
