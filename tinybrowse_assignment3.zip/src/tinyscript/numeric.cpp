#include "tinyscript/numeric.h"

#include <cstring>
#include <limits>

namespace tinyscript {

const NumKind kPromotionTable[8][8] = {
    // U8
    {NumKind::U8, NumKind::U32, NumKind::U64, NumKind::U8, NumKind::I32, NumKind::I64,
     NumKind::F32, NumKind::F64},
    // U32
    {NumKind::U32, NumKind::U32, NumKind::U64, NumKind::U32, NumKind::U32, NumKind::I64,
     NumKind::F32, NumKind::F64},
    // U64
    {NumKind::U64, NumKind::U64, NumKind::U64, NumKind::U64, NumKind::U64, NumKind::U64,
     NumKind::F32, NumKind::F64},
    // I8
    {NumKind::U8, NumKind::U32, NumKind::U64, NumKind::I8, NumKind::I32, NumKind::I64,
     NumKind::F32, NumKind::F64},
    // I32
    {NumKind::I32, NumKind::U32, NumKind::U64, NumKind::I32, NumKind::I32, NumKind::I64,
     NumKind::F32, NumKind::F64},
    // I64
    {NumKind::I64, NumKind::I64, NumKind::U64, NumKind::I64, NumKind::I64, NumKind::I64,
     NumKind::F32, NumKind::F64},
    // F32
    {NumKind::F32, NumKind::F32, NumKind::F32, NumKind::F32, NumKind::F32, NumKind::F32,
     NumKind::F32, NumKind::F64},
    // F64
    {NumKind::F64, NumKind::F64, NumKind::F64, NumKind::F64, NumKind::F64, NumKind::F64,
     NumKind::F64, NumKind::F64},
};

NumKind promote_kind(NumKind a, NumKind b) {
    return kPromotionTable[static_cast<int>(a)][static_cast<int>(b)];
}

namespace {

// Unsigned arithmetic is already well-defined modular wraparound per the
// C++ standard -- no special handling needed.
template <typename T>
T unsigned_add(T a, T b) {
    return static_cast<T>(a + b);
}
template <typename T>
T unsigned_sub(T a, T b) {
    return static_cast<T>(a - b);
}
template <typename T>
T unsigned_mul(T a, T b) {
    return static_cast<T>(a * b);
}

// The one pattern every signed wrap_* function reduces to: widen both
// operands' bit patterns into the unsigned counterpart (well-defined),
// operate there (well-defined modular wraparound), then bit-reinterpret
// the result back via memcpy rather than a static_cast, so this doesn't
// even lean on merely-implementation-defined (as opposed to outright UB)
// unsigned-to-signed narrowing. File-local only -- the public API stays as
// explicit, individually-named functions (docs/instructor/
// tinyscript-design-notes.md's note on why signed overflow needs this).
template <typename UnsignedT, typename SignedT, UnsignedT (*Op)(UnsignedT, UnsignedT)>
SignedT wrap_signed_binop(SignedT a, SignedT b) {
    UnsignedT ua = static_cast<UnsignedT>(a);
    UnsignedT ub = static_cast<UnsignedT>(b);
    UnsignedT result = Op(ua, ub);
    SignedT out;
    std::memcpy(&out, &result, sizeof(out));
    return out;
}

}  // namespace

uint8_t wrap_add_u8(uint8_t a, uint8_t b) { return unsigned_add(a, b); }
uint8_t wrap_sub_u8(uint8_t a, uint8_t b) { return unsigned_sub(a, b); }
uint8_t wrap_mul_u8(uint8_t a, uint8_t b) { return unsigned_mul(a, b); }
uint32_t wrap_add_u32(uint32_t a, uint32_t b) { return unsigned_add(a, b); }
uint32_t wrap_sub_u32(uint32_t a, uint32_t b) { return unsigned_sub(a, b); }
uint32_t wrap_mul_u32(uint32_t a, uint32_t b) { return unsigned_mul(a, b); }
uint64_t wrap_add_u64(uint64_t a, uint64_t b) { return unsigned_add(a, b); }
uint64_t wrap_sub_u64(uint64_t a, uint64_t b) { return unsigned_sub(a, b); }
uint64_t wrap_mul_u64(uint64_t a, uint64_t b) { return unsigned_mul(a, b); }

int8_t wrap_add_i8(int8_t a, int8_t b) {
    return wrap_signed_binop<uint8_t, int8_t, unsigned_add<uint8_t>>(a, b);
}
int8_t wrap_sub_i8(int8_t a, int8_t b) {
    return wrap_signed_binop<uint8_t, int8_t, unsigned_sub<uint8_t>>(a, b);
}
int8_t wrap_mul_i8(int8_t a, int8_t b) {
    return wrap_signed_binop<uint8_t, int8_t, unsigned_mul<uint8_t>>(a, b);
}
int32_t wrap_add_i32(int32_t a, int32_t b) {
    return wrap_signed_binop<uint32_t, int32_t, unsigned_add<uint32_t>>(a, b);
}
int32_t wrap_sub_i32(int32_t a, int32_t b) {
    return wrap_signed_binop<uint32_t, int32_t, unsigned_sub<uint32_t>>(a, b);
}
int32_t wrap_mul_i32(int32_t a, int32_t b) {
    return wrap_signed_binop<uint32_t, int32_t, unsigned_mul<uint32_t>>(a, b);
}
int64_t wrap_add_i64(int64_t a, int64_t b) {
    return wrap_signed_binop<uint64_t, int64_t, unsigned_add<uint64_t>>(a, b);
}
int64_t wrap_sub_i64(int64_t a, int64_t b) {
    return wrap_signed_binop<uint64_t, int64_t, unsigned_sub<uint64_t>>(a, b);
}
int64_t wrap_mul_i64(int64_t a, int64_t b) {
    return wrap_signed_binop<uint64_t, int64_t, unsigned_mul<uint64_t>>(a, b);
}

namespace {

void report_div_by_zero(int line, std::vector<Diagnostic>* diags) {
    diags->push_back(Diagnostic{"integer division by zero", line});
}

}  // namespace

uint8_t wrap_div_u8(uint8_t a, uint8_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    return static_cast<uint8_t>(a / b);
}
uint8_t wrap_mod_u8(uint8_t a, uint8_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    return static_cast<uint8_t>(a % b);
}
uint32_t wrap_div_u32(uint32_t a, uint32_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    return a / b;
}
uint32_t wrap_mod_u32(uint32_t a, uint32_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    return a % b;
}
uint64_t wrap_div_u64(uint64_t a, uint64_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    return a / b;
}
uint64_t wrap_mod_u64(uint64_t a, uint64_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    return a % b;
}

int8_t wrap_div_i8(int8_t a, int8_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    if (a == std::numeric_limits<int8_t>::min() && b == -1) {
        return std::numeric_limits<int8_t>::min();  // would overflow; wraps like any other
    }
    return static_cast<int8_t>(a / b);
}
int8_t wrap_mod_i8(int8_t a, int8_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    if (a == std::numeric_limits<int8_t>::min() && b == -1) {
        return 0;
    }
    return static_cast<int8_t>(a % b);
}
int32_t wrap_div_i32(int32_t a, int32_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    if (a == std::numeric_limits<int32_t>::min() && b == -1) {
        return std::numeric_limits<int32_t>::min();
    }
    return a / b;
}
int32_t wrap_mod_i32(int32_t a, int32_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    if (a == std::numeric_limits<int32_t>::min() && b == -1) {
        return 0;
    }
    return a % b;
}
int64_t wrap_div_i64(int64_t a, int64_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    if (a == std::numeric_limits<int64_t>::min() && b == -1) {
        return std::numeric_limits<int64_t>::min();
    }
    return a / b;
}
int64_t wrap_mod_i64(int64_t a, int64_t b, int line, std::vector<Diagnostic>* diags) {
    if (b == 0) {
        report_div_by_zero(line, diags);
        return 0;
    }
    if (a == std::numeric_limits<int64_t>::min() && b == -1) {
        return 0;
    }
    return a % b;
}

}  // namespace tinyscript
