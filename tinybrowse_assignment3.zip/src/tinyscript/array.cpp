#include "tinyscript/array.h"

#include <string>

namespace tinyscript {

namespace {

bool index_in_bounds(const Value& arr, int64_t index) {
    return index >= 0 && static_cast<uint64_t>(index) < static_cast<uint64_t>(arr.array_length);
}

void report_out_of_bounds(int64_t index, size_t length, int line,
                           std::vector<Diagnostic>* diags) {
    diags->push_back(Diagnostic{"array index " + std::to_string(index) +
                                     " out of bounds (length " + std::to_string(length) + ")",
                                 line});
}

}  // namespace

Value array_new(size_t length) {
    Value v;
    v.type = ValueType::Array;
    v.array_length = length;
    if (length > 0) {
        v.payload = new Value[length];  // each default-constructed: Unit
    }
    return v;
}

size_t array_len(const Value& arr) { return arr.array_length; }

Value* array_ref(Value& arr, int64_t index, int line, std::vector<Diagnostic>* diags) {
    if (!index_in_bounds(arr, index)) {
        report_out_of_bounds(index, arr.array_length, line, diags);
        return nullptr;
    }
    return &arr.payload[index];
}

Value array_get(const Value& arr, int64_t index, int line, std::vector<Diagnostic>* diags) {
    if (!index_in_bounds(arr, index)) {
        report_out_of_bounds(index, arr.array_length, line, diags);
        return make_unit();
    }
    return copy_value(arr.payload[index]);
}

void array_set(Value& arr, int64_t index, Value val, int line, std::vector<Diagnostic>* diags) {
    Value* slot = array_ref(arr, index, line, diags);
    if (slot == nullptr) {
        free_value(&val);  // can't store it -- release whatever it owned so it doesn't leak
        return;
    }
    // Value::operator=(Value&&) already frees whatever this slot currently
    // owns before adopting `val`'s fields (see value.cpp) -- do not add an
    // extra free_value() call here, it would double-free.
    *slot = std::move(val);
}

Value array_concat(const Value& a, const Value& b) {
    Value out;
    out.type = ValueType::Array;
    uint16_t total = static_cast<uint16_t>(a.array_length + b.array_length);
    out.array_length = total;
    if (total > 0) {
        out.payload = new Value[total];
        size_t i = 0;
        for (size_t j = 0; j < a.array_length; ++j) {
            out.payload[i++] = copy_value(a.payload[j]);
        }
        for (size_t j = 0; j < b.array_length; ++j) {
            out.payload[i++] = copy_value(b.payload[j]);
        }
    }
    return out;
}

Value array_pop(Value& arr, int line, std::vector<Diagnostic>* diags) {
    if (arr.array_length == 0) {
        Value err;
        err.type = ValueType::Result;
        err.result_is_ok = false;
        err.payload = new Value();
        diags->push_back(Diagnostic{"array_pop: array is empty", line});
        return err;
    }
    // The popped slot's own storage stays right where it is -- no need to
    // heap-allocate a separate copy just to hand it back for the length of
    // one Result.
    Value out;
    out.type = ValueType::Result;
    out.result_is_ok = true;
    out.payload = &arr.payload[arr.array_length - 1];
    arr.array_length -= 1;
    return out;
}

}  // namespace tinyscript
