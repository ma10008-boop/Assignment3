#include "tinyscript/dom_api.h"

#include "tinyhtml/parser.h"

namespace tinyscript {

namespace {

Value make_ok(Value payload) {
    Value out;
    out.type = ValueType::Result;
    out.result_is_ok = true;
    out.payload = new Value(std::move(payload));
    return out;
}

Value make_err(Value payload) {
    Value out;
    out.type = ValueType::Result;
    out.result_is_ok = false;
    out.payload = new Value(std::move(payload));
    return out;
}

// First Element in document order whose `id` attribute equals `target`,
// or nullptr.
tinyhtml::Node* find_by_id(tinyhtml::Node* node, const std::string& target) {
    if (node == nullptr) {
        return nullptr;
    }
    if (node->type == tinyhtml::NodeType::Element) {
        tinyhtml::Attribute* id_attr = tinyhtml::find_attribute(node, "id");
        if (id_attr != nullptr && id_attr->value == target) {
            return node;
        }
    }
    for (tinyhtml::Node* child = node->first_child; child != nullptr; child = child->next_sibling) {
        tinyhtml::Node* found = find_by_id(child, target);
        if (found != nullptr) {
            return found;
        }
    }
    return nullptr;
}

// free_node frees one node's own subtree, not its siblings -- this frees
// an entire sibling chain (e.g. `parent`'s full child list) and detaches
// it from `parent`.
void free_all_children(tinyhtml::Node* parent) {
    tinyhtml::Node* child = parent->first_child;
    while (child != nullptr) {
        tinyhtml::Node* next = child->next_sibling;
        tinyhtml::free_node(child);
        child = next;
    }
    parent->first_child = nullptr;
}

Value make_element(tinyhtml::Node* node) {
    Value v;
    v.type = ValueType::Element;
    v.element_val = node;
    return v;
}

Value builtin_get_element_by_id(Interpreter& interp, std::vector<Value>& args, int line,
                                 std::vector<Diagnostic>* diags) {
    if (args[0].type != ValueType::String) {
        diags->push_back(Diagnostic{"getElementById expects a String id", line});
        return make_err(make_unit());
    }
    tinyhtml::Node* found = find_by_id(interp.document, args[0].string_val);
    if (found == nullptr) {
        return make_err(make_unit());
    }
    return make_ok(make_element(found));
}

Value builtin_get_attribute(Interpreter& interp, std::vector<Value>& args, int line,
                             std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Element || args[1].type != ValueType::String) {
        diags->push_back(Diagnostic{"getAttribute expects (Element, String)", line});
        return make_err(make_unit());
    }
    tinyhtml::Attribute* attr = tinyhtml::find_attribute(args[0].element_val, args[1].string_val);
    if (attr == nullptr) {
        return make_err(make_unit());
    }
    return make_ok(make_string(attr->value));
}

Value builtin_set_attribute(Interpreter& interp, std::vector<Value>& args, int line,
                             std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Element || args[1].type != ValueType::String ||
        args[2].type != ValueType::String) {
        diags->push_back(Diagnostic{"setAttribute expects (Element, String, String)", line});
        return make_unit();
    }
    tinyhtml::Node* el = args[0].element_val;
    tinyhtml::Attribute* existing = tinyhtml::find_attribute(el, args[1].string_val);
    if (existing != nullptr) {
        existing->value = args[2].string_val;
    } else {
        tinyhtml::Attribute* attr = new tinyhtml::Attribute{args[1].string_val, args[2].string_val, nullptr};
        attr->next = el->attributes;
        el->attributes = attr;
    }
    return make_unit();
}

Value builtin_set_text(Interpreter& interp, std::vector<Value>& args, int line,
                        std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Element || args[1].type != ValueType::String) {
        diags->push_back(Diagnostic{"setText expects (Element, String)", line});
        return make_unit();
    }
    tinyhtml::Node* el = args[0].element_val;
    free_all_children(el);
    tinyhtml::Node* text = tinyhtml::make_node(tinyhtml::NodeType::Text);
    text->text = args[1].string_val;
    tinyhtml::append_child(el, text);
    return make_unit();
}

// The deliberate injection surface -- see docs/instructor/
// tinyscript-design-notes.md (once written) and docs/
// tinyscript-spec.md section 7: `html` is parsed and spliced in with no
// escaping or sanitization at all.
Value builtin_set_html(Interpreter& interp, std::vector<Value>& args, int line,
                        std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Element || args[1].type != ValueType::String) {
        diags->push_back(Diagnostic{"setHtml expects (Element, String)", line});
        return make_unit();
    }
    tinyhtml::Node* el = args[0].element_val;
    tinyhtml::ParseResult parsed = tinyhtml::parse(args[1].string_val);
    // Fragment-level parse diagnostics are intentionally dropped, not
    // forwarded as tinyscript Diagnostics -- setHtml is documented as
    // unsanitized/unvalidated, and a malformed fragment still gets
    // spliced in best-effort, matching tinyhtml's own "partial tree on
    // error" behavior for a full document.
    free_all_children(el);
    tinyhtml::Node* child = parsed.document->first_child;
    while (child != nullptr) {
        tinyhtml::Node* next = child->next_sibling;
        child->next_sibling = nullptr;  // append_child relinks it correctly
        tinyhtml::append_child(el, child);
        child = next;
    }
    parsed.document->first_child = nullptr;  // ownership already transferred to `el`
    tinyhtml::free_node(parsed.document);    // frees just the now-empty Document wrapper
    return make_unit();
}

Value builtin_first_child(Interpreter& interp, std::vector<Value>& args, int line,
                           std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Element) {
        diags->push_back(Diagnostic{"firstChild expects an Element", line});
        return make_err(make_unit());
    }
    return make_ok(make_element(args[0].element_val->first_child));
}

// Recorded only as argument validation for now -- nothing fires this
// until an interactive renderer exists to dispatch click events at all
// (docs/tinyscript-spec.md section 7); actually persisting a
// registry entry is deferred until there's a consumer for it.
Value builtin_on(Interpreter& interp, std::vector<Value>& args, int line,
                  std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Element || args[1].type != ValueType::String ||
        args[2].type != ValueType::String) {
        diags->push_back(Diagnostic{"on expects (Element, String, String)", line});
        return make_unit();
    }
    if (args[1].string_val != "click") {
        diags->push_back(Diagnostic{"on: unrecognized event '" + args[1].string_val + "'", line});
    }
    return make_unit();
}

}  // namespace

void register_dom_api(Interpreter& interp, tinyhtml::Node* document) {
    interp.document = document;
    register_builtin(interp, "getElementById", 1, builtin_get_element_by_id);
    register_builtin(interp, "getAttribute", 2, builtin_get_attribute);
    register_builtin(interp, "setAttribute", 3, builtin_set_attribute);
    register_builtin(interp, "setText", 2, builtin_set_text);
    register_builtin(interp, "setHtml", 2, builtin_set_html);
    register_builtin(interp, "on", 3, builtin_on);
    register_builtin(interp, "firstChild", 1, builtin_first_child);
}

}  // namespace tinyscript
