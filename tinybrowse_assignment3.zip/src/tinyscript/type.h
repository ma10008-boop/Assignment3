#pragma once

namespace tinyscript {

// The static type domain used by typyscript's checker (tinyscript/
// typecheck.h) and, forward-looking, by any other load-time analysis tool
// built on top of it. Deliberately a separate enum from NumKind
// (tinyscript/numeric.h) and ValueType (tinyscript/value.h) -- see
// docs/instructor/tinyscript-design-notes.md.
//
// `Any` is the "no static type information" sentinel a checker-table
// lookup returns for a plain tinyscript expression. It is NOT spellable
// anywhere in typyscript's grammar (docs/typyscript-spec.md
// section 1) -- the parser can never produce a Type with this kind for an
// annotation, by construction. See docs/instructor/typyscript-design-notes.md.
enum class TypeKind {
    Any,
    Unit,
    U8,
    U32,
    U64,
    I8,
    I32,
    I64,
    F32,
    F64,
    String,
    Bool,
    Element,
    Function,
    Result,
    Array,
};

struct Type {
    TypeKind kind = TypeKind::Any;
    Type* result_ok_type = nullptr;      // Result only, owned
    Type* result_err_type = nullptr;     // Result only, owned
    Type* array_element_type = nullptr;  // Array only, owned

    // Not `= default`: same reasoning as tinyscript::Value (value.h) --
    // a raw pointer member's compiler-generated "move" is just a member-
    // wise copy of the pointer, which would leave the moved-from Type's
    // owned sub-Type pointers non-null too (a double-free waiting to
    // happen). Implemented for real in type.cpp.
    Type() = default;
    Type(const Type&) = delete;
    Type& operator=(const Type&) = delete;
    Type(Type&& other) noexcept;
    Type& operator=(Type&& other) noexcept;
};

// Allocates a Type with `new`. Caller owns the result.
Type* make_type(TypeKind kind);

// Recursively frees `t` and every Type it owns. Call exactly once per
// tree, at the point where the tree's owner is done with it -- same
// pattern as tinyhtml::free_node / free_expr. `t` must itself be heap-
// allocated (e.g. an AST annotation, or another Type's sub-Type field) --
// this deletes `t`, so it must never be called on a stack-local Type.
void free_type(Type* t);

// Frees `t`'s owned sub-Types (result_ok_type, result_err_type,
// array_element_type) and nulls them out, but does not delete `t` itself
// -- for a Type that's a local variable rather than independently heap-
// owned (the same relationship tinyscript::free_value has to a local
// Value). This is what typecheck.cpp calls on every intermediate Type it
// computes and then discards.
void release_type(Type& t);

// Deep-copies `t`, including (recursively) any owned sub-Types.
Type copy_type(const Type& t);

}  // namespace tinyscript
