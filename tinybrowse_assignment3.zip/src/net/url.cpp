#include "net/url.h"

#include <cctype>
#include <vector>

namespace net {

namespace {

const std::string kScheme = "http://";

// True if `href` has some scheme prefix other than "http://" -- a literal
// ':' before the first '/' ("https:", "mailto:", "javascript:", ...).
// starts_with_scheme() (below) has already ruled out an actual http://
// prefix by the time this is checked in resolve_url().
bool looks_like_other_scheme(const std::string& href) {
    size_t colon = href.find(':');
    size_t slash = href.find('/');
    return colon != std::string::npos && (slash == std::string::npos || colon < slash);
}

bool starts_with_scheme(const std::string& url) {
    if (url.size() < kScheme.size()) {
        return false;
    }
    for (size_t i = 0; i < kScheme.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(url[i])) != kScheme[i]) {
            return false;
        }
    }
    return true;
}

bool parse_port(const std::string& digits, int* out) {
    if (digits.empty()) {
        return false;
    }
    int value = 0;
    for (char c : digits) {
        if (!std::isdigit(static_cast<unsigned char>(c))) {
            return false;
        }
        value = value * 10 + (c - '0');
        if (value > 65535) {
            return false;
        }
    }
    if (value < 1) {
        return false;
    }
    *out = value;
    return true;
}

}  // namespace

bool parse_url(const std::string& url, Url* out) {
    if (!starts_with_scheme(url)) {
        return false;
    }
    std::string rest = url.substr(kScheme.size());

    size_t path_start = rest.find('/');
    std::string authority = path_start == std::string::npos ? rest : rest.substr(0, path_start);
    std::string path = path_start == std::string::npos ? "/" : rest.substr(path_start);

    size_t colon = authority.find(':');
    std::string host = colon == std::string::npos ? authority : authority.substr(0, colon);
    if (host.empty()) {
        return false;
    }

    int port = 80;
    if (colon != std::string::npos) {
        if (!parse_port(authority.substr(colon + 1), &port)) {
            return false;
        }
    }

    out->host = host;
    out->port = port;
    out->path = path;
    return true;
}

bool resolve_url(const std::string& base, const std::string& href, std::string* out) {
    if (starts_with_scheme(href)) {
        *out = kScheme + href.substr(kScheme.size());  // normalize scheme casing
        return true;
    }
    if (looks_like_other_scheme(href)) {
        return false;
    }

    Url base_url;
    if (!parse_url(base, &base_url)) {
        return false;
    }

    std::string combined_path;
    if (!href.empty() && href[0] == '/') {
        combined_path = href;
    } else {
        size_t last_slash = base_url.path.rfind('/');
        std::string base_dir = last_slash == std::string::npos ? "/" : base_url.path.substr(0, last_slash + 1);
        combined_path = base_dir + href;
    }

    // Collapse "." and ".." segments (splitting only on '/', so a
    // "?query"/"#fragment" trailing the last segment rides along as part
    // of it, untouched).
    std::vector<std::string> stack;
    size_t pos = 0;
    while (pos <= combined_path.size()) {
        size_t next = combined_path.find('/', pos);
        std::string segment =
            combined_path.substr(pos, next == std::string::npos ? std::string::npos : next - pos);
        if (segment == "..") {
            if (!stack.empty()) {
                stack.pop_back();
            }
        } else if (!segment.empty() && segment != ".") {
            stack.push_back(segment);
        }
        if (next == std::string::npos) {
            break;
        }
        pos = next + 1;
    }

    std::string resolved_path = "/";
    for (size_t i = 0; i < stack.size(); ++i) {
        resolved_path += stack[i];
        if (i + 1 < stack.size()) {
            resolved_path += '/';
        }
    }
    // A combined path ending in '/' names a directory, not the file above
    // it -- preserve that distinction through the collapse above.
    if (!combined_path.empty() && combined_path.back() == '/' && resolved_path.back() != '/') {
        resolved_path += '/';
    }

    std::string host_part =
        base_url.port == 80 ? base_url.host : base_url.host + ":" + std::to_string(base_url.port);
    *out = "http://" + host_part + resolved_path;
    return true;
}

}  // namespace net
