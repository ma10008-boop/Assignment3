#include "net/http_client.h"

#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "net/url.h"

namespace net {

namespace {

const int kTimeoutSeconds = 5;
const size_t kRecvChunk = 4096;

FetchResult error_result(const std::string& message) {
    FetchResult result;
    result.ok = false;
    result.error = message;
    result.status_code = 0;
    return result;
}

bool set_timeout(int fd) {
    struct timeval tv;
    tv.tv_sec = kTimeoutSeconds;
    tv.tv_usec = 0;
    return setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) == 0 &&
           setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) == 0;
}

// Resolves host:port and connects to the first address that accepts,
// trying each candidate `getaddrinfo` returns in turn.
bool connect_to(const std::string& host, int port, int* out_fd, std::string* error) {
    struct addrinfo hints;
    std::memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    struct addrinfo* results = nullptr;
    int rc = getaddrinfo(host.c_str(), std::to_string(port).c_str(), &hints, &results);
    if (rc != 0) {
        *error = std::string("could not resolve host: ") + gai_strerror(rc);
        return false;
    }

    bool connected = false;
    for (struct addrinfo* addr = results; addr != nullptr; addr = addr->ai_next) {
        int fd = socket(addr->ai_family, addr->ai_socktype, addr->ai_protocol);
        if (fd < 0) {
            continue;
        }
        if (!set_timeout(fd)) {
            close(fd);
            continue;
        }
        if (connect(fd, addr->ai_addr, addr->ai_addrlen) == 0) {
            *out_fd = fd;
            connected = true;
            break;
        }
        close(fd);
    }
    freeaddrinfo(results);

    if (!connected) {
        *error = "could not connect to " + host + ":" + std::to_string(port);
    }
    return connected;
}

bool send_all(int fd, const std::string& data, std::string* error) {
    size_t sent = 0;
    while (sent < data.size()) {
        ssize_t n = send(fd, data.data() + sent, data.size() - sent, 0);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            *error = std::string("write failed: ") + std::strerror(errno);
            return false;
        }
        sent += static_cast<size_t>(n);
    }
    return true;
}

// Reads more bytes into `buffer`, enforcing the response-size cap.
// Returns 1 on data read, 0 on a clean EOF, -1 on error (with *error set).
int recv_more(int fd, std::string* buffer, std::string* error) {
    if (buffer->size() >= kMaxResponseBytes) {
        *error = "response exceeded maximum size";
        return -1;
    }
    char chunk[kRecvChunk];
    for (;;) {
        ssize_t n = recv(fd, chunk, sizeof(chunk), 0);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            *error = std::string("read failed: ") + std::strerror(errno);
            return -1;
        }
        if (n == 0) {
            return 0;
        }
        buffer->append(chunk, static_cast<size_t>(n));
        return 1;
    }
}

// Parses every "Name: value" line in `headers` (the status line included --
// it has no colon, so it's silently skipped). Keys are lowercased; if a
// header is repeated, the first occurrence wins.
std::map<std::string, std::string> parse_headers(const std::string& headers) {
    std::map<std::string, std::string> result;
    size_t pos = 0;
    while (pos < headers.size()) {
        size_t line_end = headers.find("\r\n", pos);
        if (line_end == std::string::npos) {
            line_end = headers.size();
        }
        std::string line = headers.substr(pos, line_end - pos);
        size_t colon = line.find(':');
        if (colon != std::string::npos) {
            std::string key = line.substr(0, colon);
            for (char& c : key) {
                c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            }
            size_t value_start = colon + 1;
            while (value_start < line.size() && line[value_start] == ' ') {
                ++value_start;
            }
            result.emplace(std::move(key), line.substr(value_start));
        }
        pos = line_end + 2;
    }
    return result;
}

bool parse_status_line(const std::string& headers, int* status_code) {
    size_t line_end = headers.find("\r\n");
    std::string status_line = headers.substr(0, line_end);
    size_t first_space = status_line.find(' ');
    if (first_space == std::string::npos) {
        return false;
    }
    size_t second_space = status_line.find(' ', first_space + 1);
    std::string code_str = second_space == std::string::npos
                                ? status_line.substr(first_space + 1)
                                : status_line.substr(first_space + 1, second_space - first_space - 1);
    if (code_str.empty()) {
        return false;
    }
    for (char c : code_str) {
        if (!std::isdigit(static_cast<unsigned char>(c))) {
            return false;
        }
    }
    *status_code = std::atoi(code_str.c_str());
    return true;
}

}  // namespace

FetchResult fetch(const std::string& url) {
    Url parsed;
    if (!parse_url(url, &parsed)) {
        return error_result("invalid or unsupported URL (only http:// is supported)");
    }

    int fd = -1;
    std::string error;
    if (!connect_to(parsed.host, parsed.port, &fd, &error)) {
        return error_result(error);
    }

    std::string host_header = parsed.port == 80 ? parsed.host : parsed.host + ":" + std::to_string(parsed.port);
    std::string request =
        "GET " + parsed.path + " HTTP/1.1\r\nHost: " + host_header + "\r\nConnection: close\r\n\r\n";
    if (!send_all(fd, request, &error)) {
        close(fd);
        return error_result(error);
    }

    std::string buffer;
    size_t header_end = std::string::npos;
    while (header_end == std::string::npos) {
        int rc = recv_more(fd, &buffer, &error);
        if (rc < 0) {
            close(fd);
            return error_result(error);
        }
        if (rc == 0) {
            close(fd);
            return error_result("connection closed before headers were complete");
        }
        header_end = buffer.find("\r\n\r\n");
    }

    std::string headers = buffer.substr(0, header_end);
    std::string body = buffer.substr(header_end + 4);

    int status_code = 0;
    if (!parse_status_line(headers, &status_code)) {
        close(fd);
        return error_result("malformed HTTP status line");
    }

    std::map<std::string, std::string> parsed_headers = parse_headers(headers);
    auto content_length_it = parsed_headers.find("content-length");
    std::string content_length_str =
        content_length_it != parsed_headers.end() ? content_length_it->second : "";
    if (!content_length_str.empty()) {
        for (char c : content_length_str) {
            if (!std::isdigit(static_cast<unsigned char>(c))) {
                close(fd);
                return error_result("malformed Content-Length header");
            }
        }
        size_t content_length = std::strtoul(content_length_str.c_str(), nullptr, 10);
        while (body.size() < content_length) {
            int rc = recv_more(fd, &buffer, &error);
            if (rc < 0) {
                close(fd);
                return error_result(error);
            }
            if (rc == 0) {
                close(fd);
                return error_result("connection closed before full response body was received");
            }
            body = buffer.substr(header_end + 4);
        }
        body.resize(content_length);
    } else {
        for (;;) {
            int rc = recv_more(fd, &buffer, &error);
            if (rc < 0) {
                close(fd);
                return error_result(error);
            }
            if (rc == 0) {
                break;
            }
            body = buffer.substr(header_end + 4);
        }
    }

    close(fd);

    FetchResult result;
    result.ok = true;
    result.status_code = status_code;
    result.body = body;
    result.headers = std::move(parsed_headers);
    return result;
}

}  // namespace net
