#pragma once

#include <string>
#include <vector>

#include "tinyhtml/dom.h"

namespace render {

// One line of already-styled output text, ready to print. Any ANSI escape
// codes are embedded directly in `text`. See docs/ARCHITECTURE.md for
// where this sits in the render pipeline.
struct Line {
    std::string text;
};

struct LayoutResult {
    std::vector<Line> lines;
    // links[i] is the href of the (i+1)'th link encountered, in document
    // order -- matches the inline "[i+1]" marker layout() attaches to that
    // link's text, and the "References" line layout() appends for it.
    std::vector<std::string> links;
};

// Lays out `document` into a sequence of terminal lines wrapped to
// `width` columns: block tags (h1-h3, p, div, ul, ol/li) each start a new
// group of lines, separated by one blank line from the next group (but not
// between consecutive <li> items in the same list); inline tags (b, i, u,
// a, span, br) contribute styled text within their enclosing block. `<title>`
// and `<script>` contribute no visible lines.
//
// Every <a href> with a non-empty href gets a bracketed number appended to
// its text (e.g. "click[1]", unstyled, attached with no space so it wraps
// as part of the same word) and an entry in the returned links list; once
// the whole document is laid out, a trailing "References" block lists
// "   [N] <href>" for each one, lynx -dump style -- this is what makes a
// rendered page's links resolvable by number for browser::run_repl. An
// `<a>` with no href attribute (or an empty one) is styled but not
// numbered, since there's nothing to navigate to.
LayoutResult layout(tinyhtml::Node* document, int width);

}  // namespace render
