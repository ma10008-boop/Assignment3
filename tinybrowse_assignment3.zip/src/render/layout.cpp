#include "render/layout.h"

#include <string>
#include <vector>

namespace render {

namespace {

constexpr const char* kReset = "\x1b[0m";

// The only visual dimensions tinyhtml's fixed tag set needs (docs/
// tinyhtml-spec.md section 3) -- no color, no font size, since a terminal
// can't render either meaningfully.
struct Style {
    bool bold = false;
    bool italic = false;
    bool underline = false;
};

bool style_eq(const Style& a, const Style& b) {
    return a.bold == b.bold && a.italic == b.italic && a.underline == b.underline;
}

bool style_none(const Style& s) { return !s.bold && !s.italic && !s.underline; }

// A small, fixed enumeration of the combinations tinyhtml's tags can
// actually produce (nesting b/i/u three deep at most) -- explicit branches
// read more clearly here than building an SGR parameter list at runtime.
const char* sgr_code(const Style& s) {
    if (s.bold && s.italic && s.underline) return "\x1b[1;3;4m";
    if (s.bold && s.underline) return "\x1b[1;4m";
    if (s.bold && s.italic) return "\x1b[1;3m";
    if (s.italic && s.underline) return "\x1b[3;4m";
    if (s.bold) return "\x1b[1m";
    if (s.italic) return "\x1b[3m";
    if (s.underline) return "\x1b[4m";
    return nullptr;
}

Style style_for_tag(const std::string& tag, Style current) {
    if (tag == "b") {
        current.bold = true;
    } else if (tag == "i") {
        current.italic = true;
    } else if (tag == "u" || tag == "a") {
        current.underline = true;
    }
    return current;
}

bool is_space(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r'; }

// One contiguous, unstyled sub-run within a Token -- a Token can carry more
// than one of these when a style boundary falls in the middle of an
// unbreakable chunk (e.g. "<b>tinyhtml</b>," has no whitespace between the
// bold word and the comma, so they must wrap as one unit, but they're two
// different styles).
struct StyledRun {
    std::string text;
    Style style;
};

// One maximal run of non-whitespace content -- the atomic unit word-wrap
// breaks between, never inside.
struct Token {
    std::vector<StyledRun> runs;
    int visible_length = 0;  // sum of runs' text lengths; no escape bytes to exclude yet
    bool break_before = false;  // a <br> occurred since the previous token
};

// Flattens a block's inline descendants (text, b/i/u/a/span/br) into
// whitespace-collapsed Tokens, tracking active style as a stack implicitly
// via recursion. docs/tinyhtml-spec.md section 1: whitespace inside
// TEXT is significant in the DOM, but "the renderer, not the parser, is
// responsible for any collapsing" -- this is that collapsing.
class Tokenizer {
public:
    void add_text(const std::string& text, const Style& style) {
        size_t i = 0;
        while (i < text.size()) {
            if (is_space(text[i])) {
                flush();
                ++i;
                continue;
            }
            size_t start = i;
            while (i < text.size() && !is_space(text[i])) {
                ++i;
            }
            std::string chunk = text.substr(start, i - start);
            if (!current_.runs.empty() && style_eq(current_.runs.back().style, style)) {
                current_.runs.back().text += chunk;
            } else {
                current_.runs.push_back(StyledRun{chunk, style});
            }
            current_.visible_length += static_cast<int>(chunk.size());
            has_pending_ = true;
        }
    }

    void add_break() {
        flush();
        pending_break_ = true;
    }

    void flush() {
        if (has_pending_) {
            current_.break_before = pending_break_;
            tokens.push_back(std::move(current_));
            current_ = Token{};
            has_pending_ = false;
            pending_break_ = false;
        }
    }

    std::vector<Token> tokens;

private:
    Token current_;
    bool has_pending_ = false;
    bool pending_break_ = false;
};

void collect_inline(tinyhtml::Node* node, Style style, Tokenizer* tok, std::vector<std::string>* links) {
    for (tinyhtml::Node* child = node->first_child; child != nullptr; child = child->next_sibling) {
        if (child->type == tinyhtml::NodeType::Text) {
            tok->add_text(child->text, style);
        } else if (child->type == tinyhtml::NodeType::Element) {
            if (child->tag_name == "br") {
                tok->add_break();
            } else if (child->tag_name == "ul" || child->tag_name == "ol") {
                continue;  // a nested list is its own block, not inline content
            } else if (child->tag_name == "a") {
                collect_inline(child, style_for_tag(child->tag_name, style), tok, links);
                tinyhtml::Attribute* href = tinyhtml::find_attribute(child, "href");
                if (href != nullptr && !href->value.empty()) {
                    links->push_back(href->value);
                    // No space before "[N]" -- add_text continues the
                    // currently-open token rather than starting a new one,
                    // so "click[1]" wraps as a single unbreakable unit.
                    tok->add_text("[" + std::to_string(links->size()) + "]", Style{});
                }
            } else {
                collect_inline(child, style_for_tag(child->tag_name, style), tok, links);
            }
        }
    }
}

// Where a wrapped block's lines get their leading text: `first_indent`
// prefixes the first line (e.g. a list bullet), `cont_indent` prefixes
// every wrapped continuation line (blank-padded to the same width, so
// wrapped text lines up under the first line's content, not its bullet).
struct BlockContext {
    int width;
    std::string first_indent;
    std::string cont_indent;
};

void wrap_tokens_into(const std::vector<Token>& tokens, const BlockContext& ctx, std::vector<Line>* out) {
    if (tokens.empty()) {
        // An empty paragraph contributes nothing, but an empty list item
        // should still show its bullet.
        if (!ctx.first_indent.empty()) {
            out->push_back(Line{ctx.first_indent});
        }
        return;
    }

    std::string line = ctx.first_indent;
    int line_visible = static_cast<int>(ctx.first_indent.size());
    bool line_has_content = false;
    Style open_style{};  // style currently left open in `line`

    auto close_style = [&]() {
        if (!style_none(open_style)) {
            line += kReset;
            open_style = Style{};
        }
    };
    auto start_new_line = [&]() {
        close_style();
        out->push_back(Line{line});
        line = ctx.cont_indent;
        line_visible = static_cast<int>(ctx.cont_indent.size());
        line_has_content = false;
    };

    for (const Token& tok : tokens) {
        if (tok.break_before && line_has_content) {
            start_new_line();
        }
        int needed = tok.visible_length + (line_has_content ? 1 : 0);
        if (line_has_content && line_visible + needed > ctx.width) {
            start_new_line();
        }
        if (line_has_content) {
            // The separator space only needs to break the open style if the
            // upcoming token doesn't continue it -- otherwise two adjacent
            // same-styled tokens (e.g. a heading's words) should stay one
            // continuous span rather than closing/reopening at every word.
            if (!style_eq(open_style, tok.runs.front().style)) {
                close_style();
            }
            line += ' ';
            line_visible += 1;
        }
        for (const StyledRun& run : tok.runs) {
            if (!style_eq(open_style, run.style)) {
                close_style();
                const char* code = sgr_code(run.style);
                if (code != nullptr) {
                    line += code;
                }
                open_style = run.style;
            }
            line += run.text;
        }
        line_visible += tok.visible_length;
        line_has_content = true;
    }
    close_style();
    out->push_back(Line{line});
}

void layout_paragraph_like(tinyhtml::Node* node, Style base_style, int width, std::vector<Line>* out,
                            std::vector<std::string>* links) {
    Tokenizer tok;
    collect_inline(node, base_style, &tok, links);
    tok.flush();
    wrap_tokens_into(tok.tokens, BlockContext{width, "", ""}, out);
}

void layout_list(tinyhtml::Node* list_node, bool ordered, int width, int indent_level, std::vector<Line>* out,
                  std::vector<std::string>* links) {
    int item_number = 1;
    for (tinyhtml::Node* child = list_node->first_child; child != nullptr; child = child->next_sibling) {
        if (child->type != tinyhtml::NodeType::Element || child->tag_name != "li") {
            continue;  // the grammar only allows <li> children; skip anything else defensively
        }
        std::string base_indent(static_cast<size_t>(indent_level) * 2, ' ');
        std::string marker = ordered ? (std::to_string(item_number) + ". ") : std::string("- ");
        ++item_number;
        std::string first_indent = base_indent + marker;
        std::string cont_indent(first_indent.size(), ' ');

        Tokenizer tok;
        collect_inline(child, Style{}, &tok, links);
        tok.flush();
        wrap_tokens_into(tok.tokens, BlockContext{width, first_indent, cont_indent}, out);

        for (tinyhtml::Node* gc = child->first_child; gc != nullptr; gc = gc->next_sibling) {
            if (gc->type == tinyhtml::NodeType::Element && (gc->tag_name == "ul" || gc->tag_name == "ol")) {
                layout_list(gc, gc->tag_name == "ol", width, indent_level + 1, out, links);
            }
        }
    }
}

void layout_blocks(tinyhtml::Node* parent, int width, std::vector<Line>* out, std::vector<std::string>* links) {
    bool need_blank_before_next = false;

    for (tinyhtml::Node* child = parent->first_child; child != nullptr; child = child->next_sibling) {
        if (child->type == tinyhtml::NodeType::Text) {
            // Stray top-level text: treat it like an anonymous paragraph.
            // Whitespace-only text (typical source-formatting indentation
            // between tags) produces no tokens and shouldn't force a blank
            // line by itself.
            Tokenizer tok;
            tok.add_text(child->text, Style{});
            tok.flush();
            if (tok.tokens.empty()) {
                continue;
            }
            if (need_blank_before_next) {
                out->push_back(Line{""});
            }
            wrap_tokens_into(tok.tokens, BlockContext{width, "", ""}, out);
            need_blank_before_next = true;
            continue;
        }
        if (child->type != tinyhtml::NodeType::Element) {
            continue;
        }

        const std::string& tag = child->tag_name;
        if (tag == "title" || tag == "script" || tag == "br") {
            continue;  // metadata/script: no visible line; a bare top-level <br> is a no-op
        }

        if (tag == "h1" || tag == "h2" || tag == "h3" || tag == "p") {
            if (need_blank_before_next) {
                out->push_back(Line{""});
            }
            Style s{};
            if (tag == "h1") {
                s.bold = true;
                s.underline = true;
            } else if (tag == "h2" || tag == "h3") {
                s.bold = true;
            }
            layout_paragraph_like(child, s, width, out, links);
            need_blank_before_next = true;
        } else if (tag == "div") {
            std::vector<Line> inner;
            layout_blocks(child, width, &inner, links);
            if (!inner.empty()) {
                if (need_blank_before_next) {
                    out->push_back(Line{""});
                }
                for (Line& l : inner) {
                    out->push_back(std::move(l));
                }
                need_blank_before_next = true;
            }
        } else if (tag == "ul" || tag == "ol") {
            std::vector<Line> inner;
            layout_list(child, tag == "ol", width, 0, &inner, links);
            if (!inner.empty()) {
                if (need_blank_before_next) {
                    out->push_back(Line{""});
                }
                for (Line& l : inner) {
                    out->push_back(std::move(l));
                }
                need_blank_before_next = true;
            }
        }
        // Any other tag (b/i/u/a/span/li) appearing directly here is
        // malformed per the grammar (they're inline-only, or li-outside-
        // a-list) -- ignored rather than crashing on it.
    }
}

// lynx -dump style: a blank line, "References", a blank line, then one
// "   [N] <href>" per link in the order layout_blocks encountered them.
void append_references(std::vector<Line>* out, const std::vector<std::string>& links) {
    if (links.empty()) {
        return;
    }
    out->push_back(Line{""});
    out->push_back(Line{"References"});
    out->push_back(Line{""});
    for (size_t i = 0; i < links.size(); ++i) {
        out->push_back(Line{"   [" + std::to_string(i + 1) + "] " + links[i]});
    }
}

}  // namespace

LayoutResult layout(tinyhtml::Node* document, int width) {
    LayoutResult result;
    layout_blocks(document, width, &result.lines, &result.links);
    append_references(&result.lines, result.links);
    return result;
}

}  // namespace render
