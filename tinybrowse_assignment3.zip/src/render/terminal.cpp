#include "render/terminal.h"

namespace render {

void print_to_terminal(const std::vector<Line>& lines, std::ostream& out) {
    for (const Line& line : lines) {
        out << line.text << '\n';
    }
}

}  // namespace render
