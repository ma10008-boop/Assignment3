#pragma once

#include <string>
#include <vector>

#include "tinyhtml/diagnostic.h"
#include "tinyhtml/dom.h"

namespace tinyhtml {

struct ParseResult {
    Node* document;  // never nullptr; owned by caller, free with free_node()
    std::vector<Diagnostic> diagnostics;
};

// Parses tinyhtml source per docs/tinyhtml-spec.md. Never throws; on
// malformed input returns a partial (possibly childless) document plus
// diagnostics rather than crashing (spec section 6, "Robustness
// requirements").
ParseResult parse(const std::string& source);

}  // namespace tinyhtml
