#include "tinyhtml/dom.h"

namespace tinyhtml {

Node* make_node(NodeType type) {
    Node* node = new Node();
    node->type = type;
    return node;
}

void free_node(Node* node) {
    if (node == nullptr) {
        return;
    }

    for (Node* child = node->first_child; child != nullptr;) {
        Node* next = child->next_sibling;
        free_node(child);
        child = next;
    }

    for (Attribute* attr = node->attributes; attr != nullptr;) {
        Attribute* next = attr->next;
        delete attr;
        attr = next;
    }

    delete node;
}

void append_child(Node* parent, Node* child) {
    child->parent = parent;
    child->next_sibling = nullptr;

    if (parent->first_child == nullptr) {
        parent->first_child = child;
        return;
    }

    Node* last = parent->first_child;
    while (last->next_sibling != nullptr) {
        last = last->next_sibling;
    }
    last->next_sibling = child;
}

Attribute* find_attribute(Node* node, const std::string& name) {
    if (node == nullptr || node->type != NodeType::Element) {
        return nullptr;
    }
    for (Attribute* attr = node->attributes; attr != nullptr; attr = attr->next) {
        if (attr->name == name) {
            return attr;
        }
    }
    return nullptr;
}

}  // namespace tinyhtml
