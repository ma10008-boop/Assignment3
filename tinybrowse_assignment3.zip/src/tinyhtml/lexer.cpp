#include "tinyhtml/lexer.h"

#include <cctype>
#include <utility>
#include <vector>

namespace tinyhtml {

namespace {

// Decodes the five recognized entities (docs/tinyhtml-spec.md section
// 1); an unrecognized "&...;" sequence (or a lone "&") passes through
// unchanged. Never used on <script> raw text -- see lex()'s script handling.
std::string decode_entities(const std::string& raw) {
    static const std::pair<const char*, char> kEntities[] = {
        {"&lt;", '<'}, {"&gt;", '>'}, {"&amp;", '&'}, {"&quot;", '"'}, {"&apos;", '\''},
    };

    std::string out;
    out.reserve(raw.size());
    size_t i = 0;
    while (i < raw.size()) {
        if (raw[i] == '&') {
            bool matched = false;
            for (const auto& entity : kEntities) {
                size_t len = std::string(entity.first).size();
                if (raw.compare(i, len, entity.first) == 0) {
                    out.push_back(entity.second);
                    i += len;
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                out.push_back('&');
                ++i;
            }
        } else {
            out.push_back(raw[i]);
            ++i;
        }
    }
    return out;
}

bool is_ident_start(char c) {
    return std::isalpha(static_cast<unsigned char>(c)) != 0;
}

bool is_ident_char(char c) {
    return std::isalnum(static_cast<unsigned char>(c)) != 0 || c == '-';
}

// Single-pass tokenizer. All state lives here instead of being threaded
// through free-function parameters -- this is a plain struct with methods,
// not a class hierarchy (docs/STYLE.md's "structure over hierarchy" still
// applies: there is exactly one lexer implementation, no swappable backends).
struct Lexer {
    const std::string& source;
    size_t pos = 0;
    int line = 1;
    std::vector<Token> tokens;

    explicit Lexer(const std::string& src) : source(src) {}

    char peek(size_t offset = 0) const {
        size_t i = pos + offset;
        return i < source.size() ? source[i] : '\0';
    }

    char advance() {
        char c = source[pos++];
        if (c == '\n') {
            ++line;
        }
        return c;
    }

    bool at_end() const { return pos >= source.size(); }

    void skip_whitespace() {
        while (!at_end() && std::isspace(static_cast<unsigned char>(peek()))) {
            advance();
        }
    }

    std::string read_ident() {
        std::string out;
        while (!at_end() && is_ident_char(peek())) {
            out.push_back(advance());
        }
        return out;
    }

    // Reads a '"'-delimited attribute string. tinyhtml strings have no
    // escape sequences (docs/tinyhtml-spec.md section 1) -- the
    // closing '"' always ends the string. An unterminated string reads to
    // EOF rather than looping forever.
    std::string read_string() {
        advance();  // consume opening '"'
        std::string raw;
        while (!at_end() && peek() != '"') {
            raw.push_back(advance());
        }
        if (!at_end()) {
            advance();  // consume closing '"'
        }
        return decode_entities(raw);
    }

    void lex_tag_open_and_attributes() {
        int open_line = line;
        advance();  // consume '<'
        std::string tag_name = read_ident();
        tokens.push_back(Token{TokenType::TagOpen, tag_name, open_line});

        for (;;) {
            skip_whitespace();
            if (peek() == '/' && peek(1) == '>') {
                advance();
                advance();
                tokens.push_back(Token{TokenType::TagSelfClose, "", line});
                return;
            }
            if (peek() == '>') {
                advance();
                tokens.push_back(Token{TokenType::TagEnd, "", line});
                lex_script_raw_text_if_needed(tag_name);
                return;
            }
            if (at_end()) {
                // Malformed: tag never closed. Stop here -- the parser will
                // notice the missing TagEnd/TagSelfClose and report it.
                return;
            }
            if (is_ident_start(peek())) {
                int attr_line = line;
                std::string attr_name = read_ident();
                tokens.push_back(Token{TokenType::Ident, attr_name, attr_line});
                skip_whitespace();
                if (peek() == '=') {
                    advance();
                    tokens.push_back(Token{TokenType::Equals, "", line});
                    skip_whitespace();
                    if (peek() == '"') {
                        int str_line = line;
                        std::string value = read_string();
                        tokens.push_back(Token{TokenType::String, value, str_line});
                    }
                    // A missing quoted value here is a grammar violation the
                    // parser will catch (it'll see something other than
                    // String right after Equals).
                }
                continue;
            }
            // Unrecognized character in tag mode: consume it and keep going
            // rather than looping forever (docs/tinyhtml-spec.md
            // section 6, "no unbounded ... backtracking").
            advance();
        }
    }

    // <script> content is raw text up to the literal "</script>", not
    // tokenized as markup, and not entity-decoded (docs/
    // tinyhtml-spec.md section 5).
    void lex_script_raw_text_if_needed(const std::string& tag_name) {
        if (tag_name != "script") {
            return;
        }
        size_t start = pos;
        size_t close = source.find("</script>", pos);
        size_t text_end = (close == std::string::npos) ? source.size() : close;

        int text_line = line;
        std::string raw = source.substr(start, text_end - start);
        for (char c : raw) {
            if (c == '\n') {
                ++line;
            }
        }
        pos = text_end;
        if (!raw.empty()) {
            tokens.push_back(Token{TokenType::Text, raw, text_line});
        }

        if (close != std::string::npos) {
            pos += 9;  // length of "</script>"
            tokens.push_back(Token{TokenType::TagClose, "script", line});
        }
        // If there was no "</script>" at all, we've consumed to EOF; the
        // parser will report the missing closing tag.
    }

    void lex_tag_close() {
        int close_line = line;
        advance();  // consume '<'
        advance();  // consume '/'
        std::string tag_name = read_ident();
        skip_whitespace();
        if (peek() == '>') {
            advance();
        }
        tokens.push_back(Token{TokenType::TagClose, tag_name, close_line});
    }

    void lex_text_run() {
        int text_line = line;
        std::string raw;
        // A stray '<' that isn't the start of a recognizable tag (not
        // followed by '/' + a letter, or by a letter) is treated as literal
        // text rather than a lexing failure -- keeps the lexer total
        // (defined for every input) without a diagnostics channel of its
        // own; see lexer.cpp's is_tag_start for what counts as "recognizable".
        do {
            raw.push_back(advance());
        } while (!at_end() && peek() != '<');
        tokens.push_back(Token{TokenType::Text, decode_entities(raw), text_line});
    }

    bool looks_like_tag_start() const {
        if (peek(1) == '/') {
            return is_ident_start(peek(2));
        }
        return is_ident_start(peek(1));
    }
};

}  // namespace

std::vector<Token> lex(const std::string& source) {
    Lexer lexer(source);

    while (!lexer.at_end()) {
        if (lexer.peek() == '<' && lexer.looks_like_tag_start()) {
            if (lexer.peek(1) == '/') {
                lexer.lex_tag_close();
            } else {
                lexer.lex_tag_open_and_attributes();
            }
        } else {
            lexer.lex_text_run();
        }
    }

    lexer.tokens.push_back(Token{TokenType::EndOfFile, "", lexer.line});
    return lexer.tokens;
}

}  // namespace tinyhtml
