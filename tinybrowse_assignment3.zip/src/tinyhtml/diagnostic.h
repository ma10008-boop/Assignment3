#pragma once

#include <string>

namespace tinyhtml {

struct Diagnostic {
    std::string message;
    int line;
};

}  // namespace tinyhtml
