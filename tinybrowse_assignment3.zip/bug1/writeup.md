# Bug 1: Format String Vulnerability

**Component:** TinyScript Interpreter (`src/tinyscript/interpreter.cpp`)

**Bug class:** Format String Vulnerability

**Discovery method:** Manual source code inspection and input testing.

## Root-cause analysis

The vulnerability is present in the `builtin_print()` function. It converts the supplied value into a string and passes that string directly to `fprintf()` as the format string:

    std::fprintf(stderr, line_out.c_str());

This is unsafe because the input may contain format specifiers such as `%x`. Instead of displaying these characters literally, `fprintf()` interprets them as formatting instructions.

I reproduced the issue using:

    print("%x %x %x %x");

The program printed hexadecimal values instead of the original string. This confirms that user-controlled input is interpreted as a format string.

A safer implementation would be:

    std::fprintf(stderr, "%s", line_out.c_str());
