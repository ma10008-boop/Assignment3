# Static Analysis Report

## Setup

I used Clang Static Analyzer 14 with the `scan-build-14` utility to analyze the Tinybrowse source code.

A separate CMake build directory named `build-analyze` was configured using Clang 14.

The analysis was performed using:

```bash
scan-build-14 --status-bugs cmake --build build-analyze --clean-first -j2
```

## Output

The build completed successfully.

The analyzer displayed:

```text
scan-build: Analysis run complete.
scan-build: No bugs found.
```

During compilation, Clang also reported a format-string warning:

```text
src/tinyscript/interpreter.cpp:353:26:
warning: format string is not a string literal (potentially insecure)
```

The warning refers to:

```cpp
std::fprintf(stderr, line_out.c_str());
```

This is related to the format-string vulnerability identified during manual testing.

No separate analyzer bug reports were generated.

## Reach & limits

The static analyzer completed its examination of the compiled project without reporting bugs.

It helped identify a compiler warning related to unsafe format-string usage. However, the analyzer did not independently report the array concatenation overflow that was detected using AddressSanitizer.

Static analysis cannot guarantee that an application is free from vulnerabilities. Its results depend on the analysis paths, supported checks, and code that is examined.
