# AddressSanitizer Testing

## Setup

I configured a separate Debug build using Clang 14 and AddressSanitizer.

The following flags were used:

    -fsanitize=address
    -fno-omit-frame-pointer
    -g

The ASan build was configured in `build-asan` and compiled successfully.

## Output

I tested the array concatenation bug using two arrays:

    let a: Array<u32> = array_new(32768);
    let b: Array<u32> = array_new(32769);
    let c: Array<u32> = array_concat(a, b);

The expected combined length was 65,537. However, the implementation stores the length in a uint16_t variable, resulting in an allocated length of 1.

I ran the test using:

    ./build-asan/src/browser/tinybrowse bug2/bug.thtml

AddressSanitizer reported:

    ERROR: AddressSanitizer: heap-buffer-overflow
    READ of size 4

The report also showed that the invalid address was immediately after a 144-byte allocated region.

This confirmed that the array concatenation implementation accesses memory outside its allocated heap buffer.

## Reach & limits

AddressSanitizer successfully detected the heap-buffer-overflow when the combined array length was 65,537.

It was useful for identifying the memory-safety issue during runtime testing. However, ASan only detects memory errors on executed code paths. It does not prove that the entire application is free from memory vulnerabilities.

The output also contained a warning about an invalid external symbolizer path, so function names were not displayed in the stack trace.
