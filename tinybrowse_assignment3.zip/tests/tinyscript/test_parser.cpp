#include "tinytest.h"

#include "tinyscript/parser.h"

using namespace tinyscript;

namespace {

Stmt* first(Program& p) { return p.statements.empty() ? nullptr : p.statements[0]; }

}  // namespace

TEST_CASE(parses_var_decl_with_literal_and_no_annotation) {
    ParseResult r = parse("let x = 5;");
    CHECK(r.diagnostics.empty());
    Stmt* s = first(r.program);
    CHECK(s != nullptr && s->type == StmtType::VarDecl);
    CHECK_EQ(s->var_name, std::string("x"));
    CHECK(s->var_type_annotation == nullptr);
    CHECK(s->var_init != nullptr && s->var_init->type == ExprType::Number);
    free_program(r.program);
}

TEST_CASE(parses_var_decl_with_annotation_always_syntactically_legal) {
    ParseResult r = parse("let x: u32 = 5;");
    CHECK(r.diagnostics.empty());
    Stmt* s = first(r.program);
    CHECK(s->var_type_annotation != nullptr);
    CHECK(s->var_type_annotation->kind == TypeKind::U32);
    free_program(r.program);
}

TEST_CASE(parses_result_and_array_types) {
    ParseResult r = parse("let x: Result<u32, String> = Ok(5); let y: Array<u8> = [1, 2];");
    CHECK(r.diagnostics.empty());
    Stmt* s = first(r.program);
    CHECK(s->var_type_annotation->kind == TypeKind::Result);
    CHECK(s->var_type_annotation->result_ok_type->kind == TypeKind::U32);
    CHECK(s->var_type_annotation->result_err_type->kind == TypeKind::String);
    Stmt* s2 = r.program.statements[1];
    CHECK(s2->var_type_annotation->kind == TypeKind::Array);
    CHECK(s2->var_type_annotation->array_element_type->kind == TypeKind::U8);
    free_program(r.program);
}

TEST_CASE(parses_unit_type) {
    ParseResult r = parse("fn f() -> () { return; }");
    CHECK(r.diagnostics.empty());
    Stmt* s = first(r.program);
    CHECK(s->return_type_annotation != nullptr);
    CHECK(s->return_type_annotation->kind == TypeKind::Unit);
    free_program(r.program);
}

TEST_CASE(operator_precedence_matches_spec_table) {
    // as binds tighter than * which binds tighter than +; unary tighter than as.
    ParseResult r = parse("let x = -a as u8 * 2 + 1;");
    CHECK(r.diagnostics.empty());
    Expr* top = first(r.program)->var_init;
    CHECK(top->type == ExprType::Binary);
    CHECK_EQ(top->text, std::string("+"));
    CHECK(top->left->type == ExprType::Binary);
    CHECK_EQ(top->left->text, std::string("*"));
    CHECK(top->left->left->type == ExprType::Cast);
    CHECK(top->left->left->cast_operand->type == ExprType::Unary);
    free_program(r.program);
}

TEST_CASE(parses_chained_cast_left_associative) {
    ParseResult r = parse("let x = 5 as u8 as u32;");
    CHECK(r.diagnostics.empty());
    Expr* top = first(r.program)->var_init;
    CHECK(top->type == ExprType::Cast);
    CHECK(top->cast_target == NumKind::U32);
    CHECK(top->cast_operand->type == ExprType::Cast);
    CHECK(top->cast_operand->cast_target == NumKind::U8);
    free_program(r.program);
}

TEST_CASE(parses_array_literal_and_subscript) {
    ParseResult r = parse("let x = [1, 2, 3][0];");
    CHECK(r.diagnostics.empty());
    Expr* top = first(r.program)->var_init;
    CHECK(top->type == ExprType::Index);
    CHECK(top->index_array->type == ExprType::ArrayLiteral);
    CHECK_EQ(top->index_array->array_elements.size(), static_cast<size_t>(3));
    free_program(r.program);
}

TEST_CASE(parses_plain_assign_and_index_assign) {
    ParseResult r = parse("x = 1; arr[0] = 2;");
    CHECK(r.diagnostics.empty());
    CHECK_EQ(r.program.statements.size(), static_cast<size_t>(2));

    Stmt* s1 = r.program.statements[0];
    CHECK(s1->type == StmtType::Assign);
    CHECK_EQ(s1->assign_name, std::string("x"));
    CHECK(s1->assign_index_target == nullptr);

    Stmt* s2 = r.program.statements[1];
    CHECK(s2->type == StmtType::Assign);
    CHECK(s2->assign_index_target != nullptr);
    CHECK(s2->assign_index_target->type == ExprType::Index);

    free_program(r.program);
}

TEST_CASE(invalid_assignment_target_is_a_diagnostic) {
    ParseResult r = parse("f() = 1;");
    CHECK(!r.diagnostics.empty());
    free_program(r.program);
}

TEST_CASE(parses_if_else_if_else_chain) {
    ParseResult r = parse("if (a) { return 1; } else if (b) { return 2; } else { return 3; }");
    CHECK(r.diagnostics.empty());
    Stmt* s = first(r.program);
    CHECK(s->type == StmtType::If);
    CHECK_EQ(s->else_body.size(), static_cast<size_t>(1));
    CHECK(s->else_body[0]->type == StmtType::If);
    CHECK_EQ(s->else_body[0]->else_body.size(), static_cast<size_t>(1));
    CHECK(s->else_body[0]->else_body[0]->type == StmtType::Return);
    free_program(r.program);
}

TEST_CASE(parses_function_with_params_and_annotations) {
    ParseResult r = parse("fn add(a: u32, b: u32) -> u32 { return a + b; }");
    CHECK(r.diagnostics.empty());
    Stmt* s = first(r.program);
    CHECK(s->type == StmtType::FuncDecl);
    CHECK_EQ(s->func_name, std::string("add"));
    CHECK_EQ(s->param_names.size(), static_cast<size_t>(2));
    CHECK(s->param_type_annotations[0]->kind == TypeKind::U32);
    CHECK(s->return_type_annotation->kind == TypeKind::U32);
    free_program(r.program);
}

TEST_CASE(missing_semicolon_is_a_diagnostic_but_does_not_hang) {
    ParseResult r = parse("let x = 5\nlet y = 6;");
    CHECK(!r.diagnostics.empty());
    free_program(r.program);
}

TEST_CASE(unterminated_block_does_not_hang_or_crash) {
    ParseResult r = parse("fn f() { let x = 1;");
    CHECK(!r.diagnostics.empty());
    free_program(r.program);
}

TEST_CASE(unrecognized_character_does_not_hang) {
    ParseResult r = parse("let x = 5 @ 3;");
    CHECK(r.program.statements.size() >= 1);
    free_program(r.program);
}

TINYTEST_MAIN()
