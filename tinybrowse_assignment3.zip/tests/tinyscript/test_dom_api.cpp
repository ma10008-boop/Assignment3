#include "tinytest.h"

#include "tinyhtml/parser.h"
#include "tinyscript/dom_api.h"
#include "tinyscript/parser.h"

using namespace tinyscript;

namespace {

struct RunResult {
    tinyhtml::Node* document;
    Interpreter interp;
    std::vector<Diagnostic> diags;
    Program program;  // kept alive: interp.functions points into it
};

RunResult run(const std::string& html, const std::string& script_source) {
    RunResult r;
    tinyhtml::ParseResult html_result = tinyhtml::parse(html);
    r.document = html_result.document;

    register_dom_api(r.interp, r.document);

    ParseResult parsed = parse(script_source);
    r.diags = parsed.diagnostics;
    r.program = std::move(parsed.program);
    collect_functions(r.interp, r.program);
    execute_program(r.interp, r.program, &r.diags);
    return r;
}

void cleanup(RunResult& r) {
    free_scope(r.interp.globals);
    free_program(r.program);
    tinyhtml::free_node(r.document);
}

Value* global(RunResult& r, const std::string& name) {
    auto it = r.interp.globals.find(name);
    return it != r.interp.globals.end() ? &it->second : nullptr;
}

}  // namespace

TEST_CASE(get_element_by_id_hit_returns_ok_element) {
    RunResult r = run("<p id=\"target\">hi</p>",
                       "let found = getElementById(\"target\");"
                       "let ok = is_ok(found);");
    CHECK(r.diags.empty());
    CHECK(global(r, "ok")->bool_val);
    cleanup(r);
}

TEST_CASE(get_element_by_id_miss_returns_err) {
    RunResult r = run("<p id=\"target\">hi</p>",
                       "let found = getElementById(\"nope\");"
                       "let is_err_result = is_err(found);");
    CHECK(r.diags.empty());
    CHECK(global(r, "is_err_result")->bool_val);
    cleanup(r);
}

TEST_CASE(get_element_by_id_wrong_arg_type_is_a_diagnostic) {
    RunResult r = run("<p id=\"target\">hi</p>", "let x = getElementById(5);");
    CHECK_EQ(r.diags.size(), static_cast<size_t>(1));
    cleanup(r);
}

TEST_CASE(get_attribute_hit_and_miss) {
    RunResult r = run(
        "<a id=\"link\" href=\"/about\">About</a>",
        "let el = unwrap(getElementById(\"link\"));"
        "let href = unwrap(getAttribute(el, \"href\"));"
        "let missing = is_err(getAttribute(el, \"class\"));");
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "href")->string_val, std::string("/about"));
    CHECK(global(r, "missing")->bool_val);
    cleanup(r);
}

TEST_CASE(set_attribute_overwrites_existing_and_adds_new) {
    RunResult r = run(
        "<p id=\"target\" class=\"old\">hi</p>",
        "let el = unwrap(getElementById(\"target\"));"
        "setAttribute(el, \"class\", \"new\");"
        "setAttribute(el, \"data-extra\", \"1\");"
        "let cls = unwrap(getAttribute(el, \"class\"));"
        "let extra = unwrap(getAttribute(el, \"data-extra\"));");
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "cls")->string_val, std::string("new"));
    CHECK_EQ(global(r, "extra")->string_val, std::string("1"));
    cleanup(r);
}

TEST_CASE(set_text_replaces_children_with_verbatim_text) {
    RunResult r = run(
        "<p id=\"target\"><b>old</b></p>",
        "let el = unwrap(getElementById(\"target\"));"
        "setText(el, \"<b>not markup</b>\");");
    CHECK(r.diags.empty());

    tinyhtml::Node* p = r.document->first_child;
    CHECK(p->first_child != nullptr);
    CHECK(p->first_child->type == tinyhtml::NodeType::Text);
    CHECK_EQ(p->first_child->text, std::string("<b>not markup</b>"));
    CHECK(p->first_child->next_sibling == nullptr);  // exactly one child, the text node

    cleanup(r);
}

TEST_CASE(set_html_splices_in_real_markup_completely_unsanitized) {
    RunResult r = run(
        "<div id=\"target\"><p>old</p></div>",
        "let el = unwrap(getElementById(\"target\"));"
        "setHtml(el, \"<b>bold</b><i>italic</i>\");");
    CHECK(r.diags.empty());

    tinyhtml::Node* div = r.document->first_child;
    CHECK(div->first_child != nullptr);
    CHECK(div->first_child->type == tinyhtml::NodeType::Element);
    CHECK_EQ(div->first_child->tag_name, std::string("b"));
    CHECK(div->first_child->next_sibling != nullptr);
    CHECK_EQ(div->first_child->next_sibling->tag_name, std::string("i"));

    cleanup(r);
}

TEST_CASE(set_html_injecting_a_script_tag_is_not_prevented) {
    // The point of setHtml being unsanitized: a script tag injected this
    // way is structurally no different from one written directly in the
    // page's markup -- nothing here refuses or escapes it.
    RunResult r = run(
        "<div id=\"target\"></div>",
        "let el = unwrap(getElementById(\"target\"));"
        "setHtml(el, \"<script>let injected = 1;</script>\");");
    CHECK(r.diags.empty());

    tinyhtml::Node* div = r.document->first_child;
    CHECK(div->first_child != nullptr);
    CHECK(div->first_child->type == tinyhtml::NodeType::Element);
    CHECK_EQ(div->first_child->tag_name, std::string("script"));

    cleanup(r);
}

TEST_CASE(on_validates_arguments_and_event_name) {
    RunResult r = run(
        "<button id=\"btn\">Click</button>",
        "let el = unwrap(getElementById(\"btn\"));"
        "on(el, \"click\", \"handler\");"
        "on(el, \"hover\", \"handler\");");  // unrecognized event -> diagnostic
    CHECK_EQ(r.diags.size(), static_cast<size_t>(1));
    cleanup(r);
}

TEST_CASE(dom_api_functions_do_not_leak_their_arguments) {
    // Run this test's target under ASan to confirm: every DOM builtin call
    // here passes ownership-bearing arguments (Result/String Values) that
    // must be freed by the general "free every arg after the call"
    // mechanism in interpreter.cpp, same as any other builtin.
    RunResult r = run(
        "<p id=\"a\">x</p><p id=\"b\">y</p>",
        "let ra = getElementById(\"a\");"
        "let rb = getElementById(\"b\");"
        "let rc = getElementById(\"missing\");"
        "if (is_ok(ra)) { setText(unwrap(ra), \"updated\"); }");
    CHECK(r.diags.empty());
    cleanup(r);
}

TINYTEST_MAIN()
