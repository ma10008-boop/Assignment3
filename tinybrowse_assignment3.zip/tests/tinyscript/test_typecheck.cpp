#include "tinytest.h"

#include "tinyscript/interpreter.h"
#include "tinyscript/parser.h"
#include "tinyscript/typecheck.h"

using namespace tinyscript;

namespace {

bool check(const std::string& source, std::vector<Diagnostic>* diags_out = nullptr) {
    ParseResult r = parse(source);
    CHECK(r.diagnostics.empty());  // these tests should all be syntactically valid
    std::vector<Program*> blocks = {&r.program};
    std::vector<Diagnostic> diags;
    bool ok = typecheck_document(blocks, nullptr, &diags);
    if (diags_out != nullptr) {
        *diags_out = diags;
    }
    free_program(r.program);
    return ok;
}

}  // namespace

TEST_CASE(annotated_var_decl_passes) {
    CHECK(check("let x: u32 = 5;"));
}

TEST_CASE(same_literal_different_annotation_proves_literal_polymorphism) {
    CHECK(check("let x: u32 = 5;"));
    CHECK(check("let y: u8 = 5;"));
}

TEST_CASE(function_with_full_annotations_including_unit_return_passes) {
    CHECK(check("fn add(a: u32, b: u32) -> u32 { return a + b; }"));
    CHECK(check("fn f() -> () { let x: u32 = 1; }"));
}

TEST_CASE(missing_var_annotation_is_rejected) {
    std::vector<Diagnostic> diags;
    CHECK(!check("let x = 5;", &diags));
    CHECK_EQ(diags.size(), static_cast<size_t>(1));
}

TEST_CASE(missing_param_annotation_is_rejected) {
    CHECK(!check("fn f(a) { return a; }"));
}

TEST_CASE(missing_return_arrow_is_rejected) {
    CHECK(!check("fn g(a: i32) { return a; }"));
}

TEST_CASE(concrete_kind_mismatch_requires_explicit_as) {
    CHECK(!check("let x: u8 = 5; let y: u32 = 10; let z: u32 = x + y;"));
}

TEST_CASE(explicit_as_fixes_the_concrete_mismatch) {
    CHECK(check("let x: u8 = 5; let y: u32 = 10; let z: u32 = (x as u32) + y;"));
}

TEST_CASE(flexible_literal_adopts_the_concrete_operands_kind) {
    CHECK(check("let x: u8 = 5; let y: u8 = x + 3;"));
}

TEST_CASE(array_literal_elements_unify_against_the_annotation) {
    CHECK(check("let a: Array<u32> = [1, 2, 3];"));
}

TEST_CASE(array_new_infers_element_type_from_the_annotation) {
    CHECK(check("let a: Array<u32> = array_new(5);"));
}

TEST_CASE(array_literal_element_kind_mismatch_is_rejected) {
    CHECK(!check("let a: Array<u32> = [1u8, 2];"));
}

TEST_CASE(array_index_result_matches_element_type_regardless_of_index_expression) {
    CHECK(check("let a: Array<u32> = [1, 2, 3]; let x: u32 = a[0];"));
    CHECK(check("let a: Array<u32> = [1, 2, 3]; let i: u64 = 2; let x: u32 = a[i];"));
}

TEST_CASE(result_ok_err_and_accessors_type_check) {
    CHECK(check("let r: Result<u32, String> = Ok(5); let x: u32 = unwrap(r);"));
    CHECK(check("let r: Result<u32, String> = Err(\"bad\"); let e: String = unwrap_err(r);"));
    CHECK(check("let r: Result<u32, String> = Ok(5); let b: Bool = is_ok(r);"));
}

TEST_CASE(unwrap_on_non_result_is_rejected) {
    CHECK(!check("let x: u32 = 5; let y: u32 = unwrap(x);"));
}

TEST_CASE(logical_operators_require_bool_operands) {
    CHECK(check("let a: Bool = true; let b: Bool = false; let c: Bool = a && b;"));
    CHECK(!check("let a: u32 = 1; let b: Bool = a && true;"));
}

TEST_CASE(all_or_nothing_across_multiple_blocks) {
    ParseResult block1 = parse("let x: u32 = 5;");
    ParseResult block2 = parse("let y = 10;");  // missing annotation
    CHECK(block1.diagnostics.empty());
    CHECK(block2.diagnostics.empty());

    std::vector<Program*> blocks = {&block1.program, &block2.program};
    std::vector<Diagnostic> diags;
    bool ok = typecheck_document(blocks, nullptr, &diags);

    CHECK(!ok);
    CHECK_EQ(diags.size(), static_cast<size_t>(1));

    free_program(block1.program);
    free_program(block2.program);
}

TEST_CASE(function_hoisting_across_blocks_type_checks) {
    ParseResult block1 = parse("let x: u32 = later();");
    ParseResult block2 = parse("fn later() -> u32 { return 42; }");
    CHECK(block1.diagnostics.empty());
    CHECK(block2.diagnostics.empty());

    std::vector<Program*> blocks = {&block1.program, &block2.program};
    std::vector<Diagnostic> diags;
    bool ok = typecheck_document(blocks, nullptr, &diags);

    CHECK(ok);
    CHECK(diags.empty());

    free_program(block1.program);
    free_program(block2.program);
}

TEST_CASE(string_concatenation_type_checks_but_mixed_operands_are_rejected) {
    CHECK(check("let a: String = \"x\"; let b: String = \"y\"; let c: String = a + b;"));
    // No implicit conversion -- unlike tinyscript's runtime, which coerces
    // the non-string side (docs/tinyscript-spec.md section 3).
    CHECK(!check("let a: String = \"x\"; let b: u32 = 1u32; let c: String = a + b;"));
}

TEST_CASE(dom_api_builtins_type_check_against_their_documented_signatures) {
    CHECK(check("let r: Result<Element, ()> = getElementById(\"a\");"));
    CHECK(check(
        "let r: Result<Element, ()> = getElementById(\"a\");"
        "let el: Element = unwrap(r);"
        "let attr: Result<String, ()> = getAttribute(el, \"id\");"
        "setAttribute(el, \"id\", \"b\");"
        "setText(el, \"hi\");"
        "setHtml(el, \"<b>hi</b>\");"
        "on(el, \"click\", \"handler\");"));
    // wrong argument kind/arity
    CHECK(!check("let r: Result<Element, ()> = getElementById(5);"));
    CHECK(!check("getElementById(\"a\", \"b\");"));
}

TEST_CASE(type_of_returns_any_for_an_expression_never_checked) {
    ParseResult r = parse("let x: u32 = 5;");
    TypeTable table;  // never populated
    Type t = type_of(table, r.program.statements[0]->var_init);
    CHECK(t.kind == TypeKind::Any);
    free_program(r.program);
}

TEST_CASE(type_table_is_populated_for_checked_expressions) {
    ParseResult r = parse("let x: u32 = 5;");
    TypeTable table;
    std::vector<Program*> blocks = {&r.program};
    std::vector<Diagnostic> diags;
    CHECK(typecheck_document(blocks, &table, &diags));

    Type t = type_of(table, r.program.statements[0]->var_init);
    CHECK(t.kind == TypeKind::U32);

    free_program(r.program);
}

// Full pipeline rehearsal for Phase 4's browser wiring: parse, typecheck,
// and only interpret if the check passed -- proving a passing typyscript
// program actually runs and a rejected one never executes at all (not
// even partially).
TEST_CASE(end_to_end_passing_typyscript_program_executes) {
    // Literal suffixes (u32) here, not just the annotation -- annotations
    // are erased before execution and have no runtime effect (only a
    // literal's own suffix sets its runtime kind), so a real u32 result
    // requires u32-suffixed literals throughout, exactly as a correctly
    // written typyscript program would use them.
    ParseResult r = parse(
        "let clicks: u32 = 0u32;"
        "fn bump() -> u32 { return clicks + 1u32; }"
        "clicks = bump();");
    CHECK(r.diagnostics.empty());

    std::vector<Program*> blocks = {&r.program};
    std::vector<Diagnostic> diags;
    bool ok = typecheck_document(blocks, nullptr, &diags);
    CHECK(ok);
    CHECK(diags.empty());

    Interpreter interp;
    collect_functions(interp, r.program);
    execute_program(interp, r.program, &diags);
    CHECK(diags.empty());

    auto it = interp.globals.find("clicks");
    CHECK(it != interp.globals.end());
    CHECK_EQ(it->second.u32_val, static_cast<uint32_t>(1));

    free_scope(interp.globals);
    free_program(r.program);
}

TEST_CASE(end_to_end_rejected_typyscript_program_never_executes) {
    ParseResult r = parse(
        "let clicks = 0;"  // missing annotation -- rejected
        "clicks = clicks + 1;");
    CHECK(r.diagnostics.empty());

    std::vector<Program*> blocks = {&r.program};
    std::vector<Diagnostic> diags;
    bool ok = typecheck_document(blocks, nullptr, &diags);
    CHECK(!ok);
    CHECK(!diags.empty());

    // Per docs/typyscript-spec.md section 4: a rejected document
    // runs nothing -- Phase 4's browser wiring simply never calls
    // execute_program in this case. Confirm there's nothing left to run
    // by checking the AST is still exactly as parsed (no interpreter
    // side effects could have occurred since it was never invoked).
    free_program(r.program);
}

TINYTEST_MAIN()
