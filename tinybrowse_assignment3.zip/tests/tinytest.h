#pragma once

// A tiny, dependency-free test harness. No external test framework is
// used here on purpose (docs/ARCHITECTURE.md) -- this is small enough to
// read in full.
//
// Usage:
//
//   #include "tinytest.h"
//
//   TEST_CASE(adds_two_numbers) {
//       CHECK_EQ(2 + 2, 4);
//   }
//
//   TINYTEST_MAIN()   // exactly once, in one .cpp per test executable

#include <cstdio>
#include <vector>

struct TinyTestCase {
    const char* name;
    void (*fn)();
};

inline std::vector<TinyTestCase>& tinytest_registry() {
    static std::vector<TinyTestCase> registry;
    return registry;
}

struct TinyTestRegistrar {
    TinyTestRegistrar(const char* name, void (*fn)()) {
        tinytest_registry().push_back(TinyTestCase{name, fn});
    }
};

inline int tinytest_failures = 0;

#define TEST_CASE(test_name)                                                 \
    static void test_name();                                                 \
    static TinyTestRegistrar tinytest_registrar_##test_name(#test_name,      \
                                                             test_name);      \
    static void test_name()

#define CHECK(condition)                                                     \
    do {                                                                     \
        if (!(condition)) {                                                  \
            std::fprintf(stderr, "  FAIL %s:%d: CHECK(%s)\n", __FILE__,      \
                          __LINE__, #condition);                             \
            ++tinytest_failures;                                             \
        }                                                                    \
    } while (0)

#define CHECK_EQ(actual, expected)                                           \
    do {                                                                     \
        auto tinytest_actual = (actual);                                     \
        auto tinytest_expected = (expected);                                 \
        if (!(tinytest_actual == tinytest_expected)) {                       \
            std::fprintf(stderr, "  FAIL %s:%d: CHECK_EQ(%s, %s)\n",         \
                          __FILE__, __LINE__, #actual, #expected);           \
            ++tinytest_failures;                                             \
        }                                                                    \
    } while (0)

#define TINYTEST_MAIN()                                                      \
    int main() {                                                             \
        int total = 0;                                                       \
        for (const TinyTestCase& test_case : tinytest_registry()) {          \
            int failures_before = tinytest_failures;                         \
            test_case.fn();                                                  \
            std::printf("%s %s\n",                                          \
                        tinytest_failures == failures_before ? "PASS"       \
                                                              : "FAIL",       \
                        test_case.name);                                     \
            ++total;                                                         \
        }                                                                    \
        std::printf("%d test case(s), %d failure(s)\n", total,               \
                    tinytest_failures);                                      \
        return tinytest_failures == 0 ? 0 : 1;                               \
    }
