#include "tinytest.h"

#include <fstream>
#include <sstream>

#include "render/layout.h"
#include "tinyhtml/parser.h"

using namespace render;

namespace {

LayoutResult layout_source_full(const std::string& source, int width) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(source);
    CHECK(parsed.diagnostics.empty());  // these fixtures should all parse cleanly
    LayoutResult result = layout(parsed.document, width);
    tinyhtml::free_node(parsed.document);
    return result;
}

std::vector<Line> layout_source(const std::string& source, int width) {
    return layout_source_full(source, width).lines;
}

// Matches exactly what render::print_to_terminal writes: every line,
// including the last, followed by '\n' -- so a golden file's raw bytes are
// exactly what `tinybrowse` itself would print to stdout.
std::string join_lines(const std::vector<Line>& lines) {
    std::string out;
    for (const Line& line : lines) {
        out += line.text;
        out += '\n';
    }
    return out;
}

std::string read_golden(const std::string& name) {
    std::ifstream file(std::string(TINYBROWSE_GOLDEN_DIR) + "/" + name);
    std::ostringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

}  // namespace

TEST_CASE(golden_hello_document) {
    std::vector<Line> lines = layout_source(
        "<title>Hello, tinybrowse!</title>"
        "<h1>Hello, tinybrowse!</h1>"
        "<p>This is the simplest possible tinyhtml document: a title, a heading, and\n"
        "a paragraph of text.</p>",
        80);
    CHECK_EQ(join_lines(lines), read_golden("hello.txt"));
}

TEST_CASE(golden_showcase_document) {
    std::vector<Line> lines = layout_source(
        "<title>tinyhtml Showcase</title>\n"
        "<h1>tinyhtml Showcase</h1>\n"
        "<p>This document exercises most of tinyhtml's tag set. See\n"
        "<b>docs/student/tinyhtml-spec.md</b> for the full grammar.</p>\n"
        "\n"
        "<h2>Text formatting</h2>\n"
        "<p>You can write <b>bold</b>, <i>italic</i>, and <u>underlined</u> text, mix\n"
        "them <b><i>together</i></b>, and use a manual line break<br>right in the\n"
        "middle of a paragraph.</p>\n"
        "\n"
        "<h2>Links</h2>\n"
        "<p>Links use the <a href=\"https://example.com\">a</a> tag with an\n"
        "<span class=\"attr\">href</span> attribute.</p>\n"
        "\n"
        "<h3>Lists</h3>\n"
        "<ul>\n"
        "  <li>Unordered items</li>\n"
        "  <li>Can be nested inside other elements</li>\n"
        "</ul>\n"
        "<ol>\n"
        "  <li>Ordered items</li>\n"
        "  <li>Work the same way, just a different tag name</li>\n"
        "</ol>\n"
        "\n"
        "<h3>Entities</h3>\n"
        "<p>Five entities are recognized: &lt; &gt; &amp; &quot; &apos;</p>\n"
        "\n"
        "<div id=\"footer\">\n"
        "  <p>Rendered by <span>tinybrowse</span>.</p>\n"
        "</div>",
        80);
    CHECK_EQ(join_lines(lines), read_golden("showcase.txt"));
}

TEST_CASE(title_and_script_contribute_no_lines) {
    std::vector<Line> lines = layout_source("<title>T</title><script>let x = 1;</script>", 80);
    CHECK(lines.empty());
}

TEST_CASE(no_visible_content_at_all_is_the_empty_document) {
    std::vector<Line> lines = layout_source("", 80);
    CHECK(lines.empty());
}

TEST_CASE(word_wrap_breaks_at_the_width_boundary_not_before_or_after) {
    std::vector<Line> lines = layout_source("<p>one two three four five six seven eight nine ten</p>", 20);
    CHECK_EQ(lines.size(), static_cast<size_t>(3));
    CHECK_EQ(lines[0].text, std::string("one two three four"));    // 19 chars, +5 for "five" would exceed 20
    CHECK_EQ(lines[1].text, std::string("five six seven eight"));  // exactly 20 chars -- must not wrap early
    CHECK_EQ(lines[2].text, std::string("nine ten"));
}

TEST_CASE(a_token_exactly_at_width_does_not_wrap) {
    std::vector<Line> lines = layout_source("<p>exactlyten</p>", 10);
    CHECK_EQ(lines.size(), static_cast<size_t>(1));
    CHECK_EQ(lines[0].text, std::string("exactlyten"));
}

TEST_CASE(a_single_token_longer_than_width_overflows_rather_than_hard_breaking) {
    std::vector<Line> lines = layout_source("<p>exactlyeleven</p>", 10);
    CHECK_EQ(lines.size(), static_cast<size_t>(1));
    CHECK_EQ(lines[0].text, std::string("exactlyeleven"));
}

TEST_CASE(br_forces_a_line_break_independent_of_width) {
    std::vector<Line> lines = layout_source("<p>first line<br>second line</p>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(2));
    CHECK_EQ(lines[0].text, std::string("first line"));
    CHECK_EQ(lines[1].text, std::string("second line"));
}

TEST_CASE(nested_lists_indent_two_spaces_per_level) {
    std::vector<Line> lines = layout_source(
        "<ul><li>Top A"
        "<ul><li>Nested A1</li><li>Nested A2"
        "<ol><li>Deep i</li></ol>"
        "</li></ul>"
        "</li><li>Top B</li></ul>",
        80);
    CHECK_EQ(lines.size(), static_cast<size_t>(5));
    CHECK_EQ(lines[0].text, std::string("- Top A"));
    CHECK_EQ(lines[1].text, std::string("  - Nested A1"));
    CHECK_EQ(lines[2].text, std::string("  - Nested A2"));
    CHECK_EQ(lines[3].text, std::string("    1. Deep i"));
    CHECK_EQ(lines[4].text, std::string("- Top B"));
}

TEST_CASE(list_items_have_no_blank_line_between_them_but_blocks_do) {
    std::vector<Line> lines = layout_source("<ul><li>A</li><li>B</li></ul><p>after</p>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(4));
    CHECK_EQ(lines[0].text, std::string("- A"));
    CHECK_EQ(lines[1].text, std::string("- B"));
    CHECK_EQ(lines[2].text, std::string(""));  // exactly one blank line between the list and the next block
    CHECK_EQ(lines[3].text, std::string("after"));
}

TEST_CASE(style_does_not_leak_into_the_separator_space_after_it_closes) {
    std::vector<Line> lines = layout_source("<p><u>underlined</u> text</p>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(1));
    CHECK_EQ(lines[0].text, std::string("\x1b[4munderlined\x1b[0m text"));
}

TEST_CASE(adjacent_same_styled_tokens_share_one_continuous_span) {
    std::vector<Line> lines = layout_source("<h1>tinyhtml Showcase</h1>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(1));
    CHECK_EQ(lines[0].text, std::string("\x1b[1;4mtinyhtml Showcase\x1b[0m"));
}

TEST_CASE(a_style_boundary_inside_one_unbreakable_token_does_not_split_it) {
    // "tinyhtml," has no whitespace in the source between the bold word and
    // the comma, so it must wrap as a single unit even though it's two
    // different styles internally.
    std::vector<Line> lines = layout_source("<p><b>tinyhtml</b>, rendered</p>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(1));
    CHECK_EQ(lines[0].text, std::string("\x1b[1mtinyhtml\x1b[0m, rendered"));
}

TEST_CASE(href_is_not_rendered_inline_only_the_link_text_and_its_number_are) {
    std::vector<Line> lines = layout_source("<p><a href=\"https://example.com\">click</a> here</p>", 80);
    CHECK_EQ(lines[0].text, std::string("\x1b[4mclick\x1b[0m[1] here"));
}

TEST_CASE(empty_list_item_still_shows_its_bullet) {
    std::vector<Line> lines = layout_source("<ul><li></li></ul>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(1));
    CHECK_EQ(lines[0].text, std::string("- "));
}

TEST_CASE(div_is_a_transparent_block_container) {
    std::vector<Line> lines = layout_source("<div><div><p>deep div nesting</p></div></div>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(1));
    CHECK_EQ(lines[0].text, std::string("deep div nesting"));
}

TEST_CASE(empty_div_contributes_no_blank_lines) {
    std::vector<Line> lines = layout_source("<p>before</p><div></div><p>after</p>", 80);
    CHECK_EQ(lines.size(), static_cast<size_t>(3));
    CHECK_EQ(lines[0].text, std::string("before"));
    CHECK_EQ(lines[1].text, std::string(""));
    CHECK_EQ(lines[2].text, std::string("after"));
}

TEST_CASE(a_link_gets_a_bracketed_number_and_a_references_entry) {
    LayoutResult result = layout_source_full("<p>Click <a href=\"https://example.com\">here</a> now.</p>", 80);
    CHECK_EQ(result.lines.size(), static_cast<size_t>(5));
    CHECK_EQ(result.lines[0].text, std::string("Click \x1b[4mhere\x1b[0m[1] now."));
    CHECK_EQ(result.lines[1].text, std::string(""));
    CHECK_EQ(result.lines[2].text, std::string("References"));
    CHECK_EQ(result.lines[3].text, std::string(""));
    CHECK_EQ(result.lines[4].text, std::string("   [1] https://example.com"));
    CHECK_EQ(result.links.size(), static_cast<size_t>(1));
    CHECK_EQ(result.links[0], std::string("https://example.com"));
}

TEST_CASE(multiple_links_are_numbered_in_document_order) {
    LayoutResult result = layout_source_full(
        "<p>Two <a href=\"/a\">first</a> and <a href=\"/b\">second</a> links.</p>", 80);
    CHECK_EQ(result.lines[0].text,
              std::string("Two \x1b[4mfirst\x1b[0m[1] and \x1b[4msecond\x1b[0m[2] links."));
    CHECK_EQ(result.links.size(), static_cast<size_t>(2));
    CHECK_EQ(result.links[0], std::string("/a"));
    CHECK_EQ(result.links[1], std::string("/b"));
    CHECK_EQ(result.lines[4].text, std::string("   [1] /a"));
    CHECK_EQ(result.lines[5].text, std::string("   [2] /b"));
}

TEST_CASE(a_link_with_no_href_or_an_empty_href_is_styled_but_not_numbered) {
    LayoutResult result =
        layout_source_full("<p><a>no href</a> and <a href=\"\">empty href</a> stay plain.</p>", 80);
    CHECK_EQ(result.lines.size(), static_cast<size_t>(1));  // no References block
    CHECK_EQ(result.lines[0].text,
              std::string("\x1b[4mno href\x1b[0m and \x1b[4mempty href\x1b[0m stay plain."));
    CHECK(result.links.empty());
}

TEST_CASE(a_link_inside_a_list_item_is_numbered_too) {
    LayoutResult result = layout_source_full("<ul><li>Item <a href=\"/x\">link</a></li></ul>", 80);
    CHECK_EQ(result.lines[0].text, std::string("- Item \x1b[4mlink\x1b[0m[1]"));
    CHECK_EQ(result.links.size(), static_cast<size_t>(1));
    CHECK_EQ(result.links[0], std::string("/x"));
}

TEST_CASE(no_links_means_no_references_block) {
    LayoutResult result = layout_source_full("<p>No links here.</p>", 80);
    CHECK_EQ(result.lines.size(), static_cast<size_t>(1));
    CHECK(result.links.empty());
}

TINYTEST_MAIN()
