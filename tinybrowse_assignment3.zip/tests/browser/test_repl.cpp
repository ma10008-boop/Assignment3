#include "tinytest.h"

#include <sstream>
#include <string>

#include "browser/browser.h"
#include "browser/repl.h"
#include "net/fixture_server.h"

using namespace browser;

namespace {

bool contains(const std::string& haystack, const std::string& needle) {
    return haystack.find(needle) != std::string::npos;
}

size_t count_occurrences(const std::string& haystack, const std::string& needle) {
    size_t count = 0;
    size_t pos = 0;
    while ((pos = haystack.find(needle, pos)) != std::string::npos) {
        ++count;
        pos += needle.size();
    }
    return count;
}

std::string fixture_path(const std::string& name) {
    return std::string(TINYBROWSE_BROWSER_FIXTURES_DIR) + "/" + name;
}

std::string http_response(const std::string& body) {
    return "HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(body.size()) + "\r\n\r\n" + body;
}

// Same real body/digest/signature triple as tests/sign/test_verify_signature.cpp
// (generated offline against tests/sign/fixtures/pki/leaf_key.pem).
const char kSignedBody[] = "Hello, this is a signed tinybrowse page.\n";
const char kDigestHeader[] = "sha-256=:zFNkTFEd9n/dj/774Ez6YstZYWaLzNncDqiY8dq0yz4=:";
const char kSignatureB64[] =
    "MEUCICsv8bYctzoDm8S1NS1GOcV1hpyr3LLpRQaj9rvKzzrgAiEA3t50xFDaaB7+"
    "uNFDknKxCVBO18NNHpxqURBDYzLqtOc=";

std::string leaf_cert_der() {
    std::string der;
    read_file(std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/pki/leaf_cert.der", der);
    return der;
}

std::string signed_page_response(const std::string& body, const std::string& digest_header,
                                  const std::string& cert_url, const std::string& signature_b64) {
    std::string headers = "HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(body.size()) +
                           "\r\nContent-Digest: " + digest_header +
                           "\r\nSignature-Input: sig1=(\"content-digest\");cert-url=\"" + cert_url +
                           "\"\r\nSignature: sig1=:" + signature_b64 + ":\r\n\r\n";
    return headers + body;
}

}  // namespace

TEST_CASE(local_follow_a_link_and_quit) {
    std::istringstream in("1\nq\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::File, fixture_path("page_a.thtml")}, in, out);
    CHECK_EQ(rc, 0);

    std::string transcript = out.str();
    CHECK(contains(transcript, "This is page A."));
    CHECK(contains(transcript, "References"));
    CHECK(contains(transcript, "page_b.thtml"));
    CHECK(contains(transcript, "This is page B."));
    CHECK(contains(transcript, "page_a.thtml"));
}

TEST_CASE(local_back_returns_to_the_previous_page) {
    std::istringstream in("1\nb\nq\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::File, fixture_path("page_a.thtml")}, in, out);
    CHECK_EQ(rc, 0);

    std::string transcript = out.str();
    CHECK_EQ(count_occurrences(transcript, "This is page A."), static_cast<size_t>(2));
    CHECK_EQ(count_occurrences(transcript, "This is page B."), static_cast<size_t>(1));
}

TEST_CASE(back_with_empty_history_prints_an_error_and_stays_put) {
    std::istringstream in("b\nq\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::File, fixture_path("page_a.thtml")}, in, out);
    CHECK_EQ(rc, 0);
    CHECK(contains(out.str(), "no previous page"));
}

TEST_CASE(an_out_of_range_link_number_prints_an_error_and_stays_put) {
    std::istringstream in("99\nq\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::File, fixture_path("page_a.thtml")}, in, out);
    CHECK_EQ(rc, 0);
    CHECK(contains(out.str(), "no such link"));
}

TEST_CASE(an_unrecognized_command_prints_an_error_and_stays_put) {
    std::istringstream in("foo\nq\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::File, fixture_path("page_a.thtml")}, in, out);
    CHECK_EQ(rc, 0);
    CHECK(contains(out.str(), "unrecognized command"));
}

TEST_CASE(bare_eof_exits_cleanly_without_any_commands) {
    std::istringstream in("");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::File, fixture_path("page_a.thtml")}, in, out);
    CHECK_EQ(rc, 0);
    CHECK(contains(out.str(), "This is page A."));
}

TEST_CASE(a_failed_initial_load_returns_a_nonzero_exit_code) {
    std::istringstream in("q\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::File, fixture_path("does_not_exist.thtml")}, in, out);
    CHECK_EQ(rc, 1);
    CHECK(contains(out.str(), "could not read"));
}

TEST_CASE(url_follow_a_link_across_two_servers) {
    FixtureServer server_b;
    server_b.serve_once(http_response("<p>This is page B (url).</p>"));

    FixtureServer server_a;
    std::string page_a_body =
        "<p>This is page A (url). <a href=\"http://127.0.0.1:" + std::to_string(server_b.port()) +
        "/\">Go to B</a>.</p>";
    server_a.serve_once(http_response(page_a_body));

    std::istringstream in("1\nq\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::Url, "http://127.0.0.1:" + std::to_string(server_a.port()) + "/"},
                       in, out);
    CHECK_EQ(rc, 0);

    std::string transcript = out.str();
    CHECK(contains(transcript, "This is page A (url)."));
    CHECK(contains(transcript, "This is page B (url)."));
}

TEST_CASE(url_back_re_fetches_rather_than_using_a_cached_copy) {
    FixtureServer server_b;
    server_b.serve_once(http_response("<p>This is page B (url).</p>"));

    FixtureServer server_a;
    std::string page_a_body =
        "<p>This is page A (url). <a href=\"http://127.0.0.1:" + std::to_string(server_b.port()) +
        "/\">Go to B</a>.</p>";
    server_a.serve_times(2, http_response(page_a_body));  // initial load, then again after "back"

    std::istringstream in("1\nb\nq\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::Url, "http://127.0.0.1:" + std::to_string(server_a.port()) + "/"},
                       in, out);
    CHECK_EQ(rc, 0);
    CHECK_EQ(count_occurrences(out.str(), "This is page A (url)."), static_cast<size_t>(2));
    CHECK_EQ(count_occurrences(out.str(), "This is page B (url)."), static_cast<size_t>(1));
}

TEST_CASE(url_page_with_valid_signature_shows_a_confirmation_and_renders) {
    FixtureServer cert_server;
    cert_server.serve_once(http_response(leaf_cert_der()));
    std::string cert_url = "http://127.0.0.1:" + std::to_string(cert_server.port()) + "/";

    FixtureServer page_server;
    page_server.serve_once(signed_page_response(kSignedBody, kDigestHeader, cert_url, kSignatureB64));

    std::istringstream in("q\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::Url, "http://127.0.0.1:" + std::to_string(page_server.port()) + "/"},
                       in, out);
    CHECK_EQ(rc, 0);

    std::string transcript = out.str();
    CHECK(contains(transcript, "signature verified"));
    CHECK(contains(transcript, "Hello, this is a signed tinybrowse page."));
}

TEST_CASE(url_page_with_bad_signature_is_refused_and_never_rendered) {
    FixtureServer cert_server;
    cert_server.serve_once(http_response(leaf_cert_der()));
    std::string cert_url = "http://127.0.0.1:" + std::to_string(cert_server.port()) + "/";

    std::string tampered_signature = kSignatureB64;
    tampered_signature[10] = (tampered_signature[10] == 'A') ? 'B' : 'A';

    FixtureServer page_server;
    page_server.serve_once(signed_page_response(kSignedBody, kDigestHeader, cert_url, tampered_signature));

    std::istringstream in("q\n");
    std::ostringstream out;
    int rc = run_repl(Location{LocationKind::Url, "http://127.0.0.1:" + std::to_string(page_server.port()) + "/"},
                       in, out);
    CHECK_EQ(rc, 1);

    std::string transcript = out.str();
    CHECK(contains(transcript, "refusing to render"));
    CHECK(!contains(transcript, "Hello, this is a signed tinybrowse page."));
}

TINYTEST_MAIN()
