#include "tinytest.h"

#include "browser/browser.h"
#include "tinyhtml/parser.h"

namespace {

std::string text_of(tinyhtml::Node* el) {
    return (el->first_child != nullptr && el->first_child->type == tinyhtml::NodeType::Text)
               ? el->first_child->text
               : "";
}

tinyhtml::Node* find_by_id(tinyhtml::Node* node, const std::string& id) {
    if (node->type == tinyhtml::NodeType::Element) {
        tinyhtml::Attribute* attr = tinyhtml::find_attribute(node, "id");
        if (attr != nullptr && attr->value == id) {
            return node;
        }
    }
    for (tinyhtml::Node* child = node->first_child; child != nullptr; child = child->next_sibling) {
        tinyhtml::Node* found = find_by_id(child, id);
        if (found != nullptr) {
            return found;
        }
    }
    return nullptr;
}

}  // namespace

TEST_CASE(all_or_nothing_a_type_error_in_one_block_prevents_every_block_from_running) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(
        "<p id=\"a\">orig</p>"
        "<script type=\"typyscript\">"
        "let x: u32 = 5;"
        "setText(unwrap(getElementById(\"a\")), \"changed\");"
        "</script>"
        "<script type=\"typyscript\">"
        "let y = 10;"  // missing annotation -- rejected
        "</script>");
    CHECK(parsed.diagnostics.empty());

    std::vector<tinyscript::Diagnostic> diags = browser::run_scripts(parsed.document);
    CHECK(!diags.empty());

    // Block 1 is individually well-typed and would have mutated #a, but
    // must not have run at all -- the whole document failed to check.
    CHECK_EQ(text_of(find_by_id(parsed.document, "a")), std::string("orig"));

    tinyhtml::free_node(parsed.document);
}

TEST_CASE(all_blocks_well_typed_both_run_and_share_the_global_environment) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(
        "<p id=\"a\">orig</p>"
        "<script type=\"typyscript\">"
        "let x: u32 = 5;"
        "</script>"
        "<script type=\"typyscript\">"
        "let y: u32 = x + 1;"  // sees block 1's global `x`
        "setText(unwrap(getElementById(\"a\")), \"changed\");"
        "</script>");
    CHECK(parsed.diagnostics.empty());

    std::vector<tinyscript::Diagnostic> diags = browser::run_scripts(parsed.document);
    CHECK(diags.empty());
    CHECK_EQ(text_of(find_by_id(parsed.document, "a")), std::string("changed"));

    tinyhtml::free_node(parsed.document);
}

TEST_CASE(cross_block_hoisting_lets_an_earlier_block_call_a_later_function) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(
        "<p id=\"a\">orig</p>"
        "<script type=\"typyscript\">"
        "let x: u32 = later();"
        "setText(unwrap(getElementById(\"a\")), \"done\");"
        "</script>"
        "<script type=\"typyscript\">"
        "fn later() -> u32 { return 42; }"
        "</script>");
    CHECK(parsed.diagnostics.empty());

    std::vector<tinyscript::Diagnostic> diags = browser::run_scripts(parsed.document);
    CHECK(diags.empty());
    CHECK_EQ(text_of(find_by_id(parsed.document, "a")), std::string("done"));

    tinyhtml::free_node(parsed.document);
}

TEST_CASE(default_dialect_is_tinyscript_and_never_checked) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(
        "<p id=\"a\">orig</p>"
        "<script>"  // no type attribute at all
        "let x = 5;"
        "setText(unwrap(getElementById(\"a\")), \"changed\");"
        "</script>");
    CHECK(parsed.diagnostics.empty());

    std::vector<tinyscript::Diagnostic> diags = browser::run_scripts(parsed.document);
    CHECK(diags.empty());
    CHECK_EQ(text_of(find_by_id(parsed.document, "a")), std::string("changed"));

    tinyhtml::free_node(parsed.document);
}

TEST_CASE(tinyscript_document_ignores_a_later_disagreeing_type_attribute) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(
        "<p id=\"a\">orig</p>"
        "<script>"  // first tag: no type -> document is tinyscript
        "let x = 5;"
        "</script>"
        "<script type=\"typyscript\">"  // disagreeing, but tinyscript doesn't reject
        "setText(unwrap(getElementById(\"a\")), \"changed\");"
        "</script>");
    CHECK(parsed.diagnostics.empty());

    std::vector<tinyscript::Diagnostic> diags = browser::run_scripts(parsed.document);
    CHECK(diags.empty());
    CHECK_EQ(text_of(find_by_id(parsed.document, "a")), std::string("changed"));

    tinyhtml::free_node(parsed.document);
}

TEST_CASE(typyscript_document_rejects_a_later_disagreeing_type_attribute) {
    tinyhtml::ParseResult parsed = tinyhtml::parse(
        "<p id=\"a\">orig</p>"
        "<script type=\"typyscript\">"  // first tag fixes the document as typyscript
        "let x: u32 = 5;"
        "setText(unwrap(getElementById(\"a\")), \"should-not-happen\");"
        "</script>"
        "<script>"  // defaults to tinyscript -- disagrees with the document's typyscript dialect
        "let y = 10;"
        "</script>");
    CHECK(parsed.diagnostics.empty());

    std::vector<tinyscript::Diagnostic> diags = browser::run_scripts(parsed.document);
    CHECK(!diags.empty());
    // Block 1 is individually well-typed but must not have run either --
    // the dialect mismatch fails the whole document, same as any other
    // checking failure.
    CHECK_EQ(text_of(find_by_id(parsed.document, "a")), std::string("orig"));

    tinyhtml::free_node(parsed.document);
}

TEST_CASE(no_script_elements_returns_no_diagnostics) {
    tinyhtml::ParseResult parsed = tinyhtml::parse("<p>just markup</p>");
    std::vector<tinyscript::Diagnostic> diags = browser::run_scripts(parsed.document);
    CHECK(diags.empty());
    tinyhtml::free_node(parsed.document);
}

TINYTEST_MAIN()
