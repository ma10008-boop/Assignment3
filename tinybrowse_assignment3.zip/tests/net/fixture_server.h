#pragma once

// Test-only scaffolding: a tiny loopback TCP server for exercising
// net::fetch() against real sockets without touching the real network.
// Not part of the shipped net module.

#include <cstring>
#include <string>
#include <thread>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

class FixtureServer {
public:
    FixtureServer() {
        listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);

        struct sockaddr_in addr;
        std::memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        addr.sin_port = 0;  // ask the OS for an ephemeral port
        bind(listen_fd_, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr));
        listen(listen_fd_, 1);

        struct sockaddr_in bound;
        socklen_t bound_len = sizeof(bound);
        getsockname(listen_fd_, reinterpret_cast<struct sockaddr*>(&bound), &bound_len);
        port_ = ntohs(bound.sin_port);
    }

    ~FixtureServer() {
        close(listen_fd_);
        if (server_thread_.joinable()) {
            server_thread_.join();
        }
    }

    int port() const { return port_; }

    // Accepts exactly one connection on a background thread, writes
    // `raw_response` verbatim, then closes it. Returns immediately -- the
    // caller's own connect() naturally blocks until accept() below is
    // ready, so no extra synchronization is needed.
    void serve_once(const std::string& raw_response) {
        server_thread_ = std::thread([this, raw_response] {
            int client_fd = accept(listen_fd_, nullptr, nullptr);
            if (client_fd < 0) {
                return;
            }
            respond(client_fd, raw_response);
        });
    }

    // Like serve_once, but accepts exactly `count` connections in
    // sequence, sending the same canned response to each. For tests that
    // need to hit this server more than once (e.g. a REPL "back" case,
    // which reloads the same page). Deliberately bounded rather than
    // looping until the destructor closes the listening socket -- closing
    // a socket doesn't reliably interrupt a concurrent blocking accept()
    // on Linux, so an open-ended version of this can hang the destructor
    // forever waiting for a connection that will never come.
    void serve_times(int count, const std::string& raw_response) {
        server_thread_ = std::thread([this, count, raw_response] {
            for (int i = 0; i < count; ++i) {
                int client_fd = accept(listen_fd_, nullptr, nullptr);
                if (client_fd < 0) {
                    return;
                }
                respond(client_fd, raw_response);
            }
        });
    }

private:
    static void respond(int client_fd, const std::string& raw_response) {
        char discard[4096];
        recv(client_fd, discard, sizeof(discard), 0);  // drain the request, best-effort
        size_t sent = 0;
        while (sent < raw_response.size()) {
            ssize_t n = send(client_fd, raw_response.data() + sent, raw_response.size() - sent, 0);
            if (n <= 0) {
                break;
            }
            sent += static_cast<size_t>(n);
        }
        close(client_fd);
    }

    int listen_fd_ = -1;
    int port_ = 0;
    std::thread server_thread_;
};

// A loopback port nothing is listening on, for exercising the
// connection-refused path: binds an ephemeral port, then releases it.
inline int unused_port() {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = 0;
    bind(fd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr));

    struct sockaddr_in bound;
    socklen_t bound_len = sizeof(bound);
    getsockname(fd, reinterpret_cast<struct sockaddr*>(&bound), &bound_len);
    int port = ntohs(bound.sin_port);

    close(fd);
    return port;
}
