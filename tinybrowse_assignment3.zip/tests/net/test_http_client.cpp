#include "tinytest.h"

#include <string>

#include "net/http_client.h"
#include "net/fixture_server.h"

using namespace net;

namespace {

std::string url_for(const FixtureServer& server, const std::string& path = "/") {
    return "http://127.0.0.1:" + std::to_string(server.port()) + path;
}

}  // namespace

TEST_CASE(fetches_body_framed_by_content_length) {
    FixtureServer server;
    server.serve_once("HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello");

    FetchResult result = fetch(url_for(server));
    CHECK(result.ok);
    CHECK_EQ(result.status_code, 200);
    CHECK_EQ(result.body, std::string("hello"));
}

TEST_CASE(fetches_body_framed_by_connection_close_when_no_content_length) {
    FixtureServer server;
    server.serve_once("HTTP/1.1 200 OK\r\nConnection: close\r\n\r\nhello, no length header");

    FetchResult result = fetch(url_for(server));
    CHECK(result.ok);
    CHECK_EQ(result.status_code, 200);
    CHECK_EQ(result.body, std::string("hello, no length header"));
}

TEST_CASE(non_2xx_status_is_still_a_successful_fetch) {
    FixtureServer server;
    server.serve_once("HTTP/1.1 404 Not Found\r\nContent-Length: 9\r\n\r\nnot found");

    FetchResult result = fetch(url_for(server));
    CHECK(result.ok);
    CHECK_EQ(result.status_code, 404);
    CHECK_EQ(result.body, std::string("not found"));
}

TEST_CASE(ignores_trailing_bytes_past_content_length) {
    FixtureServer server;
    server.serve_once("HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhelloEXTRA");

    FetchResult result = fetch(url_for(server));
    CHECK(result.ok);
    CHECK_EQ(result.body, std::string("hello"));
}

TEST_CASE(connection_refused_is_reported_as_an_error) {
    int port = unused_port();
    FetchResult result = fetch("http://127.0.0.1:" + std::to_string(port) + "/");
    CHECK(!result.ok);
    CHECK(!result.error.empty());
}

TEST_CASE(malformed_status_line_is_reported_as_an_error) {
    FixtureServer server;
    server.serve_once("not an http response\r\n\r\n");

    FetchResult result = fetch(url_for(server));
    CHECK(!result.ok);
    CHECK(!result.error.empty());
}

TEST_CASE(invalid_url_is_reported_as_an_error_without_touching_the_network) {
    FetchResult result = fetch("not-a-url");
    CHECK(!result.ok);
    CHECK(!result.error.empty());
}

TEST_CASE(response_past_the_size_cap_is_rejected) {
    FixtureServer server;
    std::string oversized(kMaxResponseBytes + 1024, 'x');
    server.serve_once("HTTP/1.1 200 OK\r\n\r\n" + oversized);

    FetchResult result = fetch(url_for(server));
    CHECK(!result.ok);
    CHECK(!result.error.empty());
}

TEST_CASE(response_headers_are_captured_with_lowercased_keys) {
    FixtureServer server;
    server.serve_once(
        "HTTP/1.1 200 OK\r\nContent-Length: 5\r\nSignature: xyz\r\nX-Custom: abc\r\n\r\nhello");

    FetchResult result = fetch(url_for(server));
    CHECK(result.ok);
    CHECK_EQ(result.headers.at("content-length"), std::string("5"));
    CHECK_EQ(result.headers.at("signature"), std::string("xyz"));
    CHECK_EQ(result.headers.at("x-custom"), std::string("abc"));
    CHECK(result.headers.find("does-not-exist") == result.headers.end());
}

TEST_CASE(header_lookup_is_case_insensitive_via_lowercased_keys) {
    FixtureServer server;
    server.serve_once("HTTP/1.1 200 OK\r\nCONTENT-LENGTH: 5\r\n\r\nhello");

    FetchResult result = fetch(url_for(server));
    CHECK(result.ok);
    CHECK_EQ(result.headers.at("content-length"), std::string("5"));
}

TEST_CASE(repeated_header_keeps_the_first_occurrence) {
    FixtureServer server;
    server.serve_once("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nX-Dup: first\r\nX-Dup: second\r\n\r\nhello");

    FetchResult result = fetch(url_for(server));
    CHECK(result.ok);
    CHECK_EQ(result.headers.at("x-dup"), std::string("first"));
}

TINYTEST_MAIN()
