#include "tinytest.h"

#include "tinyhtml/dom.h"

using namespace tinyhtml;

TEST_CASE(make_node_sets_type) {
    Node* n = make_node(NodeType::Text);
    CHECK(n->type == NodeType::Text);
    free_node(n);
}

TEST_CASE(append_child_links_siblings_in_order) {
    Node* parent = make_node(NodeType::Element);
    Node* a = make_node(NodeType::Text);
    Node* b = make_node(NodeType::Text);
    a->text = "a";
    b->text = "b";
    append_child(parent, a);
    append_child(parent, b);

    CHECK(parent->first_child == a);
    CHECK(a->next_sibling == b);
    CHECK(b->next_sibling == nullptr);
    CHECK(a->parent == parent);
    CHECK(b->parent == parent);

    free_node(parent);
}

TEST_CASE(find_attribute_returns_matching_attribute) {
    Node* el = make_node(NodeType::Element);
    Attribute* id_attr = new Attribute{"id", "banner", nullptr};
    el->attributes = id_attr;

    CHECK(find_attribute(el, "id") == id_attr);
    CHECK(find_attribute(el, "class") == nullptr);

    free_node(el);
}

TEST_CASE(find_attribute_on_non_element_returns_null) {
    Node* text = make_node(NodeType::Text);
    CHECK(find_attribute(text, "id") == nullptr);
    free_node(text);
}

TINYTEST_MAIN()
