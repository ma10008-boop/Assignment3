#include "tinytest.h"

#include <string>

#include "tinyhtml/parser.h"

using namespace tinyhtml;

namespace {

Node* first_child(Node* n) { return n->first_child; }
Node* nth_child(Node* n, int index) {
    Node* c = n->first_child;
    for (int i = 0; i < index && c != nullptr; ++i) {
        c = c->next_sibling;
    }
    return c;
}

}  // namespace

TEST_CASE(parses_text_and_element_content) {
    ParseResult result = parse("<p>hello <b>world</b></p>");
    CHECK(result.diagnostics.empty());

    Node* p = first_child(result.document);
    CHECK(p != nullptr);
    CHECK(p->type == NodeType::Element);
    CHECK_EQ(p->tag_name, std::string("p"));

    Node* text = nth_child(p, 0);
    CHECK(text != nullptr);
    CHECK(text->type == NodeType::Text);
    CHECK_EQ(text->text, std::string("hello "));

    Node* b = nth_child(p, 1);
    CHECK(b != nullptr);
    CHECK(b->type == NodeType::Element);
    CHECK_EQ(b->tag_name, std::string("b"));
    CHECK_EQ(nth_child(b, 0)->text, std::string("world"));

    free_node(result.document);
}

TEST_CASE(parses_attributes_and_decodes_entities) {
    ParseResult result =
        parse("<a href=\"/x?a=1&amp;b=2\" id=\"link\">go &lt;here&gt;</a>");
    CHECK(result.diagnostics.empty());

    Node* a = first_child(result.document);
    CHECK(find_attribute(a, "href") != nullptr);
    CHECK_EQ(find_attribute(a, "href")->value, std::string("/x?a=1&b=2"));
    CHECK_EQ(find_attribute(a, "id")->value, std::string("link"));
    CHECK_EQ(nth_child(a, 0)->text, std::string("go <here>"));

    free_node(result.document);
}

TEST_CASE(unrecognized_entity_passes_through_literally) {
    ParseResult result = parse("<p>5 &notanentity; 10</p>");
    CHECK_EQ(nth_child(first_child(result.document), 0)->text,
              std::string("5 &notanentity; 10"));
    free_node(result.document);
}

TEST_CASE(void_element_both_forms_have_no_children) {
    ParseResult result = parse("<p>a<br>b<br/>c</p>");
    CHECK(result.diagnostics.empty());

    Node* p = first_child(result.document);
    Node* br1 = nth_child(p, 1);
    Node* br2 = nth_child(p, 3);
    CHECK(br1->tag_name == "br" && br1->first_child == nullptr);
    CHECK(br2->tag_name == "br" && br2->first_child == nullptr);

    free_node(result.document);
}

TEST_CASE(mismatched_closing_tag_is_a_diagnostic) {
    ParseResult result = parse("<div><p>hi</div></p>");
    CHECK(!result.diagnostics.empty());
    free_node(result.document);
}

TEST_CASE(duplicate_attribute_is_a_diagnostic) {
    ParseResult result = parse("<p id=\"a\" id=\"b\">x</p>");
    CHECK(!result.diagnostics.empty());
    free_node(result.document);
}

TEST_CASE(duplicate_title_is_a_diagnostic_but_both_remain_in_tree) {
    ParseResult result = parse("<title>One</title><title>Two</title>");
    CHECK(!result.diagnostics.empty());

    Node* first = first_child(result.document);
    Node* second = first->next_sibling;
    CHECK(first != nullptr && first->tag_name == "title");
    CHECK(second != nullptr && second->tag_name == "title");

    free_node(result.document);
}

TEST_CASE(unknown_tag_is_a_diagnostic_but_still_parsed) {
    ParseResult result = parse("<foo>text</foo>");
    CHECK(!result.diagnostics.empty());

    Node* foo = first_child(result.document);
    CHECK(foo != nullptr);
    CHECK_EQ(foo->tag_name, std::string("foo"));
    CHECK_EQ(nth_child(foo, 0)->text, std::string("text"));

    free_node(result.document);
}

TEST_CASE(non_void_self_close_is_a_diagnostic) {
    ParseResult result = parse("<div/>");
    CHECK(!result.diagnostics.empty());
    free_node(result.document);
}

TEST_CASE(script_content_is_raw_text_not_markup_and_not_entity_decoded) {
    ParseResult result =
        parse("<script>if (a < b) { print(\"&amp;\"); }</script>");
    CHECK(result.diagnostics.empty());

    Node* script = first_child(result.document);
    CHECK_EQ(script->tag_name, std::string("script"));
    Node* text = nth_child(script, 0);
    CHECK(text != nullptr);
    CHECK_EQ(text->text, std::string("if (a < b) { print(\"&amp;\"); }"));

    free_node(result.document);
}

TEST_CASE(script_containing_literal_close_tag_truncates_early) {
    // Documented rough edge (docs/tinyhtml-spec.md section 5): the
    // raw-text scan looks for a literal "</script>", so a string literal
    // containing that exact text ends the block early.
    ParseResult result = parse("<script>let s = \"</script>\";</script>");

    Node* script = first_child(result.document);
    Node* text = nth_child(script, 0);
    CHECK_EQ(text->text, std::string("let s = \""));

    // The rest of the source (`";</script>`) is leftover top-level content:
    // a stray `"` (text) then a second, unmatched closing tag.
    CHECK(!result.diagnostics.empty());

    free_node(result.document);
}

TEST_CASE(deeply_nested_document_is_rejected_without_crashing) {
    std::string source;
    const int depth = 600;  // over the 512 cap
    for (int i = 0; i < depth; ++i) {
        source += "<div>";
    }
    source += "x";
    for (int i = 0; i < depth; ++i) {
        source += "</div>";
    }

    ParseResult result = parse(source);
    CHECK(!result.diagnostics.empty());
    CHECK(result.document != nullptr);

    free_node(result.document);
}

TEST_CASE(unterminated_tag_and_string_do_not_hang_or_crash) {
    ParseResult result = parse("<p id=\"unterminated");
    CHECK(!result.diagnostics.empty());
    CHECK(result.document != nullptr);
    free_node(result.document);
}

TINYTEST_MAIN()
