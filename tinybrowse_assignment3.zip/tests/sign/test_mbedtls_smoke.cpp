#include "tinytest.h"

#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>

#include "mbedtls/x509_crt.h"

namespace {

// Phase 0 checkpoint: proves the vendored-from-source mbedTLS build
// (src/sign/CMakeLists.txt) actually links and can parse a real DER
// certificate end to end -- not yet wired into tinybrowse itself.
bool read_file(const std::string& path, std::string* out) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        return false;
    }
    std::ostringstream buffer;
    buffer << file.rdbuf();
    *out = buffer.str();
    return true;
}

}  // namespace

TEST_CASE(parses_a_der_certificate_and_reads_its_subject) {
    std::string der;
    CHECK(read_file(std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/smoke_cert.der", &der));

    mbedtls_x509_crt crt;
    mbedtls_x509_crt_init(&crt);
    int ret = mbedtls_x509_crt_parse_der(
        &crt, reinterpret_cast<const unsigned char*>(der.data()), der.size());
    CHECK_EQ(ret, 0);

    char subject[256];
    int written = mbedtls_x509_dn_gets(subject, sizeof(subject), &crt.subject);
    CHECK(written > 0);
    CHECK_EQ(std::string(subject), std::string("CN=tinybrowse-smoke-test"));

    mbedtls_x509_crt_free(&crt);
}

TEST_CASE(rejects_truncated_der) {
    std::string der;
    CHECK(read_file(std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/smoke_cert.der", &der));
    der.resize(der.size() / 2);

    mbedtls_x509_crt crt;
    mbedtls_x509_crt_init(&crt);
    int ret = mbedtls_x509_crt_parse_der(
        &crt, reinterpret_cast<const unsigned char*>(der.data()), der.size());
    CHECK(ret != 0);
    mbedtls_x509_crt_free(&crt);
}

TINYTEST_MAIN()
