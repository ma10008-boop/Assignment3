#include "tinytest.h"

#include <string>

#include "sign/base64.h"
#include "sign/content_digest.h"

using namespace sign;

TEST_CASE(matches_a_known_sha256_vector_for_empty_body) {
    CHECK_EQ(compute_content_digest(""), std::string("sha-256=:47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=:"));
}

TEST_CASE(matches_a_known_sha256_vector) {
    CHECK_EQ(compute_content_digest("hello"),
             std::string("sha-256=:LPJNul+wow4m6DsqxbninhsWHlwfp0JecwQzYpOLmCQ=:"));
}

TEST_CASE(differs_for_different_bodies) {
    CHECK(compute_content_digest("hello") != compute_content_digest("hellp"));
}

TEST_CASE(embedded_base64_payload_decodes_to_32_bytes) {
    std::string digest_header = compute_content_digest("some page body");
    CHECK_EQ(digest_header.substr(0, 9), std::string("sha-256=:"));
    CHECK_EQ(digest_header.back(), ':');
    std::string payload = digest_header.substr(9, digest_header.size() - 10);
    std::string decoded;
    CHECK(base64_decode(payload, &decoded));
    CHECK_EQ(decoded.size(), static_cast<size_t>(32));
}

TINYTEST_MAIN()
