#include "tinytest.h"

#include <string>

#include "sign/base64.h"

using namespace sign;

TEST_CASE(encodes_known_vector) {
    CHECK_EQ(base64_encode("foobar"), std::string("Zm9vYmFy"));
    CHECK_EQ(base64_encode("foo"), std::string("Zm9v"));
    CHECK_EQ(base64_encode("fo"), std::string("Zm8="));
    CHECK_EQ(base64_encode("f"), std::string("Zg=="));
    CHECK_EQ(base64_encode(""), std::string(""));
}

TEST_CASE(decodes_known_vector) {
    std::string out;
    CHECK(base64_decode("Zm9vYmFy", &out));
    CHECK_EQ(out, std::string("foobar"));
    CHECK(base64_decode("Zm8=", &out));
    CHECK_EQ(out, std::string("fo"));
    CHECK(base64_decode("Zg==", &out));
    CHECK_EQ(out, std::string("f"));
    CHECK(base64_decode("", &out));
    CHECK_EQ(out, std::string(""));
}

TEST_CASE(round_trips_every_length_from_0_to_10_with_binary_content) {
    std::string data;
    for (int len = 0; len <= 10; ++len) {
        data.push_back(static_cast<char>((len * 37 + 5) % 256));
        std::string encoded = base64_encode(data);
        std::string decoded;
        CHECK(base64_decode(encoded, &decoded));
        CHECK_EQ(decoded, data);
    }
}

TEST_CASE(round_trips_all_256_byte_values) {
    std::string data;
    for (int i = 0; i < 256; ++i) {
        data.push_back(static_cast<char>(i));
    }
    std::string decoded;
    CHECK(base64_decode(base64_encode(data), &decoded));
    CHECK_EQ(decoded, data);
}

TEST_CASE(rejects_length_not_a_multiple_of_four) {
    std::string out;
    CHECK(!base64_decode("Zm9vY", &out));
    CHECK(!base64_decode("A", &out));
}

TEST_CASE(rejects_a_character_outside_the_alphabet) {
    std::string out;
    CHECK(!base64_decode("Zm9v!mFy", &out));
    CHECK(!base64_decode("****", &out));
}

TEST_CASE(rejects_padding_in_the_middle) {
    std::string out;
    CHECK(!base64_decode("Zm=9YmFy", &out));
    CHECK(!base64_decode("AB=A", &out));
}

TEST_CASE(rejects_too_much_padding) {
    std::string out;
    CHECK(!base64_decode("A===", &out));
}

TINYTEST_MAIN()
