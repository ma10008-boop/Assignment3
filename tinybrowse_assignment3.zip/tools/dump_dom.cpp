// Dev CLI: parses a tinyhtml file and prints its DOM tree, indented by
// depth. Useful for debugging the parser and as a template for other
// dump tools (e.g. a tinyscript AST dumper).
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>

#include "tinyhtml/dom.h"
#include "tinyhtml/parser.h"

namespace {

void print_node(tinyhtml::Node* node, int depth) {
    if (node == nullptr) {
        return;
    }

    std::string indent(static_cast<size_t>(depth) * 2, ' ');
    switch (node->type) {
        case tinyhtml::NodeType::Document:
            std::printf("%sDocument\n", indent.c_str());
            break;
        case tinyhtml::NodeType::Element:
            std::printf("%s<%s>\n", indent.c_str(), node->tag_name.c_str());
            break;
        case tinyhtml::NodeType::Text:
            std::printf("%s\"%s\"\n", indent.c_str(), node->text.c_str());
            break;
    }

    for (tinyhtml::Node* child = node->first_child; child != nullptr; child = child->next_sibling) {
        print_node(child, depth + 1);
    }
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::fprintf(stderr, "usage: %s <file.thtml>\n", argv[0]);
        return 2;
    }

    std::ifstream file(argv[1]);
    if (!file) {
        std::fprintf(stderr, "dump_dom: could not read '%s'\n", argv[1]);
        return 1;
    }
    std::ostringstream buffer;
    buffer << file.rdbuf();

    tinyhtml::ParseResult parsed = tinyhtml::parse(buffer.str());
    for (const tinyhtml::Diagnostic& diag : parsed.diagnostics) {
        std::fprintf(stderr, "line %d: %s\n", diag.line, diag.message.c_str());
    }
    print_node(parsed.document, 0);

    tinyhtml::free_node(parsed.document);
    return 0;
}
