# Stack Canaries

## Setup

I enabled stack protection using Clang 14 with the following compiler flag:

    -fstack-protector-strong

I configured a separate Release build in the `build-stack` directory and compiled the Tinybrowse project successfully.

## Output

The build completed successfully.

I verified the executable using:

    readelf -s build-stack/src/browser/tinybrowse | grep __stack_chk

The output contained:

    __stack_chk_fail

This confirms that the executable references the stack-canary failure handler.

## Reach & limits

Stack canaries help detect certain stack-buffer overflows that overwrite the protected stack canary value.

If the canary is corrupted, the program can terminate instead of continuing with potentially corrupted execution.

However, stack canaries do not prevent every memory vulnerability. They do not protect heap memory or fix issues such as the format-string vulnerability and array concatenation bug found during this assignment.

