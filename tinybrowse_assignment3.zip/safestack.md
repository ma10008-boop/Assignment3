# SafeStack

## Setup

I used Clang 14 to enable SafeStack with:

    -fsanitize=safe-stack

I configured a separate Release build in the `build-safestack` directory. The project compiled successfully.

## Output

I verified the executable using:

    nm build-safestack/src/browser/tinybrowse | grep -E '__safestack|__llvm_safestack'

The output contained:

    __safestack_init
    __safestack_preinit
    __safestack_unsafe_stack_ptr

These symbols confirm that SafeStack runtime support is included in the executable.

## Reach & limits

SafeStack separates the safe stack from the unsafe stack. This helps protect return addresses and other sensitive stack data from certain stack-based memory corruption attacks.

However, SafeStack does not prevent every memory vulnerability. It does not protect heap allocations or fix the underlying bugs in the application.
