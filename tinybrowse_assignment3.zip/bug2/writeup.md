# Bug 2: Integer Truncation in Array Concatenation

**Component:** TinyScript Array Implementation (`src/tinyscript/array.cpp`)

**Bug class:** Integer Overflow / Heap Buffer Overflow

**Discovery method:** Manual source code inspection and runtime testing.

## Root-cause analysis

The vulnerability is in the `array_concat()` function. The combined array length is calculated and stored in a `uint16_t` variable:

    uint16_t total = static_cast<uint16_t>(a.array_length + b.array_length);

The original array lengths use `size_t`, but the result is converted to a 16-bit integer. If the combined length exceeds 65,535, the value is truncated.

The program then allocates memory using this incorrect length but continues copying all elements from both input arrays. This can cause writes beyond the allocated heap buffer.

I reproduced the issue using two arrays of 32,768 elements each:

    let a: Array<u32> = array_new(32768);
    let b: Array<u32> = array_new(32768);
    let c: Array<u32> = array_concat(a, b);

The expected result length was 65,536, but the program printed 0. This confirms the integer truncation. The copy loops in the source code can then write beyond the allocated buffer.

A safer implementation should use `size_t` for the total and check for addition overflow before allocating memory.
