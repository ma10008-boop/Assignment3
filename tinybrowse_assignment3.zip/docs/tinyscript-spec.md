# tinyscript specification

tinyscript is a small, dynamically-typed imperative language embedded in `<script>` blocks
(`<script type="tinyscript">`, or no `type` attribute at all — that's the default). It lets
tinyhtml pages manipulate the DOM at load time. `typyscript` (see `typyscript-spec.md`) is the
same language plus mandatory type annotations, checked before anything runs.

## 1. Lexical grammar

```
token         ::= IDENT | NUMBER | STRING | KEYWORD | operator/punctuation | EOF

IDENT         ::= [a-zA-Z_][a-zA-Z0-9_]*        ; not a KEYWORD
NUMBER        ::= INT_LITERAL | DECIMAL_LITERAL
INT_LITERAL   ::= [0-9]+ KIND_SUFFIX?
DECIMAL_LITERAL ::= [0-9]+ "." [0-9]+ FLOAT_SUFFIX?
KIND_SUFFIX   ::= "u8" | "u32" | "u64" | "i8" | "i32" | "i64" | "f32" | "f64"
FLOAT_SUFFIX  ::= "f32" | "f64"
STRING        ::= '"' (escape | any char except '"' or newline)* '"'
escape        ::= "\\" ( "n" | "t" | "\\" | '"' )

KEYWORD       ::= "let" | "fn" | "if" | "else" | "while" | "return"
                | "true" | "false" | "as"
```

**Numeric literal defaults**: a bare `INT_LITERAL` with no suffix is `i32`; a bare
`DECIMAL_LITERAL` with no suffix is `f32`. A `DECIMAL_LITERAL` may only take a float suffix
(`5.0u8` is a lexer error). Use a suffix to get any of the other 6 kinds directly, e.g. `5u8`,
`200u64`, `3.5f64`.

Line comments start with `//` and run to end of line. There is no block comment form.

## 2. Context-free grammar

```
Program        ::= Statement*

Statement      ::= VarDecl | Assign | IfStmt | WhileStmt
                  | FuncDecl | ReturnStmt | ExprStmt | Block

VarDecl        ::= "let" IDENT TypeAnnotation? ( "=" Expr )? ";"
Assign         ::= Lvalue "=" Expr ";"
Lvalue         ::= IDENT | Lvalue "[" Expr "]"
IfStmt         ::= "if" "(" Expr ")" Block ( "else" ( IfStmt | Block ) )?
WhileStmt      ::= "while" "(" Expr ")" Block
FuncDecl       ::= "fn" IDENT "(" ParamList? ")" ReturnAnnotation? Block
ParamList      ::= Param ( "," Param )*
Param          ::= IDENT TypeAnnotation?
ReturnStmt     ::= "return" Expr? ";"
ExprStmt       ::= Expr ";"
Block          ::= "{" Statement* "}"

TypeAnnotation    ::= ":" Type   ; optional here; see typyscript-spec.md for the Type grammar
ReturnAnnotation  ::= "->" Type  ; and for when annotations become mandatory

Expr           ::= LogicOr
LogicOr        ::= LogicAnd ( "||" LogicAnd )*
LogicAnd       ::= Equality ( "&&" Equality )*
Equality       ::= Comparison ( ( "==" | "!=" ) Comparison )*
Comparison     ::= Term ( ( "<" | ">" | "<=" | ">=" ) Term )*
Term           ::= Factor ( ( "+" | "-" ) Factor )*
Factor         ::= Cast ( ( "*" | "/" | "%" ) Cast )*
Cast           ::= Unary ( "as" KIND_SUFFIX )*
Unary          ::= ( "!" | "-" ) Unary | Postfix
Postfix        ::= Primary ( "(" ArgList? ")" | "[" Expr "]" )*
Primary        ::= NUMBER | STRING | "true" | "false"
                  | IDENT | "(" Expr ")" | ArrayLiteral
ArrayLiteral   ::= "[" ( Expr ( "," Expr )* )? "]"
ArgList        ::= Expr ( "," Expr )*
```

Notes:

- **Assignment is a statement, not an expression** — no `x = y = 3` chaining, no
  assignment-as-value.
- `Lvalue` covers both a plain variable (`x = 1;`) and an array slot (`arr[i] = 1;`); the
  grammar allows chained indexing (`arr[i][j] = 1;`) for arrays of arrays.
- `TypeAnnotation`/`ReturnAnnotation` are always syntactically legal to write, in every
  `<script>` regardless of dialect — tinyscript's interpreter just ignores them. Only
  typyscript's checker requires and enforces them.

### Operator precedence (low to high)

| Level | Operators | Associativity |
|---|---|---|
| 1 (lowest) | `\|\|` | left |
| 2 | `&&` | left |
| 3 | `==` `!=` | left |
| 4 | `<` `>` `<=` `>=` | left |
| 5 | `+` `-` | left |
| 6 | `*` `/` `%` | left |
| 7 | `as` (cast) | left |
| 8 | unary `!` `-` | right |
| 9 (highest) | call `(...)`, subscript `[...]` | left |

## 3. Values

A tinyscript value is always concretely one of:

```
u8 u32 u64 i8 i32 i64 f32 f64   -- 8 numeric kinds, no generic "number"
String
Bool
Unit                             -- the "nothing" value: (), no payload
Element                          -- a reference into the DOM tree
Function                         -- a reference to a declared function
Result                           -- Ok(...) or Err(...), see §6
Array                            -- a fixed-length sequence of values, see §5
```

There are **no closures**: a function value is just a reference to its declaration.
Functions are hoisted document-wide — every `fn` declared in any `<script>` block in the
document is visible from any other block, regardless of order (see §7). Variables declared
with `let` are block-scoped in the ordinary nested sense.

**Truthiness** (`if`/`while`/`!`/`&&`/`||`): `false`, `0` (any numeric kind), `""`, and `Unit`
are falsy; everything else — including any `Array` or `Result`, regardless of contents — is
truthy.

**Equality** (`==`/`!=`): comparing two values whose kinds fall into different *categories*
(e.g. `String` vs `Bool`, a number vs `Element`) is always `false` (never an error). Within a
category: two numeric values of *any* of the 8 kinds compare by value after promotion (§4) —
`5u8 == 5u32` is `true`, exactly like `5u8 + 5u32` promotes before adding; `String`/`Bool`
compare by value; `Element`/`Function` compare by identity (are they the *same* DOM node / the
*same* declared function, not merely an equal-looking one); `Result`/`Array` compare
structurally — `Ok(5) == Ok(5)` is `true`, `[1, 2] == [1, 2]` is `true`, even though each side
was constructed independently.

## 4. Operator semantics

**Arithmetic** (`+ - * / %`) and numeric comparisons (`< > <= >=`) require both operands to be
numeric. If they're different kinds, both are first promoted to a common kind per the table
below, then the operation is performed in that kind. `+` also accepts a `String` on either
side: if either operand is a `String`, the other is converted to its string form (numbers →
decimal digits, `Bool` → `"true"`/`"false"`, `Unit` → `"()"`) and the result is string
concatenation.

### The promotion table

Given two different numeric kinds, the result kind is:

|        | U8  | U32 | U64 | I8  | I32 | I64 | F32 | F64 |
|--------|-----|-----|-----|-----|-----|-----|-----|-----|
| **U8** | U8  | U32 | U64 | U8  | I32 | I64 | F32 | F64 |
| **U32**| U32 | U32 | U64 | U32 | U32 | I64 | F32 | F64 |
| **U64**| U64 | U64 | U64 | U64 | U64 | U64 | F32 | F64 |
| **I8** | U8  | U32 | U64 | I8  | I32 | I64 | F32 | F64 |
| **I32**| I32 | U32 | U64 | I32 | I32 | I64 | F32 | F64 |
| **I64**| I64 | I64 | U64 | I64 | I64 | I64 | F32 | F64 |
| **F32**| F32 | F32 | F32 | F32 | F32 | F32 | F32 | F64 |
| **F64**| F64 | F64 | F64 | F64 | F64 | F64 | F64 | F64 |

In words: a float operand always wins over an integer operand (and, note, an `i64`/`u64`
combined with an `f32` is promoted to `f32`, which can lose precision for large values); among
two floats, the wider one wins; among two integers of different width, the wider one wins
outright; among two integers of the *same* width but different signedness, the **unsigned**
one wins (e.g. `i32 + u32` produces a `u32`, and a negative `i32` operand is reinterpreted as
a large unsigned value before the addition).

### Overflow and casts

Integer arithmetic **wraps** on overflow: the result is computed modulo 2^n for an n-bit
kind. `as` performs an explicit cast and uses the same wraparound rule for a narrowing
integer→integer conversion (compute in the source's width, then keep only the low bits of the
target width): `300u32 as u8 == 44`, `-1i32 as u8 == 255`. A widening integer→integer cast
(e.g. `5u8 as u32`) simply extends, no wraparound involved.

A float→integer cast **saturates** instead of wrapping: a value outside the target's
representable range clamps to that range's minimum or maximum, and `NaN` becomes `0`
(`1e20f32 as i32 == i32::MAX`, `-1e20f32 as i32 == i32::MIN`). Casting a non-numeric value
(`String`, `Bool`, `Element`, `Result`, `Array`, `Unit`) is not supported — it's a Diagnostic,
evaluated result is `Unit`, execution continues.

### Division and modulo

Integer division/modulo by zero is a Diagnostic; the expression evaluates to `0` and
execution continues. Dividing the most negative value of a signed kind by `-1` (the one other
case that overflows) wraps back to that same most-negative value, following the same
wraparound rule as any other integer overflow. Floats use ordinary IEEE-754 behavior for
division by zero (`±inf`/`NaN`, not a Diagnostic).

## 5. Arrays

`[e1, e2, ...]` constructs a fixed-length array from the given elements. `array_new(n)`
allocates a fixed-length array of `n` elements, every one initially `Unit` (regardless of what
you go on to store there). Arrays never grow past their allocated length, but `array_pop` (below)
can shrink one.

`arr[i]` reads element `i`; `arr[i] = value;` writes it. **Index access is bounds-checked.**
An out-of-range `i` (negative, or `>= array_len(arr)`) is a Diagnostic, not a crash: a
read evaluates to `Unit`, a write does nothing (the array is left unchanged), and execution
continues either way, consistent with every other runtime error in this language (§8).

| Function | Signature | Behavior |
|---|---|---|
| `array_new(n)` | `(u64) -> Array` | Allocates an `n`-element array, every slot `Unit`. |
| `array_len(arr)` | `(Array) -> u64` | The array's fixed length. |
| `array_concat(a, b)` | `(Array, Array) -> Array` | A new array holding `a`'s elements followed by `b`'s. |
| `array_pop(arr)` | `(Array) -> Result<T, ()>` | Removes and returns `arr`'s last element as `Ok(value)`, reducing its length by one. `Err(())` if `arr` is empty. |

## 6. The `Result` type

`Result` represents "a value, or an error instead" — there is no separate `Option`/nullable
type; use `Result<T, ()>` (see `typyscript-spec.md`) when there's no error value to carry,
only a fail case.

| Function | Signature | Behavior |
|---|---|---|
| `Ok(value)` | `T -> Result` | Constructs a success value carrying `value`. |
| `Err(value)` | `E -> Result` | Constructs a failure value carrying `value`. |
| `is_ok(r)` | `Result -> Bool` | `true` iff `r` was constructed with `Ok`. |
| `is_err(r)` | `Result -> Bool` | `true` iff `r` was constructed with `Err`. |
| `unwrap(r)` | `Result -> T` | The `Ok` payload. Calling this on an `Err` value (or a non-`Result` value) is a Diagnostic; the expression evaluates to `Unit`, execution continues. |
| `unwrap_err(r)` | `Result -> E` | The `Err` payload, with the same wrong-variant behavior as `unwrap`. |

`getElementById` (§7) is the DOM API's own use of this pattern: it returns `Result<Element,
()>` rather than a nullable element.

## 7. The DOM API

| Function | Signature | Behavior |
|---|---|---|
| `getElementById(id)` | `(String) -> Result<Element, ()>` | The first element in document order whose `id` attribute equals `id`, or `Err(())` if none matches. |
| `getAttribute(el, name)` | `(Element, String) -> Result<String, ()>` | The named attribute's value, or `Err(())` if absent. |
| `firstChild(el)` | `(Element) -> Result<Element, ()>` | `el`'s first child element. |
| `setAttribute(el, name, value)` | `(Element, String, String) -> Unit` | Sets (or replaces) the attribute. |
| `setText(el, text)` | `(Element, String) -> Unit` | Replaces all of `el`'s children with a single text node containing `text` verbatim — no re-parsing as markup. |
| `setHtml(el, html)` | `(Element, String) -> Unit` | Parses `html` as a tinyhtml fragment and replaces `el`'s children with the result. The content is **not** escaped or sanitized in any way. |
| `on(el, event, handlerName)` | `(Element, String, String) -> Unit` | Registers `handlerName` (a declared function) to run when `event` fires on `el`. Currently only `"click"` is a recognized event; registering a handler is accepted, but nothing invokes it in this version of tinybrowse. tinybrowse's interactive session navigates `<a href>` links directly, without going through this event system at all. |
| `print(value)` | `(any value) -> Unit` | Writes a debug representation of `value` to stderr. Never affects the rendered page. |

## 8. Execution and error model

There are no exceptions in tinyscript. Every runtime error — a type mismatch, wrong arity,
calling an undefined function, dividing by zero, an unresolvable cast — is recorded as a
Diagnostic, the offending expression evaluates to `Unit`, and execution continues with the
next statement. A broken script does not stop the rest of the page from loading.

Pipeline: tinyhtml parses the whole document first (no scripts have run yet); the browser then
walks the tree in document order, lexes and parses each `<script>` element's raw text into a
`Program`, and executes each `Program`'s statements immediately, in document order. All
`Program`s in a document share **one global environment and one function table** — a variable
or function from an earlier `<script>` block is visible to a later one, and (per the hoisting
note in §3) a function from a *later* block is callable from an earlier one too. After every
`<script>` has run, the browser calls, in document order, the function named by each
element's `onload` attribute, if any; an `onload` naming an undeclared function is a
Diagnostic, not a crash.

## 9. Example

```html
<script>
let clicks = 0;

fn onBannerClick() {
    clicks = clicks + 1;
    let counter = getElementById("counter");
    if (is_ok(counter)) {
        setText(unwrap(counter), "Clicks: " + clicks);
    }
}
</script>
<h1 id="banner" onclick="onBannerClick">Click me</h1>
<p id="counter">Clicks: 0</p>
```
